<template>
  <div id="app" class="container-fluid">
    <div v-if="getLoaderStatus" class="k-loading-mask" style="width:100%;height:100%">
      <span class="k-loading-text">Loading...</span>
      <div class="k-loading-image">
        <div class="k-loading-color"></div>
      </div>
    </div>

    <!-- <LoginComponent v-if="!authenticated" @loggedIn="onLoggedIn" /> -->
    <!-- header section -->
    <Header />
    <div class="row">
      <div id="viewport" :class="{'leftSubmenuOpen':toggle}">
        <LeftMenu @clicked="onClickChild" />
        <!-- <RightMenu /> -->
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
// import LoginComponent from './modules/login/login';
import LeftMenu from './components/LeftMenu';
import Header from './components/Header';
import RightMenu from './components/RightMenu';

export default {
  components: {
    LeftMenu,
    Header,
    RightMenu
  },
  data() {
    return {
      toggle: false,
      authenticated: false
    };
  },
  computed: {
    getLoaderStatus() {
      return this.$store.getters.getLoaderStatus;
    }
  },
  methods: {
    onClickChild(value) {
      this.toggle = value;
    },
    onLoggedIn(loggIn) {
      this.authenticated = loggIn;
    }
  },
  created() {
    this.$store.dispatch('setLoaderStatus', false);
  }
};
</script>

