import Vue from 'vue';

import Toasted from 'vue-toasted';

Vue.use(Toasted);
/* eslint-disable */
export const showToast = (param) => {
    if (param === 'success') {
        Vue.toasted.show('Record has been saved successfully !!', {
            theme: 'toasted-primary',
            type: 'success',
            duration: 1500,
            position: 'top-center'
        });
    } else if (param === 'error') {
        Vue.toasted.show('Internal Server Error !!', {
            theme: 'toasted-primary',
            type: 'error',
            duration: 1500,
            position: 'top-center'
        });
    }
};

