import Vue from 'vue';

import Toasted from 'vue-toasted';
import HTTP from './http-common';
import store from '../../store/store';

Vue.use(Toasted);

/* eslint-disable */
const axiosMethods = {
  // axios http get request
  getRequest(urls, body) {
    return HTTP.get(urls, body).then(res => res).catch(() => {
    });
  },

  // axios http put request
  putRequest(urls, body) {
    return HTTP.put(urls, body).then((res) => {
      Vue.toasted.show('Record has been saved successfully !!', {
        theme: 'toasted-primary',
        type: 'success',
        duration: 1500,
        position: 'top-center'
      });
      return res;
    }).catch((error) => {
      // eslint-disable-next-line no-console
      console.log(error);
      Vue.toasted.show('Internal Server Error !!', {
        theme: 'toasted-primary',
        type: 'error',
        duration: 1500,
        position: 'top-center'
      });
    });
  },

  // axios http post request
  // postRequest(urls, body) {
  //   return HTTP.post(urls, body).then((res) => {
  //     Vue.toasted.show('Records has been updated successfully !!', {
  //       theme: 'toasted-primary',
  //       type: 'success',
  //       duration: 1500,
  //       position: 'top-center'
  //     });
  //     return res;
  //   }).catch((error) => {
  //     // eslint-disable-next-line no-console
  //     console.log(error);
  //     Vue.toasted.show('Internal Server Error !!', {
  //       theme: 'toasted-primary',
  //       type: 'error',
  //       duration: 1500,
  //       position: 'top-center'
  //     });
  //   });
  // },

  postRequest(urls, body) {
    store.dispatch('setLoaderStatus', true);
    return HTTP.post(urls, body).then((response) => {
      store.dispatch('setLoaderStatus', false);
      return response;
    }).catch((error) => {
      store.dispatch('setLoaderStatus', false);
      // eslint-disable-next-line no-console 
      Vue.toasted.show('Internal Server Error !!', {
        theme: 'toasted-primary',
        type: 'error',
        duration: 1500,
        position: 'top-center'
      });
    });
  },

  /**
   * 
   * @param {*} urls 
   * @param {*} body 
   * @description 'This function will a use case which is working with new response code
   *                Provided by api'
   */
  postRequestAction(urls, body) {
    store.dispatch('setLoaderStatus', true);
    return HTTP.post(urls, body).then((response) => {
      store.dispatch('setLoaderStatus', false);
      return response;
    }).catch((error) => {
      store.dispatch('setLoaderStatus', false);
      // eslint-disable-next-line no-console 
      Vue.toasted.show('Internal Server Error !!', {
        theme: 'toasted-primary',
        type: 'error',
        duration: 1500,
        position: 'top-center'
      });
    });
  },

  // axios http delete request
  deleteRequest(urls, body) {
    return HTTP.post(urls, body).then((res) => {
      Vue.toasted.show('Records has been deleted successfully !!', {
        theme: 'toasted-primary',
        type: 'success',
        duration: 1500,
        position: 'top-center'
      });
      return res;
    }).catch((error) => {
      // eslint-disable-next-line no-console
      console.log(error);
      Vue.toasted.show('Internal Server Error !!', {
        theme: 'toasted-primary',
        type: 'error',
        duration: 1500,
        position: 'top-center'
      });
    });
  },

  // axios http upload image request
  fileUploadRequest(urls, body, headers) {
    return HTTP.post(urls, body, headers).then((res) => {
      return res;
    }).catch((error) => {
      // eslint-disable-next-line no-console
      console.log(error);
      Vue.toasted.show('Internal Server Error !!', {
        theme: 'toasted-primary',
        type: 'error',
        duration: 1500,
        position: 'top-center'
      });
    });
  },

  // axios http upload image request
  fileUploadRequest2(urls, body) {
    return HTTP.post(urls, body).then(res => res).catch((error) => {
      // eslint-disable-next-line no-console
      console.log(error);
    });
  }

};

export default axiosMethods;
