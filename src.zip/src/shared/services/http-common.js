import axios from 'axios';

const HTTP = axios.create({
  baseURL: 'http://10.131.85.3:5001/'
});

export default HTTP;
