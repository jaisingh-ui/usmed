/* eslint-disable */
import VALIDATION_MESSAGE from '../constants/messages';

// eslint-disable-next-line import/prefer-default-export
export const showWindowConfrim = () => {
    return window.confirm(VALIDATION_MESSAGE.CANCEL_ALERT);
};
