/* eslint-disable indent */

import axiosMethods from './base-service';

const commonService = {
    getConfigurableMenus(url, body) {
        return axiosMethods.getRequest(url, body).then(res => res);
    }
};

export default commonService;
