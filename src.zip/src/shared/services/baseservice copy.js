import axios from 'axios';

export default {
  methods: {
    getDataFromApi(path, requestObject) {
      let responseObject = null;
      axios
        .get(path, requestObject)
        .then((response) => { responseObject = response.data; });
      return responseObject;
    },
    putDataToApi(path, requestObject) {
      let responseObject = null;
      axios
        .put(path, requestObject)
        .then((response) => { responseObject = response.data; });
      return responseObject;
    },
    deleteDataToApi(path, requestObject) {
      let responseObject = null;
      axios
        .delete(path, requestObject)
        .then((response) => { responseObject = response.data; });
      return responseObject;
    },
    postDataToApi(path, requestObject) {
      let responseObject = null;
      axios
        .post(path, requestObject)
        .then((response) => { responseObject = response.data; });
      return responseObject;
    }
  }
};
