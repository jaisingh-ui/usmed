/* eslint-disable indent */
export const ModelUrls = {
    modelListSearch: 'api/modelcatalog/search',
    modelListShowAll: 'api/modelcatalog',
    modelGeneralData: 'api/modelcatalog/generaldetails',
    addModelGeneralData: 'api/ModelCatalog/generaldetails',
    getModelAccountingData: 'api/modelcatalog/accounting',
    saveModelAccountingData: 'api/ModelCatalog/accounting',
    getModelMobileSettings: 'api/ModelCatalog/mobilesettings',
    saveMobileSettings: 'api/ModelCatalog/mobilesettings',
    getModelAdditionalInfo: 'api/ModelCatalog/additionalinfo',
    saveModelAdditionalInfo: 'api/ModelCatalog/additionalinfo',
    ModelImages: 'api/ModelCatalog/modelimages',
    removeImage: 'api/ModelCatalog/image/delete',
    getModelOptions: 'api/ModelOption/option',
    saveModelOptions: 'api/ModelOption/option/save',
    // Model Software Versions
    getModelSoftwareVersions: 'api/ModelOption/softwareversion',
    savetModelSoftwareVersions: 'api/ModelOption/softwareversion/save',
    // Model Pricing
    getModelPricing: 'api/ModelPricing/pricing',
    saveModelPricing: 'api/ModelPricing/pricing/save',
    searchModelLookUpData: 'api/ModelAssociatedModelPart/commonname',
    getComaparableModelData: 'api/ModelAssociatedModelPart/comparablemodel',
    postComaparableModelData: 'api/ModelAssociatedModelPart/comparablemodel/save',
    getAssociateModelData: 'api/ModelAssociatedModelPart/associatedmodel',
    postAssociateModelData: 'api/ModelAssociatedModelPart/associatedmodel/save',
    getStandardPartModelData: 'api/ModelAssociatedModelPart/standardpart',
    postStandardPartModelData: 'api/ModelAssociatedModelPart/standardpart/save',
    getUsablePartModelData: 'api/ModelAssociatedModelPart/usablepart',
    postUsablePartModelData: 'api/ModelAssociatedModelPart/usablepart/save',
    getAccessoriesModelData: 'api/ModelAssociatedModelPart/accessory',
    postAccessoriesModelData: 'api/ModelAssociatedModelPart/accessory/save',
    /**
     * Model Video List Urls
     */
    getVideoListModelData: '/api/Documentation/GetVideo',
    postVideoListModelData: '/api/Documentation/SaveVideo'
};

export const ContactsUrls = {
    GET_CONTACT_LIST: 'http://10.131.85.70:5555/api/ContactList/contactsList'
};

export const PartnersUrls = {
    SAVE_PARTNERS_INFORMATION: 'api/PartnerProfile/save',
    GET_PARTNERS_INFORMATION: 'api/PartnerProfile/partnerinfo',
    GET_PARTNERS_SHOWALL: 'api/PartnerProfile/partners',
    GET_PARTNERS_SEARCH: 'api/PartnerProfile/search',
    SAVE_PARTNERS_ADDRESS: 'api/PartnerProfile/saveaddress',
    GET_PARTNERS_ADDRESS: 'api/PartnerProfile/address',
    DELETE_PARTNERS_ADDRESS: 'api/PartnerProfile/deleteaddress',
    GET_BILLING_ADDRESS: 'api/PartnerProfile/billingaddress',
    SAVE_BILLING_ADDRESS: 'api/PartnerProfile/savebillingaddress',
    GET_SHIPING_ADDRESS: 'api/PartnerProfile/shippingaddress',
    SAVE_SHIPING_ADDRESS: 'api/PartnerProfile/saveshippingaddress',
    SAVE_IDN_GPO_COALITION: 'api/PartnerProfile/purchasingcoalition/save',
    GET_IDN_GPO_COALITION: 'api/PartnerProfile/purchasingcoalition',
    GET_PARTNER_FLAG: 'api/PartnerProfile/GetPartnerFlags',
    SAVE_PARTNER_FLAG: 'api/PartnerProfile/SavePartnerFlags',
    GET_ADDITIONAL_INFORMATION: 'api/PartnerProfile/additionalinfo',
    SAVE_ADDITIONAL_INFORMATION: 'api/PartnerProfile/saveadditionalinfo',
    GET_BILLING_INFO: 'api/PartnerProfile/billinginfo',
    SAVE_BILLING_INFO: 'api/PartnerProfile/billinginfo/save',
    SAVE_PARTNER_PRICING: '/api/PartnerPricing/save',
    GET_PARTNERS_PRICING: '/api/PartnerPricing/getmodelpricing',
    GET_PARTNER_DEPARTMENTS: '/api/PartnerDepartment/department',
    SAVE_PARTNER_DEPARTMENTS: '/api/PartnerDepartment/department/save',

    GET_PARTNER_PRICING: '/api/PartnerPricing/getpartnerpricing',
    SAVE_PARTNERS_PRICING: '/api/PartnerDepartment/department/save',
    DELETE_PARTNERS_PRICING: '/api/PartnerPricing/delete',
    /**
     * Partner Contact List
     */
    GET_PARTNERS_CONTACT_LIST: 'api/PartnersContact/partnercontacts',
    GET_PARTNERS_SINGLE_CONTACT: 'api/PartnersContact/contactinfo',
    SAVE_PARTNER_CONTACT: 'api/PartnersContact/savecontactinfo',
    GET_PARTNER_CONTACT_ADDRESS: 'api/PartnersContact/contactaddress',
    SAVE_PARTNER_CONTACT_ADDRESS: 'api/PartnersContact/savecontactaddress',
    GET_PARTNER_CONTACT_FLAGS: 'api/PartnersContact/contactflags',
    SAVE_PARTNER_CONTACT_FLAGS: 'api/PartnersContact/savecontactflags',
    SEARCH_PARTNER_CONTACT_MAP: 'api/PartnersContact/contactpartners',
    GET_PARTNER_CONTACT_MAP: 'api/PartnersContact/contactmap',
    SAVE_PARTNER_CONTACT_MAP: 'api/PartnersContact/savecontactmap',
    /**
     * Partner Invoice URLs
     */
    GET_PREINVOICEINFO_INFO: 'api/PartnerProfile/GetPreliminaryInvoice',
    SAVE_PREINVOICEINFO_INFO: 'api/PartnerProfile/SavePreliminaryInvoice',
    /**
     * Partner Product Profile
     */
    GET_PREFERED_SEARCH_MODEL: '/api/PartnerPreferredModel/searchmodel',
    GET_PREFERED_MODEL_LIST: '/api/PartnerPreferredModel/preferredmodel',
    GET_PREFERED_MODEL_DETAILS: '/api/PartnerPreferredModel/preferredmodeldetails',
    SAVE_PREFERED_MODEL: '/api/PartnerPreferredModel/preferredmodel/save',
    SAVE_PREFERED_MODEL_DETAILS: '/api/PartnerPreferredModel/preferredmodeldetails/save'
};

export const ServiceInfoUrls = {
    GET_PM_SHEDULE: 'api/ModelServiceInfo/pmschedule',
    POST_PM_SHEDULE: 'api/ModelServiceInfo/pmschedule/save',
    GET_OVP_SHEDULE: 'api/ModelServiceInfo/ovpschedule',
    POST_OVP_SHEDULE: 'api/ModelServiceInfo/ovpschedule/save',
    GET_RECAll: 'api/ModelServiceInfo/recallinfo',
    POST_RECAll: 'api/ModelServiceInfo/recallinfo/save',
    GET_BATTERY: 'api/ModelServiceInfo/batteryinfo',
    POST_BATTERY: 'api/ModelServiceInfo/batteryinfo/save'
};

export const DocumentUrls = {
    GET_DOCUMENT: 'api/Documentation',
    POST_DOCUMENT: 'api/Documentation/add',
    DELETE_DOCUMENT: 'api/Documentation/delete'
};

export const MasterUrls = {
    configurableMenu: 'api/Menu/menudetails',
    getMasterMockup: 'api/Master/GetMasterRecord'
};

export const NotesUrls = {
    GET_NOTE: 'api/Notes/notes',
    POST_NOTE: 'api/Notes/notes/save'
};

export const CalllogUrls = {
    GET_CALL_METADATA: '/api/CallLog/metadata',
    GET_CALL_LOG: 'api/CallLog/getall',
    GET_PREFERRED_MODEL: 'api/PartnerPreferredModel/getall',
    GET_ORDERED_MODEL: 'api/CallLog/orderhistory',
    GET_ORDERED_MODEL_DETAILS: 'api/CallLog/orderhistorydetails',
    ASSIGN_CALL: '/api/CallLog/assign',
    PARTNER_CONTACT_DETAILS: '/api/PartnersContact/primarycontactinfo'
};

export const LocationUrls = {
    GET_BRANCH: '/api/Location/branch/all',
    GET_TERRITORY: '/api/Location/territory/all'
};

