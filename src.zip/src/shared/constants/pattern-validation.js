/* eslint-disable indent */
export const PatternValidation = {

    // Alphanumeric, Periods, spaces, Hash symbols, apostrophes, hyphens allowed
    alphaNumSpecialValidation: /^[a-zA-Z0-9' , . _ # -]*$/,
    // Alphanumeric hyphens, underscores, periods, spaces allowed
    alphaNumSpecialValidationRuleTitle: /^[a-zA-Z0-9 _ . -]*$/,
    numericUpToTwoDecimal: /^\s*(?=.*[0-9])\d*(?:\.\d{1,2})?\s*$/,
    // Atleast one Upper Case Allowed
    OneUpperCaseAtleast: /^[A-Z]*$/,
    alphaNumSpace: /^[0-9a-zA-Z ]+$/,
    alphaNumSpaceDot: /^[0-9a-zA-Z . ]+$/

};

export const customValidation = {
    /**
     * formattedPhone(event, key) formatting phone to (XXX)-XXX-XXXX
     * event is used for passing current input value
     * key is used to pass the input name
     */
    formattedPhone(event) {
        if (!event) { return null; }
        const value = event;

        const input = value.replace(/\D/g, '').substring(0, 10); // First ten digits of input only
        const firstThree = input.substring(0, 3);
        const middleThree = input.substring(3, 6);
        const lastThree = input.substring(6, 10);

        if (lastThree) {
            return `(${firstThree})-${middleThree}-${lastThree}`;
        } else if (middleThree) {
            return `(${firstThree})-${middleThree}`;
        } else if (firstThree) {
            return `(${firstThree})`;
        }
        return input;
    }
    /** -----------END---------- */
};

