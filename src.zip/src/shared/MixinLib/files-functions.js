/* eslint-disable */
// define a mixin object
const commonFunctiions = {
    methods: {
        extImageValidationinLoop(files) {
            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                let ext = file.name.split('.')[1].toLowerCase();
                if (ext !== 'jpeg' && ext !== 'JPEG' && ext !== 'jpg' && ext !== 'JPG' && ext !== 'png' && ext !== 'PNG') {
                    alert('Please upload only jpeg/png format iamges');
                    return false;
                } else {
                    return true;
                }
            }
        },
        sizeImageValidationinLoop(files) {
            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                let filesize = file.size;
                if (filesize > 5242880) {
                    alert('Maximum allowed file size is 5 MB');
                    return false;
                } else {
                    return true;
                }
            }
        },
        sizeFileValidation(files) {
            let filesize = files[0].size;
            if (filesize > 5242880) {
                alert('Maximum allowed file size is 5 MB');
                return false;
            } else {
                return true;
            }
        }
    }
};

export default commonFunctiions;

