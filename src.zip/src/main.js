import Vue from 'vue';
import Axios from 'axios';
import 'bootstrap';
import moment from 'moment';
import '@progress/kendo-theme-default/dist/all.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Vuelidate from 'vuelidate';

import kendo from '@progress/kendo-ui';
import App from './App';
import router from './router';
import store from './store/store';

import './assets/css/all-icon.css';
import './assets/css/animate.css';
import './assets/css/font-awesome.min.css';
import './assets/css/all-font-awesome.css';
import './assets/css/custom.css';
import './assets/css/custom-kendo.css';
import './assets/css/native-grid.css';

Vue.use(store);
Vue.use(Vuelidate);
Vue.config.productionTip = true;
Vue.prototype.$http = Axios;
Vue.filter('formatDate', (value) => {
  if (value) {
    return moment(String(value)).format('MM/DD/YYYY hh:mm');
  }
  return 'MM/DD/YYYY';
});
Vue.filter('formatDateTime', (value) => {
  if (value) {
    return moment(String(value)).format('MM/DD/YYYY hh:mm:ss A');
  }
  return 'MM/DD/YYYY hh:mm:ss A';
});


new Vue({
  router,
  store,
  kendo,
  render: h => h(App)
}).$mount('#app');
