import Dashboard from '../dashboard/Dashboard';

export default [
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: Dashboard
  }
];
