<template>
  <!-- Default form login -->
  <div id="login">
    <h1>Login</h1>
    <label v-if="error" class="error">User Name or Password is incorrect</label>
    <input
      type="text"
      class="form-control"
      name="username"
      v-model="input.username"
      placeholder="email: abc@abc.com"
    />
    <br />
    <input
      type="password"
      class="form-control"
      name="password"
      v-model="input.password"
      placeholder="Password"
    />
    <br />
    <button type="button" class="btn btn-primary" v-on:click="login()">Login</button>
  </div>
  <!-- Default form login -->
</template>

<script>
export default {
  name: 'Login',
  data() {
    return {
      input: {
        username: '',
        password: ''
      },
      error: false
    };
  },
  methods: {
    login() {
      this.error = false;
      this.$store
        .dispatch('LOGIN', {
          email: this.input.username,
          password: this.input.password
        })
        // eslint-disable-next-line no-unused-vars,arrow-parens
        .then(success => {
          this.$emit('loggedIn', true);
          this.$router.push({ name: 'Dashboard' });
        })
        // eslint-disable-next-line no-unused-vars,arrow-parens
        .catch(error => {
          this.$emit('loggedIn', false);
          this.error = true;
        });
    }
  }
};
</script>
<style scoped>
.error {
  background: red;
}
#login {
  width: 500px;
  border: 1px solid #cccccc;
  background-color: #ffffff;
  margin: auto;
  margin-top: 200px;
  padding: 20px;
}
</style>>
