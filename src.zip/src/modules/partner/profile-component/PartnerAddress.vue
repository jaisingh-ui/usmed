<template>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseTwo"
          aria-expanded="false"
          aria-controls="collapseTwo"
        >Partner Address</button>
      </h5>
      <div class="rightInfotext">
        <i class="fa fa-angle-down" data-toggle="collapse" data-target="#collapseTwo"></i>
      </div>
    </div>
    <div
      id="collapseTwo"
      class="collapse"
      aria-labelledby="headingTwo"
      data-parent="#accordion"
      style
    >
      <div class="card-body" v-if="editMode">
        <template v-if="true">
          <div class="row">
            <div class="col-md-12 text-right mb-1 mt-1">
              <div id="savebtn-box" class="mb-1 mt-1 BorderBottom pb-1">
                <button type="button" class="save-btn mr-1" @click="saveAddress()">Save</button>
                <button type="button" class="cancel-btn" @click="cancelClicked()">Cancel</button>
                <!-- <span class="workingBtn">
                  <a href="javascript:void(0)">
                    <i class="fa fa-floppy-o" aria-hidden="true"></i> Save
                  </a>
                </span>-->
                <!-- <span class="workingBtn">
                  <a href="javascript:void(0)">
                    <i class="fa fa-times" aria-hidden="true"></i> Cancel
                  </a>
                </span>-->
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <!--------------------------------------------------->
              <div id="table1" class="edit-associated-block" style="border:none; padding: 0;">
                <!--<h3>Add Associated Model</h3>-->
                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        Address 1
                        <i
                          class="icon-help-round-button"
                          data-container="body"
                          data-toggle="popover"
                          data-placement="right"
                          data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                          data-original-title
                          title
                        ></i>
                      </label>
                      <input
                        type="text"
                        maxlength="200"
                        class="form-control"
                        v-model.trim="partnerAddress.address1"
                      />
                      <div v-if="submitted" class="error-message">
                        <p
                          v-if="!$v.partnerAddress.address1.required"
                        >{{validationMessages.REQUIRED}}</p>
                        <p
                          v-if="!$v.partnerAddress.address1.alphaNumSpecialValidation"
                        >{{validationMessages.INVALIDMODELOPTION}}</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        Address 2
                        <i
                          class="icon-help-round-button"
                          data-container="body"
                          data-toggle="popover"
                          data-placement="right"
                          data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                          data-original-title
                          title
                        ></i>
                      </label>
                      <input
                        type="text"
                        maxlength="200"
                        class="form-control"
                        v-model.trim="partnerAddress.address2"
                      />
                      <div v-if="submitted" class="error-message">
                        <p
                          v-if="!$v.partnerAddress.address2.alphaNumSpecialValidation"
                        >{{validationMessages.INVALIDMODELOPTION}}</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        City
                        <i
                          class="icon-help-round-button"
                          data-container="body"
                          data-toggle="popover"
                          data-placement="right"
                          data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                          data-original-title
                          title
                        ></i>
                      </label>
                      <input
                        type="text"
                        maxlength="60"
                        class="form-control"
                        v-model.trim="partnerAddress.city"
                      />
                      <div v-if="submitted" class="error-message">
                        <p v-if="!$v.partnerAddress.city.required">{{validationMessages.REQUIRED}}</p>
                        <p
                          v-if="!$v.partnerAddress.city.alphawithspace"
                        >{{validationMessages.ALPHA_NUMERIC_SPACES}}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        State
                        <i
                          class="icon-help-round-button"
                          data-container="body"
                          data-toggle="popover"
                          data-placement="right"
                          data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                          data-original-title
                          title
                        ></i>
                      </label>
                      <select
                        id="inputMenu"
                        class="form-control"
                        v-model="partnerAddress.stateId"
                        @change="partnerAddress.countyId = null"
                      >
                        <option value>Select</option>
                        <option
                          v-for="state in stateOptions"
                          :value="state.entityID"
                        >{{ state.entityName }}</option>
                      </select>
                      <div v-if="submitted" class="error-message">
                        <p
                          v-if="!$v.partnerAddress.stateId.required"
                        >{{validationMessages.REQUIRED}}</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        Zip
                        <i
                          class="icon-help-round-button"
                          data-container="body"
                          data-toggle="popover"
                          data-placement="right"
                          data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                          data-original-title
                          title
                        ></i>
                      </label>
                      <input
                        type="text"
                        maxlength="5"
                        class="form-control"
                        v-model.number="partnerAddress.zip"
                      />
                      <div v-if="submitted" class="error-message">
                        <p v-if="!$v.partnerAddress.zip.required">{{validationMessages.REQUIRED}}</p>
                        <p v-if="!$v.partnerAddress.zip.numeric">{{validationMessages.INTEGER}}</p>
                        <p
                          v-if="!$v.partnerAddress.zip.minLen"
                        >{{validationMessages.MIN_LENGTH}} {{$v.partnerAddress.zip.$params.minLen.min}}</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        County
                        <i
                          class="icon-help-round-button"
                          data-container="body"
                          data-toggle="popover"
                          data-placement="right"
                          data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                          data-original-title
                          title
                        ></i>
                      </label>
                      <select id="inputMenu" class="form-control" v-model="partnerAddress.countyId">
                        <option :value="null">Select</option>
                        <option
                          v-for="county in countyOptionsResult"
                          :value="county.entityID"
                        >{{ county.entityName }}</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        Country
                        <i
                          class="icon-help-round-button"
                          data-container="body"
                          data-toggle="popover"
                          data-placement="right"
                          data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                          data-original-title
                          title
                        ></i>
                      </label>
                      <select
                        id="inputMenu"
                        class="form-control"
                        v-model="partnerAddress.countryId"
                      >
                        <option value>Select</option>
                        <option
                          v-for="country in countryOptions"
                          :value="country.entityID"
                        >{{ country.entityName }}</option>
                      </select>
                      <div v-if="submitted" class="error-message">
                        <p
                          v-if="!$v.partnerAddress.countryId.required"
                        >{{validationMessages.REQUIRED}}</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        Fax
                        <i
                          class="icon-help-round-button"
                          data-container="body"
                          data-toggle="popover"
                          data-placement="right"
                          data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                          data-original-title
                          title
                        ></i>
                      </label>
                      <div class="custom-kendo-input">
                        <kendo-maskedtextbox
                          title="phone number"
                          v-model="partnerAddress.fax"
                          mask="(999)-000-0000"
                        ></kendo-maskedtextbox>
                      </div>
                      <div v-if="submitted" class="error-message">
                        <p
                          v-if="!$v.partnerAddress.fax.phoneCustomLimit"
                        >{{validationMessages.MIN_LENGTH}} 10</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        Email
                        <i
                          class="icon-help-round-button"
                          data-container="body"
                          data-toggle="popover"
                          data-placement="right"
                          data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                          data-original-title
                          title
                        ></i>
                      </label>
                      <input
                        type="text"
                        maxlength="100"
                        class="form-control"
                        v-model="partnerAddress.email"
                      />
                      <div v-if="submitted" class="error-message">
                        <p v-if="!$v.partnerAddress.email.required">{{validationMessages.REQUIRED}}</p>
                        <p v-if="!$v.partnerAddress.email.email">{{validationMessages.EMAIL}}</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        Phone
                        <i
                          class="icon-help-round-button"
                          data-container="body"
                          data-toggle="popover"
                          data-placement="right"
                          data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                          data-original-title
                          title
                        ></i>
                      </label>
                      <div class="custom-kendo-input">
                        <kendo-maskedtextbox
                          title="phone number"
                          v-model="partnerAddress.phone"
                          mask="(999)-000-0000"
                        ></kendo-maskedtextbox>
                      </div>
                      <div v-if="submitted" class="error-message">
                        <p
                          v-if="!$v.partnerAddress.phone.phoneCustomLimit"
                        >{{validationMessages.MIN_LENGTH}} 10</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        Extension
                        <i
                          class="icon-help-round-button"
                          data-container="body"
                          data-toggle="popover"
                          data-placement="right"
                          data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                          data-original-title
                          title
                        ></i>
                      </label>
                      <input
                        type="text"
                        maxlength="8"
                        class="form-control"
                        v-model="partnerAddress.ext"
                      />
                      <div v-if="submitted" class="error-message">
                        <p
                          v-if="!$v.partnerAddress.ext.alphaNum"
                        >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!------------------------------------------------------>
          </div>
        </template>
      </div>

      <div id="tableOne" v-else>
        <div class="row">
          <div class="col-md-12">
            <div class="col-lg-4 col-md-6 mb-3">
              <div class="contractsList-block mt-2">
                <div class="row BorderBottom">
                  <div class="col-md-12 text-right mb-1">
                    <div class="standard-box">
                      <button
                        type="button"
                        class="delete-btn mr-1"
                        @click="deletePartnersAddress()"
                      >Delete</button>
                      <button type="button" class="edit-btn" @click="editMode = true">Edit</button>
                      <!-- <span class="workingBtn">
                        <a href="javascript:void(0)">
                          <i class="icon-delete" aria-hidden="true"></i> Delete
                        </a>
                      </span>
                      <span class="workingBtn">
                        <a href="javascript:void(0)" class="editOne-addNew">
                          <i class="icon-edit-button-icon" aria-hidden="true"></i> Edit
                        </a>
                      </span>-->
                    </div>
                  </div>
                </div>

                <div class="contact-body mt-1">
                  <strong>Address</strong>
                  <br />
                  {{partnerAddress.address1}}, {{partnerAddress.address2}}
                  <br />
                  {{partnerAddress.city}}, {{partnerAddress.stateName}}
                  <br />
                  {{partnerAddress.zip}} {{partnerAddress.countryName}}
                  <br />
                  <br />
                  <strong>Phone (Ext.):</strong>
                  {{partnerAddress.phone}} ({{partnerAddress.ext}})
                  <br />
                  <strong>Fax:</strong>
                  {{partnerAddress.fax}}
                  <br />
                  <strong>Email:</strong>
                  {{partnerAddress.email}}
                </div>
              </div>
            </div>
          </div>

          <!-------------------------------------------->
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
import Vue from 'vue';
import { InputsInstaller } from '@progress/kendo-inputs-vue-wrapper';
import { required, email, numeric, minLength, alphaNum, helpers } from 'vuelidate/lib/validators';
import { PatternValidation, customValidation } from '../../../shared/constants/pattern-validation';
import { showToast } from '../../../shared/services/toast-service';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import partnerService from '../services/partners-service';
import { PartnersUrls, MasterUrls } from '../../../shared/constants/urls';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

Vue.use(InputsInstaller);

const alphaNumSpecialValidation = helpers.regex('alphaNumSpecialValidation', PatternValidation.alphaNumSpecialValidation);
const alphawithspace = helpers.regex('alphawithspace', /^[0-9a-zA-Z ]+$/);
const phoneCustomLimit = value => !helpers.req(value) || value.replace(/\D/g, '').substring(0, 10).length === 10;

export default {
  data() {
    return {
      editMode: true,
      validationMessages: VALIDATION_MESSAGE,
      customValidation,
      submitted: false,
      partnerAddress: this.partnersFormField(),
      stateOptions: [],
      countyDataOptions: [],
      countyOptions: [],
      countryOptions: []
    };
  },
  validations: {
    partnerAddress: {
      address1: { required, alphaNumSpecialValidation },
      address2: { alphaNumSpecialValidation },
      city: { required, alphawithspace },
      stateId: { required },
      countryId: { required },
      zip: { required, numeric, minLen: minLength(5) },
      email: { required, email },
      fax: { phoneCustomLimit },
      phone: { phoneCustomLimit },
      ext: { alphaNum }
    }
  },
  created() {
    this.getDropdownData();
    if (this.$route.params.id) {
      this.partnerAddress.partnerId = this.$route.params.id;
      this.getPartnersAddress(this.partnerAddress.partnerId);
    }
    // console.log(this.partnerAddress, 'kkkkkkkkkkkkkkk');
  },
  computed: {
    countyOptionsResult() {
      const stateId = this.partnerAddress.stateId;
      this.countyOptions = this.countyDataOptions.filter(item => stateId === item.countyStateID);
      return this.countyOptions;
    }
  },
  methods: {
    saveAddress() {
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      }
      if (this.$route.params.id) this.partnerAddress.partnerId = parseInt(this.$route.params.id, 10);
      delete this.partnerAddress.countryName;
      delete this.partnerAddress.countyName;
      delete this.partnerAddress.stateName;
      // console.log(this.partnerAddress);
      partnerService.postPartnersData(`${PartnersUrls.SAVE_PARTNERS_ADDRESS}`, this.partnerAddress).then(res => {
        // console.log(res, '===============partners address===============');
        const result = res.data.data;
        if (result) {
          showToast('success');
          this.partnerAddress.addressId = result;
          this.getPartnersAddress(this.partnerAddress.partnerId);
        }
      });
      this.editMode = false;
    },
    deletePartnersAddress() {
      const answer = window.confirm('Are you sure, you want to delete?');
      if (answer) {
        const body = {
          addressId: this.partnerAddress.addressId,
          partnerId: this.partnerAddress.partnerId,
          userId: this.partnerAddress.userId
        };
        partnerService.postPartnersData(`${PartnersUrls.DELETE_PARTNERS_ADDRESS}`, body).then(() => {
          // console.log(res, '===============delete partners address===============');
          this.editMode = true;
          this.submitted = false;
          this.$v.$reset();
          this.partnerAddress = this.partnersFormField();
        });
      }
    },

    getPartnersAddress(id) {
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_ADDRESS}?partnerId=${id}`).then(res => {
        const result = res.data.data;
        if (result) {
          this.partnerAddress = result;
          if (result.fax) this.formattedPhone(result.fax, 'fax');
          if (result.phone) this.formattedPhone(result.phone, 'phone');
          if (this.partnerAddress.addressId) this.editMode = false;
          console.log(result, '========get partner address=============', res, this.partnerAddress);
        } else {
          this.partnerAddress = this.partnersFormField();
        }
      });
    },
    getDropdownData() {
      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=State%7CCountry%7CCounty`).then(res => {
        const result = res.data.data;
        this.stateOptions = result.State;
        this.countyDataOptions = result.County;
        this.countryOptions = result.Country;
        // console.log(res, res.data, '=====================', this.countyDataOptions);
      });
    },
    cancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        if (this.partnerAddress.partnerId) {
          this.getPartnersAddress(this.partnerAddress.partnerId);
          this.editMode = false;
        } else {
          this.submitted = false;
          this.$v.$reset();
          this.partnerAddress = this.partnersFormField();
        }
      }
      return false;
    },
    partnersFormField() {
      return {
        addressId: 0,
        address1: '',
        address2: '',
        city: '',
        stateId: '',
        zip: null,
        countyId: null,
        countryId: 1,
        fax: '',
        email: '',
        phone: '',
        ext: '',
        userId: 0
      };
    },
    /**
     * formattedPhone(event, key) formatting phone to (XXX)-XXX-XXXX
     * event is used for passing current input value
     * key is used to pass the input name
     */
    formattedPhone(event, key) {
      this.partnerAddress[key] = this.customValidation.formattedPhone(event);
    }
    /** -----------END---------- */
  }
};
</script>
<style>
.custom-kendo-input .k-maskedtextbox {
  width: 100%;
}
.custom-kendo-input span input {
  height: calc(1.5em + 0.75rem + 2px);
  padding: 0.375rem 0.75rem;
  font-size: 0.875rem;
  font-weight: 400;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.custom-kendo-input span input:focus {
  color: #495057;
  background-color: #fff;
  border-color: #80bdff;
  outline: 0;
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}
</style>