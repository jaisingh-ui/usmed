<template>
  <div class="card">
    <div class="card-header" id="headingEleven">
      <h5 class="mb-0">
        <button
          class="btn btn-link"
          data-toggle="collapse"
          data-target="#collapseEleven"
          aria-expanded="true"
          aria-controls="collapseEleven"
        >Invoice Information</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseEleven"
          aria-expanded="true"
        ></i>
      </div>
    </div>
    <div
      id="collapseEleven"
      class="collapse"
      aria-labelledby="headingEleven"
      data-parent="#accordion"
      style
    >
      <div class="card-body">
        <div v-if="editMode==false" class="row border-bottom">
          <div class="col-md-12 text-right mb-1 pt-1">
            <button v-if="!editMode" type="button" class="edit-btn" @click="editMode = true">Edit</button>
          </div>
        </div>
        <div v-if="editMode==true" class="row border-bottom">
          <div class="col-md-12 text-right mb-1 pt-1">
            <button type="button" class="save-btn mr-1" @click="handleSave">Save</button>
            <button type="button" class="cancel-btn" @click="handleCancel">Cancel</button>
          </div>
        </div>
        <div class="row">
          <div class="col-md-5">
            <div class="form-group">
              <label for="customCheck12"></label>
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="editMode==false"
                    @click="updateFields"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck12"
                    :checked="preliminaryInvoiceInformation.isPreliminaryInvoiceReq"
                  />
                  <label
                    class="custom-control-label"
                    for="customCheck12"
                  >Requires Preliminary Invoice</label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-5">
            <div class="form-group">
              <label>
                Frequency of Preliminary Invoice
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title=" Frequency of Preliminary Invoice"
                ></i>
              </label>
              <select
                :disabled="editMode==false || preliminaryInvoiceInformation.isPreliminaryInvoiceReq==false"
                id="inputState"
                class="form-control"
                v-model="preliminaryInvoiceInformation.preliminaryInvoiceFrequency"
              >
                <option selected value>Select</option>
                <option value="1">Monthly</option>
                <option value="2">Weekly</option>
              </select>
              <small
                v-if="!$v.preliminaryInvoiceInformation.preliminaryInvoiceFrequency.checkEmpty"
                class="error-message"
              >{{validationMessages.REQUIRED}}</small>
            </div>
          </div>
        </div>
        <div class="row">
          <!-- left panel code -->

          <div class="col-md-5">
            <div
              class="row"
              v-for="(preEmail,index) in $v.preliminaryInvoiceInformation.preInvoiceEmail.$each.$iter"
            >
              <div class="col-md-10">
                <div class="form-group">
                  <label v-show="index == 0">
                    Email Address for Preliminary Invoice
                    <i
                      class="fa fa-info-circle"
                      aria-hidden="true"
                      title="Email Address for Preliminary Invoice"
                    ></i>
                  </label>
                  <input
                    :ref="'ele_'+index"
                    :disabled="editMode===false || preliminaryInvoiceInformation.isPreliminaryInvoiceReq===false"
                    v-model.trim="preEmail.preliminaryEmailID.$model"
                    type="text"
                    class="form-control"
                    id
                    placeholder
                    value
                  />
                  <small
                    v-if="!preEmail.preliminaryEmailID.email"
                    class="error-message"
                  >{{validationMessages.EMAIL}}</small>
                  <small
                    v-if="!preEmail.preliminaryEmailID.isPreEmailDuplicate"
                    class="error-message"
                  >{{validationMessages.EMAIL_UNIQUE}}</small>
                  <small
                    v-if="!preEmail.preliminaryEmailID.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</small>
                </div>
              </div>
              <div class="col-md-2 text-left">
                <div
                  :class="{'form-group': true, 'mt-1':index !=0,'mt-4 pt-2':index==0}"
                  v-if="index==preliminaryInvoiceInformation.preInvoiceEmail.length-1"
                >
                  <a
                    href="javascript:void(0);"
                    @click.prevent="!editMode || !preliminaryInvoiceInformation.isPreliminaryInvoiceReq? '#':addPreInvElements(index)"
                  >
                    <i class="icon-model-options AddDelBtn"></i>
                  </a>
                </div>
                <div v-else :class="{'form-group': true, 'mt-1':index !=0,'mt-4 pt-2':index==0}">
                  <a
                    href="#"
                    @click.prevent="!editMode || !preliminaryInvoiceInformation.isPreliminaryInvoiceReq? '#':deletePreInvElements(index)"
                  >
                    <i
                      aria-hidden="true"
                      :class="{'AddDelBtn':!editMode || !preliminaryInvoiceInformation.isPreliminaryInvoiceReq, 'fas fa-trash AddDelBtn':true, 'custom-delete-btn': !preEmail.$model.isActive}"
                    ></i>
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-5">
            <!-- right panel code -->
            <div
              class="row"
              v-for="(authEmail,index) in $v.preliminaryInvoiceInformation.authPreInvoiceEmail.$each.$iter"
            >
              <div class="col-md-10">
                <div class="form-group">
                  <label v-show="index == 0">
                    Email Address for Authorized Invoice
                    <i
                      class="fa fa-info-circle"
                      aria-hidden="true"
                      title="Email Address for Authorized Invoice"
                    ></i>
                  </label>
                  <input
                    type="text"
                    :disabled="editMode===false"
                    v-model.trim="authEmail.preliminaryEmailID.$model"
                    class="form-control"
                    id
                    placeholder
                    value
                  />
                  <small
                    v-if="!authEmail.preliminaryEmailID.email"
                    class="error-message"
                  >{{validationMessages.EMAIL}}</small>
                  <small
                    v-if="!authEmail.preliminaryEmailID.isAuthEmailDuplicate"
                    class="error-message"
                  >{{validationMessages.EMAIL_UNIQUE}}</small>
                  <small
                    v-if="!authEmail.preliminaryEmailID.checkEmpty"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</small>
                </div>
              </div>
              <div class="col-md-2 text-left">
                <div
                  :class="{'form-group': true, 'mt-1':index !=0,'mt-4 pt-2':index==0}"
                  v-if="index==preliminaryInvoiceInformation.authPreInvoiceEmail.length-1"
                >
                  <a
                    href="javascript:void(0);"
                    @click.prevent="!editMode? '#':addAuthInvElements(index)"
                  >
                    <i class="icon-model-options AddDelBtn"></i>
                  </a>
                </div>
                <div v-else :class="{'form-group': true, 'mt-1':index !=0,'mt-4 pt-2':index==0}">
                  <a href="#" @click.prevent="!editMode? '#':deleteAuthInvElements(index)">
                    <i
                      aria-hidden="true"
                      :class="{'AddDelBtn':!editMode, 'fas fa-trash AddDelBtn':true, 'custom-delete-btn': !authEmail.$model.isActive}"
                    ></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { email } from 'vuelidate/lib/validators';
import { PartnersUrls } from '../../../shared/constants/urls';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import partnerService from '../services/partners-service';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

export default {
  props: {},
  data() {
    return {
      validationMessages: VALIDATION_MESSAGE,
      editMode: false,
      authInvEmailError: false,
      preInvEmailError: false,
      preliminaryInvoiceInformation: {
        partnerId: 1,
        isPreliminaryInvoiceReq: false,
        preliminaryInvoiceFrequency: 0,
        preInvoiceEmail: [
          {
            id: 0,
            preliminaryEmailID: '',
            isAuthorizedInvoiceEmail: false,
            isActive: true
          }
        ],
        authPreInvoiceEmail: [
          {
            id: 0,
            preliminaryEmailID: '',
            isAuthorizedInvoiceEmail: true,
            isActive: true
          }
        ],
        isActive: true,
        userId: 0
      }
    };
  },
  methods: {
    addPreInvElements(index) {
      console.log('in add');
      if (this.preliminaryInvoiceInformation.preInvoiceEmail[index].preliminaryEmailID !== '' && !this.preInvEmailError) {
        console.log('in add2');
        this.preliminaryInvoiceInformation.preInvoiceEmail.push({
          id: 0,
          preliminaryEmailID: '',
          isAuthorizedInvoiceEmail: false,
          isActive: true
        });
      }
    },
    deletePreInvElements(index) {
      if (this.preliminaryInvoiceInformation.preInvoiceEmail[index] !== 'undefined') {
        if (this.preliminaryInvoiceInformation.preInvoiceEmail[index].id !== 0) {
          this.preliminaryInvoiceInformation.preInvoiceEmail[index].isActive = !this.preliminaryInvoiceInformation.preInvoiceEmail[index].isActive;
        } else {
          this.preliminaryInvoiceInformation.preInvoiceEmail.splice(index, 1);
          if (this.preliminaryInvoiceInformation.preInvoiceEmail.length === 0) {
            this.preliminaryInvoiceInformation.preInvoiceEmail.push({
              id: 0,
              preliminaryEmailID: '',
              isAuthorizedInvoiceEmail: false,
              isActive: true
            });
          }
        }
      }
    },
    addAuthInvElements(index) {
      if (this.preliminaryInvoiceInformation.authPreInvoiceEmail[index].preliminaryEmailID !== '' && !this.authInvEmailError) {
        this.preliminaryInvoiceInformation.authPreInvoiceEmail.push({
          id: 0,
          preliminaryEmailID: '',
          isAuthorizedInvoiceEmail: true,
          isActive: true
        });
      }
    },
    deleteAuthInvElements(index) {
      if (this.preliminaryInvoiceInformation.authPreInvoiceEmail[index] !== undefined) {
        if (this.preliminaryInvoiceInformation.authPreInvoiceEmail[index].id !== 0) {
          this.preliminaryInvoiceInformation.authPreInvoiceEmail[index].isActive = !this.preliminaryInvoiceInformation.authPreInvoiceEmail[index].isActive;
        } else {
          this.preliminaryInvoiceInformation.authPreInvoiceEmail.splice(index, 1);
          if (this.preliminaryInvoiceInformation.authPreInvoiceEmail.length === 0) {
            this.preliminaryInvoiceInformation.authPreInvoiceEmail.push({
              id: 0,
              preliminaryEmailID: '',
              isAuthorizedInvoiceEmail: true,
              isActive: true
            });
          }
        }
      }
    },
    checkError(eType, e) {
      console.log('in blur', e);
      console.log(this.preliminaryInvoiceInformation.preInvoiceEmail.length);
      this.$v.$touch();
      this.authInvEmailError = this.$v.preliminaryInvoiceInformation.authPreInvoiceEmail.$invalid;
      this.preInvEmailError = this.$v.preliminaryInvoiceInformation.preInvoiceEmail.$invalid;

      // Code to remove blank boxes if user leave in between the rows for pre and auth emails

      let uniqueObject = [];

      if (eType === 'pre') {
        // eslint-disable-next-line no-plusplus
        if (this.preliminaryInvoiceInformation.preInvoiceEmail.length > 1) {
          // eslint-disable-next-line no-plusplus
          for (let i = 0; i < this.preliminaryInvoiceInformation.preInvoiceEmail.length; i++) {
            if (
              this.preliminaryInvoiceInformation.preInvoiceEmail[i].id === 0 &&
              this.preliminaryInvoiceInformation.preInvoiceEmail[i].preliminaryEmailID === ''
            ) {
              uniqueObject.push(i);
            }
          }

          // eslint-disable-next-line no-plusplus
          for (let i = uniqueObject.length - 1; i >= 0; i--) {
            if (this.preliminaryInvoiceInformation.preInvoiceEmail.length > 1) {
              this.preliminaryInvoiceInformation.preInvoiceEmail.splice(uniqueObject[i], 1);
            }
          }
          if (this.preliminaryInvoiceInformation.preInvoiceEmail[this.preliminaryInvoiceInformation.preInvoiceEmail.length - 1].preliminaryEmailID !== '') {
            this.preliminaryInvoiceInformation.preInvoiceEmail.push({
              id: 0,
              preliminaryEmailID: '',
              isAuthorizedInvoiceEmail: false,
              isActive: true
            });
          }
        }
      }

      /* if (!this.preInvEmailError) {
        this.preliminaryInvoiceInformation.preInvEmail.push({
          id: 0,
          preliminaryEmailID: '',
          isAuthorizedInvoiceEmail: false,
          isActive: true
        });
      } */

      uniqueObject = [];
      if (eType === 'auth') {
        // eslint-disable-next-line no-plusplus
        for (let i = 0; i < this.preliminaryInvoiceInformation.authPreInvoiceEmail.length; i++) {
          if (
            this.preliminaryInvoiceInformation.authPreInvoiceEmail[i].id === 0 &&
            this.preliminaryInvoiceInformation.authPreInvoiceEmail[i].preliminaryEmailID === ''
          ) {
            uniqueObject.push(i);
          }
        }

        // eslint-disable-next-line no-plusplus
        for (let i = uniqueObject.length - 1; i >= 0; i--) {
          if (this.preliminaryInvoiceInformation.authPreInvoiceEmail.length > 1) {
            this.preliminaryInvoiceInformation.authPreInvoiceEmail.splice(uniqueObject[i], 1);
          }
        }
        if (
          this.preliminaryInvoiceInformation.authPreInvoiceEmail[this.preliminaryInvoiceInformation.authPreInvoiceEmail.length - 1].preliminaryEmailID !== ''
        ) {
          this.preliminaryInvoiceInformation.authPreInvoiceEmail.push({
            id: 0,
            preliminaryEmailID: '',
            isAuthorizedInvoiceEmail: false,
            isActive: true
          });
        }
      }
    },
    updateFields() {
      this.preliminaryInvoiceInformation.isPreliminaryInvoiceReq = !this.preliminaryInvoiceInformation.isPreliminaryInvoiceReq;
      /* this.preliminaryInvoiceInformation.preliminaryInvoiceFrequency = null;
      this.preliminaryInvoiceInformation.preInvEmail = [
        {
          id: 0,
          preliminaryEmailID: '',
          isAuthorizedInvoiceEmail: false,
          isActive: true
        }
      ]; */
    },
    handleCancel() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.editMode = false;
        if (this.$route.params.id) {
          this.getPreliminaryInvoiceInformation(this.$route.params.id);
        }
        this.$v.$reset();
      }
      return false;
    },
    handleSave() {
      this.$emit('onShowHideLoader', true);
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        this.$emit('onShowHideLoader', false);
        return;
      }

      this.preliminaryInvoiceInformation.partnerId = parseInt(this.preliminaryInvoiceInformation.partnerId, 10);
      this.preliminaryInvoiceInformation.preliminaryInvoiceFrequency = parseInt(this.preliminaryInvoiceInformation.preliminaryInvoiceFrequency, 10);
      // call API to save data to DB
      const delPreData = this.preliminaryInvoiceInformation.preInvoiceEmail.filter(item => item.isActive === false);
      this.deletedPreRecord = delPreData.length;
      const delAuthData = this.preliminaryInvoiceInformation.authPreInvoiceEmail.filter(item => item.isActive === false);
      this.deletedAuthRecord = delAuthData.length;
      if (this.deletedPreRecord !== 0 || this.deletedAuthRecord !== 0) {
        let message = '';
        if (this.deletedPreRecord !== 0 && this.deletedAuthRecord !== 0) {
          message = `${this.deletedPreRecord} Preliminary and ${this.deletedAuthRecord} Authorized `;
        } else if (this.deletedPreRecord !== 0) {
          message = `${this.deletedPreRecord} Preliminary `;
        } else {
          message = `${this.deletedAuthRecord} Authorized `;
        }
        // eslint-disable-next-line no-alert
        const answer = window.confirm(`${message} ${this.validationMessages.INPUTDELETERECORD}`);
        if (answer) {
          this.savePreliminaryInformation();
        } else {
          this.$emit('onShowHideLoader', false);
        }
      } else {
        this.savePreliminaryInformation();
      }
    },
    savePreliminaryInformation() {
      if (this.preliminaryInvoiceInformation.preInvoiceEmail[this.preliminaryInvoiceInformation.preInvoiceEmail.length - 1].preliminaryEmailID === '') {
        this.preliminaryInvoiceInformation.preInvoiceEmail.splice(this.preliminaryInvoiceInformation.preInvoiceEmail.length - 1, 1);
      }
      if (this.preliminaryInvoiceInformation.authPreInvoiceEmail[this.preliminaryInvoiceInformation.authPreInvoiceEmail.length - 1].preliminaryEmailID === '') {
        this.preliminaryInvoiceInformation.authPreInvoiceEmail.splice(this.preliminaryInvoiceInformation.authPreInvoiceEmail.length - 1, 1);
      }
      if (isNaN(this.preliminaryInvoiceInformation.preliminaryInvoiceFrequency)) {
        this.preliminaryInvoiceInformation.preliminaryInvoiceFrequency = 0;
      }
      // eslint-disable-next-line arrow-parens
      partnerService.postPartnersDataAction(`${PartnersUrls.SAVE_PREINVOICEINFO_INFO}`, this.preliminaryInvoiceInformation).then(res => {
        if (res) {
          this.$emit('onShowHideLoader', false);
          this.submitted = false;
          this.editMode = false;
          showToast('success');
          this.getPreliminaryInvoiceInformation(this.preliminaryInvoiceInformation.partnerId);
        }
      });
    },
    getPreliminaryInvoiceInformation(partnerId) {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PREINVOICEINFO_INFO}?partnerId=${partnerId}`).then(res => {
        if (res.data !== null) {
          this.preliminaryInvoiceInformation = res.data.data;

          if (res.data.data.preInvoiceEmail) {
            this.preliminaryInvoiceInformation.preInvoiceEmail.push({
              id: 0,
              preliminaryEmailID: '',
              isAuthorizedInvoiceEmail: false,
              isActive: true
            });
          }
          if (res.data.data.authPreInvoiceEmail) {
            this.preliminaryInvoiceInformation.authPreInvoiceEmail.push({
              id: 0,
              preliminaryEmailID: '',
              isAuthorizedInvoiceEmail: true,
              isActive: true
            });
          }
        }
      });
    }
  },
  async created() {
    if (this.$route.params.id) {
      this.getPreliminaryInvoiceInformation(this.$route.params.id);
    }
  },
  validations: {
    preliminaryInvoiceInformation: {
      preInvoiceEmail: {
        $each: {
          preliminaryEmailID: {
            email,
            required: function checkEmpty(value, emailObject) {
              console.log(this.$refs);
              console.log(this, 'this herer');
              let reqValue = true;
              if (this.preliminaryInvoiceInformation.isPreliminaryInvoiceReq === true) {
                if (value === '' && emailObject.id !== 0) {
                  reqValue = false;
                } else if (
                  this.preliminaryInvoiceInformation &&
                  emailObject.id === 0 &&
                  this.preliminaryInvoiceInformation.preInvoiceEmail.length === 1 &&
                  this.preliminaryInvoiceInformation.preInvoiceEmail[0].preliminaryEmailID.trim() === ''
                ) {
                  reqValue = false;
                }
              }

              return reqValue;
            },
            isPreEmailDuplicate(name, emailItem) {
              const emailIndex = this.preliminaryInvoiceInformation.preInvoiceEmail.findIndex(prod => prod.preliminaryEmailID === name);
              let isEmailDuplicate = true;
              this.preliminaryInvoiceInformation.preInvoiceEmail.forEach((emailObject, index) => {
                if (index !== emailIndex) {
                  console.log('rahul', emailObject);
                  if (emailObject.preliminaryEmailID.trim() === emailItem.preliminaryEmailID.trim() && emailItem.preliminaryEmailID.trim() !== '') {
                    isEmailDuplicate = false;
                  }
                }
              });
              return isEmailDuplicate;
            }
          }
        }
      },
      authPreInvoiceEmail: {
        $each: {
          preliminaryEmailID: {
            email,
            checkEmpty(value, emailObject) {
              if (value === '' && emailObject.id !== 0) {
                return false;
              }
              return true;
            },
            isAuthEmailDuplicate(name, emailItem) {
              const emailIndex = this.preliminaryInvoiceInformation.authPreInvoiceEmail.findIndex(prod => prod.preliminaryEmailID === name);
              let isEmailDuplicate = true;
              this.preliminaryInvoiceInformation.authPreInvoiceEmail.forEach((emailObject, index) => {
                if (index !== emailIndex) {
                  if (emailObject.preliminaryEmailID.trim() === emailItem.preliminaryEmailID.trim() && emailItem.preliminaryEmailID.trim() !== '') {
                    isEmailDuplicate = false;
                  }
                }
              });
              return isEmailDuplicate;
            }
          }
        }
      },
      preliminaryInvoiceFrequency: {
        checkEmpty(value, data) {
          if (data.isPreliminaryInvoiceReq === true && (value === null || value === '' || value === 0)) {
            return false;
          }
          return true;
        }
      }
    }
  }
};
</script>