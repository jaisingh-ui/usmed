<template>
  <CommonBillingShipping
    :heading="heading"
    :acordianId="acordianId"
    :editMode="editMode"
    :saveAddressUrl="saveAddressUrl"
    :getAddressUrl="getAddressUrl"
    @onEditAddress="editMode = true"
    @onSaveAddress="editMode = false;"
    @onCancelClicked="editMode = false;"
    @onAddNewAddressClicked="editMode = true;"
  ></CommonBillingShipping>
</template>
<script>
/* eslint-disable */
import CommonBillingShipping from './CommonBillingShipping';
import partnerService from '../services/partners-service';
import { PartnersUrls } from '../../../shared/constants/urls';

export default {
  components: {
    CommonBillingShipping
  },
  data() {
    return {
      heading: 'Billing Address',
      saveAddressUrl: PartnersUrls.SAVE_BILLING_ADDRESS,
      getAddressUrl: PartnersUrls.GET_BILLING_ADDRESS,
      editMode: false,
      acordianId: 'billingAddress1'
    };
  }
};
</script>