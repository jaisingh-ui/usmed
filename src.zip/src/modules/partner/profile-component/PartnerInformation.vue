<template>
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button
          class="btn btn-link"
          data-toggle="collapse"
          data-target="#collapseOne"
          aria-expanded="true"
          aria-controls="collapseOne"
        >Partner Information</button>
      </h5>
      <div class="rightInfotext">
        <i class="fa fa-angle-down" data-toggle="collapse" data-target="#collapseOne"></i>
      </div>
    </div>

    <div
      id="collapseOne"
      class="collapse show"
      aria-labelledby="headingOne"
      data-parent="#accordion"
    >
      <div class="card-body">
        <div class="row">
          <div class="col-md-12 text-right mb-1 mt-1">
            <button v-if="editMode" type="button" class="edit-btn" @click="editMode = false">Edit</button>
            <div v-else>
              <button type="button" class="save-btn mr-1" @click="savePartnersInformation()">Save</button>
              <button type="button" class="cancel-btn" @click="cancelClicked()">Cancel</button>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Partner Name
                <i
                  class="icon-help-round-button"
                  data-container="body"
                  data-toggle="popover"
                  data-placement="right"
                  data-content="Help Text Here"
                  data-original-title
                  title
                ></i>
              </label>
              <div class="input-group">
                <input
                  type="text"
                  class="form-control"
                  :disabled="editMode"
                  maxlength="400"
                  v-model.trim="partnerInformation.partnerName"
                />
              </div>
              <div v-if="submitted" class="error-message">
                <div
                  v-if="!$v.partnerInformation.partnerName.required"
                >{{validationMessages.REQUIRED}}</div>
                <div
                  v-if="!$v.partnerInformation.partnerName.alphaNumSpecialValidation"
                >{{validationMessages.INVALIDMODELOPTION}}</div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Legal Name
                <i
                  class="icon-help-round-button"
                  data-container="body"
                  data-toggle="popover"
                  data-placement="right"
                  data-content="Help Text Here"
                  data-original-title
                  title
                ></i>
              </label>
              <input
                type="text"
                class="form-control"
                :disabled="editMode"
                maxlength="400"
                v-model="partnerInformation.legalName"
              />
              <div v-if="submitted" class="error-message">
                <div
                  v-if="!$v.partnerInformation.legalName.alphaNumSpecialValidation"
                >{{validationMessages.INVALIDMODELOPTION}}</div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Partner Type
                <i
                  class="icon-help-round-button"
                  data-container="body"
                  data-toggle="popover"
                  data-placement="right"
                  data-content="Help Text Here"
                  data-original-title
                  title
                ></i>
              </label>
              <select
                id="inputState"
                class="form-control"
                :disabled="editMode"
                v-model="partnerInformation.partnerTypeId"
              >
                <option value>Select</option>
                <option
                  v-for="pTypeOption in partnerTypeOptions"
                  :value="pTypeOption.entityID"
                >{{ pTypeOption.entityName }}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.partnerInformation.partnerTypeId.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Time Zone
                <i
                  class="icon-help-round-button"
                  data-container="body"
                  data-toggle="popover"
                  data-placement="right"
                  data-content="Help Text Here"
                  data-original-title
                  title
                ></i>
              </label>
              <select
                id="inputState"
                :disabled="editMode"
                class="form-control"
                v-model="partnerInformation.timeZoneId"
              >
                <option value>Select</option>
                <option
                  v-for="tZoneOption in timeZoneOptions"
                  :value="tZoneOption.entityID"
                >{{ tZoneOption.entityName }}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p v-if="!$v.partnerInformation.timeZoneId.required">{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Status
                <i
                  class="icon-help-round-button"
                  data-container="body"
                  data-toggle="popover"
                  data-placement="right"
                  data-content="Help Text Here"
                  data-original-title
                  title
                ></i>
              </label>
              <select
                id="inputState"
                class="form-control"
                :disabled="editMode || !partnerInformation.partnerId"
                v-model="partnerInformation.statusId"
                @change="getActivationDate()"
              >
                <option value>Select</option>
                <option
                  v-for="statusOption in statusOptions"
                  :value="statusOption.entityID"
                >{{ statusOption.entityName }}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p v-if="!$v.partnerInformation.statusId.required">{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Activation Date
                <i
                  class="icon-help-round-button"
                  data-container="body"
                  data-toggle="popover"
                  data-placement="right"
                  data-content="Help Text Here"
                  data-original-title
                  title
                ></i>
              </label>
              <div class="input-group">
                <!-- <input
                  :readonly="true"
                  :disabled="editMode"
                  type="text"
                  class="form-control"
                  v-model="partnerInformation.activationDate"
                />-->
                <kendo-datepicker
                  :disabled="editMode ? true : partnerInformation.statusId !== 1"
                  class="form-control custom-calender"
                  :date-input="true"
                  :max="maxDate"
                  :format="'MM/dd/yyyy'"
                  v-model="partnerInformation.activationDate"
                  ref="picker"
                ></kendo-datepicker>
                <!-- <div class="input-group-prepend">
                  <span class="input-group-text">
                    <i class="fa fa-calendar" aria-hidden="true"></i>
                  </span>
                </div>-->
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Number of Beds
                <i
                  class="icon-help-round-button"
                  data-container="body"
                  data-toggle="popover"
                  data-placement="right"
                  data-content="Help Text Here"
                  data-original-title
                  title
                ></i>
              </label>
              <input
                type="text"
                class="form-control"
                :disabled="editMode"
                v-model.number="partnerInformation.numberOfBeds"
              />
              <div v-if="submitted" class="error-message">
                <p v-if="!$v.partnerInformation.numberOfBeds.numeric">{{validationMessages.INTEGER}}</p>
                <p
                  v-if="!$v.partnerInformation.numberOfBeds.range"
                >{{validationMessages.BETWEEN}} {{$v.partnerInformation.numberOfBeds.$params.range.min}} to {{$v.partnerInformation.numberOfBeds.$params.range.max}}</p>
              </div>
            </div>
          </div>

          <div class="col-md-4" v-if="partnerInformation.statusId === 4">
            <div class="form-group">
              <label>
                Reason for Inactive Status
                <i
                  class="icon-help-round-button"
                  data-container="body"
                  data-toggle="popover"
                  data-placement="right"
                  data-content="Help Text Here"
                  data-original-title
                  title
                ></i>
              </label>
              <select
                id="inputMenu"
                :disabled="partnerInformation.statusId !== 4 || editMode"
                class="form-control"
                v-model="partnerInformation.inactiveReasonId"
              >
                <option :value="null">Select</option>
                <option
                  v-for="reasonStatusOption in reasonForInactiveOptions"
                  :value="reasonStatusOption.entityID"
                >{{ reasonStatusOption.entityName }}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.partnerInformation.inactiveReasonId.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import Vue from 'vue';
import { required, requiredIf, between, numeric, helpers } from 'vuelidate/lib/validators';
import { showToast } from '../../../shared/services/toast-service';
import { PatternValidation } from '../../../shared/constants/pattern-validation';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import partnerService from '../services/partners-service';
import { PartnersUrls, MasterUrls } from '../../../shared/constants/urls';
import $ from 'jquery';

import { showWindowConfrim } from '../../../shared/services/window-confrim';

const alphaNumSpecialValidation = helpers.regex('alphaNumSpecialValidation', PatternValidation.alphaNumSpecialValidation);

export default {
  data() {
    return {
      validationMessages: VALIDATION_MESSAGE,
      submitted: false,
      editMode: false,
      maxDate: new Date(),
      activationDateDummy: null,
      partnerInformation: this.createPartnerInfoForm(),
      partnerTypeOptions: [],
      timeZoneOptions: [],
      statusOptions: [],
      reasonForInactiveOptions: []
    };
  },
  validations: {
    partnerInformation: {
      partnerName: { required, alphaNumSpecialValidation },
      legalName: { alphaNumSpecialValidation },
      partnerTypeId: { required },
      timeZoneId: { required },
      statusId: { required },
      numberOfBeds: { numeric, range: between(1, 10000) },
      inactiveReasonId: {
        // eslint-disable-next-line arrow-parens
        required: requiredIf(vm => {
          if (vm.statusId === 4) {
            return true;
          }
          return false;
        })
      }
    }
  },
  created() {
    this.getDropdownData();
    if (this.$route.params.id) {
      this.partnerInformation.partnerId = this.$route.params.id;
      this.getPartnersInfo(this.partnerInformation.partnerId);
    }
  },
  mounted() {
    const picker = this.$refs.picker.kendoWidget();
    $('.custom-calender').keydown(function(event) {
      return false;
    });
    picker._dateInput.setOptions({
      messages: {
        year: 'YYYY',
        month: 'MM',
        day: 'DD'
      }
    });
  },
  methods: {
    /**
     * savePartnersInformation is triggred on save button to add partners information
     * save new partners information
     */
    savePartnersInformation() {
      /**
       * emitting 'onShowHideLoader' for partner event  to keep status of onShowHideLoader
       */
      this.$emit('onShowHideLoader', true);
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        this.$emit('onShowHideLoader', false);
        return;
      }
      if (!this.partnerInformation.numberOfBeds) this.partnerInformation.numberOfBeds = null;
      if (!this.partnerInformation.activationDate) this.partnerInformation.activationDate = null;
      /**
       * this scope of code get executed for adding and updating partners information
       */
      // eslint-disable-next-line arrow-parens
      partnerService.postPartnersData(`${PartnersUrls.SAVE_PARTNERS_INFORMATION}`, this.partnerInformation).then(res => {
        const result = res.data.data;
        if (result) {
          this.editMode = true;
          showToast('success');
          this.$emit('onShowHideLoader', false);
          this.$emit('onPartnerAdded');
          const id = result;
          this.partnerInformation.partnerId = id;
          if (!this.$route.params.id) {
            this.$router.push(`/partners/profile/${id}`);
          }
        }
      });
    },
    /**
     * getPartnersInfo(id) getting partners information data from api
     * id = partners id
     */
    getPartnersInfo(id) {
      /**
       * emitting 'onPartnerAdded' for store to keep status of form
       */
      this.$emit('onPartnerAdded');
      this.editMode = true;
      partnerService
        .getPartnersResult(`${PartnersUrls.GET_PARTNERS_INFORMATION}?partnerId=${id}`)
        // eslint-disable-next-line arrow-parens
        .then(res => {
          // console.log(res, res.data, '========get partner info=============');
          const result = res.data.data;
          if (result) {
            this.partnerInformation = result;
            if (result.activationDate) {
              this.partnerInformation.activationDate = this.convertDate(result.activationDate);
              this.activationDateDummy = this.convertDate(result.activationDate);
            }
          }
        });
    },
    getDropdownData() {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=PartnerType%7CTimeZone%7CStatus%7CReasonforInactiveStatus`).then(res => {
        // console.log(res, res.data, '=====================');
        const result = res.data.data;
        this.partnerTypeOptions = result.PartnerType;
        this.timeZoneOptions = result.TimeZone;
        this.statusOptions = result.Status;
        //console.log(result.Status, '=====================');
        this.reasonForInactiveOptions = result.ReasonforInactiveStatus;
      });
    },
    cancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        if (this.$route.params.id) {
          this.editMode = true;
          this.getPartnersInfo(this.$route.params.id);
        } else {
          this.submitted = false;
          this.$v.$reset();
          this.partnerInformation = this.createPartnerInfoForm();
        }
      }
      return false;
    },
    /**
     * getActivationDate() used to get the current date
     * only in case the status is active
     */
    getActivationDate() {
      if (this.partnerInformation.statusId === 1) {
        if (this.activationDateDummy) this.partnerInformation.activationDate = this.activationDateDummy;
        else this.partnerInformation.activationDate = this.convertDate();
        this.partnerInformation.inactiveReasonId = null;
      } else {
        this.partnerInformation.activationDate = null;
      }
    },
    convertDate(dateVal) {
      let originalDate;
      if (dateVal) {
        originalDate = new Date(dateVal);
      } else {
        originalDate = new Date();
      }
      const day = originalDate.getDate();
      const month = originalDate.getMonth() + 1;
      const year = originalDate.getFullYear();

      if (month < 10) {
        return `${year}-0${month}-${day}`;
      }
      return `${year}-${month}-${day}`;
    },
    createPartnerInfoForm() {
      return {
        partnerName: '',
        legalName: '',
        partnerTypeId: '',
        timeZoneId: '',
        activationDate: null,
        statusId: 2,
        numberOfBeds: null,
        inactiveReasonId: null,
        partnerId: 0,
        userId: 0
      };
    }
    /** ----------END----------- */
  }
};
</script>

<style>
.input-group .custom-calender span.k-picker-wrap {
  border: 0;
}
</style>