<template>
  <div class="card">
    <div class="card-header" id="headingSix">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseSix"
          aria-expanded="false"
          aria-controls="collapseSix"
          :data-target="'#'+acordianId"
          :aria-controls="acordianId"
          @click="clickPanel"
        >{{heading}}</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          :data-target="'#'+acordianId"
          aria-expanded="true"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div :id="acordianId" class="collapse" aria-labelledby="headingSix" data-parent="#accordion">
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid #efefef;">
          <div class="col-md-12 text-right mb-1 pt-1" v-if="!editMode">
            <button type="button" class="edit-btn" @click="editMode = !editMode">Edit</button>
          </div>
          <div class="col-md-12 text-right mb-1 mt-1" v-if="editMode">
            <div
              id="billing-edit-1"
              class="mb-1 mt-1"
              style="border-bottom: 1px solid #efefef; padding-bottom:4px;"
            >
              <button
                type="button"
                class="save-btn mr-1"
                @click="updateAdditionalInformation()"
              >Save</button>
              <button type="button" class="cancel-btn" @click="cancelClicked()">Cancel</button>
            </div>
          </div>
        </div>

        <div
          class="alert alert-danger alert-dismissible fade show text-center"
          role="alert"
          style="color:red"
          v-if="errors.length > 0"
        >
          <div v-for="message in errors">{{message.userMessage}}</div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label></label>
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    :checked="additionalInformationData.isAffiliate"
                    class="custom-control-input"
                    id="customCheck11123"
                    @change="checkboxAdditionalInformation()"
                  />

                  <label class="custom-control-label" for="customCheck11123">Affiliate</label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Affiliate Partner
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Affiliate Partner"
                ></i>
              </label>

              <select
                id="inputPartnerName"
                class="form-control"
                :disabled="!editMode || !additionalInformationData.isAffiliate"
                v-model="additionalInformationData.affiliatePartnerID"
              >
                <option value>Select</option>
                <option
                  v-for="partner in affiliatepartners"
                  :value="partner.entityID"
                >{{ partner.entityName }}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.additionalInformationData.affiliatePartnerID.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>
                GLN
                <i class="fa fa-info-circle" aria-hidden="true" title="GLN"></i>
              </label>
              <div class="input-group">
                <input
                  class="form-control"
                  :disabled="!editMode"
                  v-model.trim="additionalInformationData.gln"
                />
              </div>
              <div class="error-message">
                <p
                  v-if="!$v.additionalInformationData.gln.alphaNum"
                >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label>
                HIN
                <i class="fa fa-info-circle" aria-hidden="true" title="HIN"></i>
              </label>
              <div class="input-group">
                <input
                  class="form-control"
                  :disabled="!editMode"
                  v-model.trim="additionalInformationData.hin"
                />
              </div>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.additionalInformationData.hin.alphaNum"
                >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>
                DEA
                <i class="fa fa-info-circle" aria-hidden="true" title="DEA"></i>
              </label>
              <div class="input-group">
                <input
                  class="form-control"
                  :disabled="!editMode"
                  v-model.trim="additionalInformationData.dea"
                />
              </div>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.additionalInformationData.dea.alphaNum"
                >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>
                Contract Entity ID
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Contract Entity ID"
                ></i>
              </label>
              <div class="input-group">
                <input
                  class="form-control"
                  :disabled="!editMode"
                  v-model.trim="additionalInformationData.contractEntityID"
                />
              </div>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.additionalInformationData.contractEntityID.alphaNum"
                >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label>
                PAC
                <i class="fa fa-info-circle" aria-hidden="true" title="PAC"></i>
              </label>
              <div class="input-group">
                <select
                  id="inputPartnerName"
                  class="form-control"
                  :disabled="!editMode"
                  v-model="additionalInformationData.pacid"
                >
                  <option value="0">Select</option>
                  <option v-for="pac in pacs" :value="pac.entityID">{{ pac.entityName }}</option>
                </select>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>
                Stat Team Rep
                <i class="fa fa-info-circle" aria-hidden="true" title="Stat Team Rep"></i>
              </label>

              <select
                id="inputState"
                class="form-control"
                :disabled="!editMode"
                v-model="additionalInformationData.statTeamRepEmpID"
              >
                <option value="0">Select</option>
                <option
                  v-for="timerep in statteamrep"
                  :value="timerep.entityID"
                >{{ timerep.entityName }}</option>
              </select>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>
                Drive Time from the Branch Serving the Partner
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Drive Time from the Branch Serving the Partner"
                ></i>
              </label>
              <div class="input-group">
                <input
                  class="form-control"
                  :disabled="!editMode"
                  :readonly="true"
                  v-model.trim="additionalInformationData.driveTime"
                />
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>
                Distance from the Branch Serving the Partner (in miles)
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Distance from the Branch Serving the Partner (in miles)"
                ></i>
              </label>
              <div class="input-group">
                <input
                  type="text"
                  :disabled="!editMode"
                  oninput="validity.valid||(value='');"
                  min="1"
                  pattern="\d*"
                  maxlength="9"
                  v-model.number="additionalInformationData.distanceFromBranch"
                  class="form-control"
                />
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>
                Website
                <i class="fa fa-info-circle" aria-hidden="true" title="Website"></i>
              </label>
              <div class="input-group">
                <input
                  class="form-control"
                  :disabled="!editMode"
                  v-model.trim="additionalInformationData.webSiteURL"
                />
              </div>
              <div v-if="submitted" class="error-message">
                <p v-if="!$v.additionalInformationData.webSiteURL.url">{{validationMessages.URL}}</p>
                <p
                  v-if="!$v.additionalInformationData.webSiteURL.maxLength"
                >{{validationMessages.URLMAXLENGTH}}</p>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>
                Facebook Account
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Facebook Account"
                ></i>
              </label>
              <div class="input-group">
                <input
                  class="form-control"
                  :disabled="!editMode"
                  v-model.trim="additionalInformationData.facebookAccount"
                />
              </div>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.additionalInformationData.facebookAccount.url"
                >{{validationMessages.URL}}</p>
                <p
                  v-if="!$v.additionalInformationData.facebookAccount.maxLength"
                >{{validationMessages.URLMAXLENGTH}}</p>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>
                Twitter Account
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Twitter Account"
                ></i>
              </label>
              <div class="input-group">
                <input
                  class="form-control"
                  :disabled="!editMode"
                  v-model.trim="additionalInformationData.twitterAccount"
                />
              </div>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.additionalInformationData.twitterAccount.url"
                >{{validationMessages.URL}}</p>
                <p
                  v-if="!$v.additionalInformationData.twitterAccount.maxLength"
                >{{validationMessages.URLMAXLENGTH}}</p>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>
                Linkedin Account
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Linkedin Account"
                ></i>
              </label>
              <div class="input-group">
                <input
                  class="form-control"
                  :disabled="!editMode"
                  v-model.trim="additionalInformationData.linkedInAccount"
                />
              </div>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.additionalInformationData.linkedInAccount.url"
                >{{validationMessages.URL}}</p>
                <p
                  v-if="!$v.additionalInformationData.linkedInAccount.maxLength"
                >{{validationMessages.URLMAXLENGTH}}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
 

<script>
/* eslint-disable */
import { PartnersUrls, MasterUrls, getMasterMockup } from '../../../shared/constants/urls';
import partnerService from '../services/partners-service';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import Vue from 'vue';
import { url, alphaNum, integer, maxLength, requiredIf } from 'vuelidate/lib/validators';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
export default {
  name: 'AdditioalPartnerInformation',
  data() {
    return {
      heading: 'Additional Partner Information',
      saveAdditionalInformationUrl: PartnersUrls.SAVE_ADDITIONAL_INFORMATION,
      getAdditionalInformationUrl: PartnersUrls.GET_ADDITIONAL_INFORMATION,
      acordianId: 'additionalinformation',
      additionalInformationDataArray: [],
      errors: [],
      affiliatepartners: null,
      statteamrep: null,
      pacs: null,
      editMode: false,
      submitted: false,
      validationMessages: VALIDATION_MESSAGE,
      additionalInformationData: {
        isAffiliate: '',
        affiliatePartnerID: '',
        gln: '',
        hin: '',
        dea: '',
        contractEntityID: '',
        pacid: '',
        statTeamRepEmpID: '',
        driveTime: '',
        distanceFromBranch: '',
        webSiteURL: '',
        facebookAccount: '',
        twitterAccount: '',
        linkedInAccount: ''
      },
      formRequestPayload: {}
    };
  },
  watch: {
    $route(to, from) {
      if (this.$route.params.id) {
        this.getAdditionalinformation();

        partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=AffiliatePartner&id=${this.$route.params.id}`).then(response => {
          if (response.data) {
            this.affiliatepartners = response.data.data.AffiliatePartner;
          }
        });

        partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=StatTeamRep`).then(response => {
          if (response.data) {
            this.statteamrep = response.data.data.StatTeamRep;
          }
        });

        partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=PAC`).then(response => {
          if (response.data) {
            this.pacs = response.data.data.PAC;
          }
        });
      }
    }
  },
  async created() {
    if (this.$route.params.id) {
      await this.getAdditionalinformation();

      //this.setToStrings();
      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=AffiliatePartner&id=${this.$route.params.id}`).then(response => {
        if (response.data) {
          this.affiliatepartners = response.data.data.AffiliatePartner;
        }
      });

      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=StatTeamRep`).then(response => {
        if (response.data) {
          this.statteamrep = response.data.data.StatTeamRep;
        }
      });

      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=PAC`).then(response => {
        if (response.data) {
          this.pacs = response.data.data.PAC;
        }
      });
    }
  },
  methods: {
    setToStrings() {
      // Simply replaces null values with strings=''
      if (this.additionalInformationData.pacid === null) {
        this.additionalInformationData.pacid = '0';
      }
      if (this.additionalInformationData.affiliatePartnerID === 0) {
        this.additionalInformationData.affiliatePartnerID = '';
      }
      return this.additionalInformationData;
    },
    makeErrorsBlank() {
      this.errors.length = 0;
    },
    clickPanel() {
      this.$emit('onPannelClicked');
    },
    getAdditionalinformation() {
      const id = this.$route.params.id;
      partnerService
        .getPartnersResult(`${this.getAdditionalInformationUrl}?partnerId=${id}`)
        .then(res => {
          this.additionalInformationData = res.data.data;
          this.setToStrings();
        })
        .catch(error => {
          console.log(error);
        });
    },
    /**
     * This function used for udpate information
     */
    updateAdditionalInformation() {
      this.submitted = true;
      this.$v.$touch();

      if (this.$v.$invalid) {
        return;
      }

      const postData = {
        PartnerID: Number(this.$route.params.id),
        IsAffiliate: this.additionalInformationData.isAffiliate !== null ? this.additionalInformationData.isAffiliate : '',
        AffiliatePartnerID: Number(this.additionalInformationData.affiliatePartnerID),
        GLN: this.additionalInformationData.gln !== null ? this.additionalInformationData.gln : '',
        HIN: this.additionalInformationData.hin !== null ? this.additionalInformationData.hin : '',
        DEA: this.additionalInformationData.dea !== null ? this.additionalInformationData.dea : '',
        ContractEntityID: this.additionalInformationData.contractEntityID !== '' ? this.additionalInformationData.contractEntityID : null,
        PACID:
          this.additionalInformationData.pacid !== null && this.additionalInformationData.pacid !== '0' ? Number(this.additionalInformationData.pacid) : null,
        StatTeamRepEmpID: Number(this.additionalInformationData.statTeamRepEmpID),
        DriveTime: this.additionalInformationData.driveTime !== null ? this.additionalInformationData.driveTime : '',
        DistanceFromBranch: this.additionalInformationData.distanceFromBranch,
        WebSiteURL: this.additionalInformationData.webSiteURL,
        FacebookAccount: this.additionalInformationData.facebookAccount,
        TwitterAccount: this.additionalInformationData.twitterAccount,
        LinkedInAccount: this.additionalInformationData.linkedInAccount,
        UserId: 1
      };

      partnerService.postPartnersDataAction(this.saveAdditionalInformationUrl, postData).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.getAdditionalinformation();
          this.errors.length = 0;
          this.editMode = false;
          showToast('success');
        } else {
          this.errors = res.data.errors;
        }
      });
    },
    cancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        if (this.errors.length === 0) {
          this.getAdditionalinformation();
        } else {
          this.errors.length = 0;
        }
        this.editMode = false;
      }
      return false;
    },
    onPannelClicked() {
      this.$emit('panelClicked', 5);
    },
    /**
     * This function is used for toggle IsAffiliate checkbox
     * and make null affiliatePartnerID based on IsAffiliate
     */
    checkboxAdditionalInformation() {
      this.additionalInformationData.isAffiliate = !this.additionalInformationData.isAffiliate;
      if (this.additionalInformationData.isAffiliate === false) {
        this.additionalInformationData.affiliatePartnerID = null;
      }
    }
  },
  /**
   * Validation Logic
   */
  validations: {
    additionalInformationData: {
      gln: { alphaNum },
      hin: { alphaNum },
      dea: { alphaNum },
      contractEntityID: { alphaNum },
      pacid: { integer },
      affiliatePartnerID: {
        required: requiredIf(function(vm) {
          if (vm.isAffiliate === true) {
            return true;
          }
          return false;
        })
      },
      webSiteURL: {
        url,
        maxLength: maxLength(250)
      },
      facebookAccount: {
        url,
        maxLength: maxLength(250)
      },
      twitterAccount: {
        url,
        maxLength: maxLength(250)
      },
      linkedInAccount: {
        url,
        maxLength: maxLength(250)
      }
    }
  }
};
</script>
 