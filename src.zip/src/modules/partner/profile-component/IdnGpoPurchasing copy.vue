<template>
  <div class="card">
    <div class="card-header" id="headingTen">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseTen"
          aria-expanded="false"
          aria-controls="collapseTen"
        >IDN/GPO/Purchasing Coalition</button>
      </h5>
      <div class="rightInfotext">
        <i class="fa fa-angle-down" data-toggle="collapse" data-target="#collapseTen"></i>
      </div>
    </div>
    <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordion">
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid #efefef;">
          <div class="col-md-12 text-right mb-1 pt-1">
            <button v-if="!editMode" type="button" class="edit-btn" @click="editMode = true">Edit</button>
            <div v-else>
              <button type="button" class="save-btn mr-1" @click="savePurchasingCoalition()">Save</button>
              <button type="button" class="cancel-btn" @click="cancelClicked()">Cancel</button>
            </div>
          </div>
        </div>
        <div
          class="alert alert-danger alert-dismissible fade show text-center"
          role="alert"
          style="color:red"
          v-if="error"
        >
          <div v-if="pError.rental === -1">{{validationMessages.rentalGPO}}</div>
          <div v-if="pError.sales === -1">{{validationMessages.salesGPO}}</div>
          <div v-if="pError.coalition === -1">{{validationMessages.purchasingCoalition}}</div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label>
                IDN
                <i
                  class="icon-help-round-button"
                  data-container="body"
                  data-toggle="popover"
                  data-placement="right"
                  data-content="Help Text Here"
                  data-original-title
                  title
                ></i>
              </label>
              <select
                id="inputState"
                class="form-control"
                v-model="purchasingCoalition.idnid"
                :disabled="!editMode"
              >
                <option :value="0">Select</option>
                <option v-for="IDN in idnOptions" :value="IDN.entityID">{{ IDN.entityName }}</option>
              </select>
            </div>
          </div>
        </div>
        <div class="row pt-3">
          <div class="col-md-4">
            <!-- <h3 class="gridName">Rental GPO</h3> -->
            <div class="fullPagetable">
              <div class="row">
                <div class="col-md-12">
                  <div class="table-responsive" style="height:230px;">
                    <table class="table softwareTable">
                      <thead>
                        <tr>
                          <th colspan="2">Rental GPO</th>
                          <th>Primary</th>
                        </tr>
                      </thead>
                      <tbody>
                        <template v-for="(rentalData, index) in rentalGPOOptions">
                          <tr>
                            <td width="3%">
                              <div class="checkBoxinFrom NoMargPad">
                                <div class="custom-control custom-checkbox">
                                  <input
                                    type="checkbox"
                                    :disabled="!editMode"
                                    class="custom-control-input"
                                    :id="'RentalCheck1'+index"
                                    checked
                                    :ref="'RentalCheck1'+index"
                                    v-model="purchasingCoalition.rentalGPODefault[index]"
                                    @change="rentalGPOData(rentalData, index)"
                                  />
                                  <label class="custom-control-label" :for="'RentalCheck1'+index"></label>
                                </div>
                              </div>
                            </td>
                            <td>{{rentalData.entityName}}</td>
                            <td>
                              <div class="custom-control custom-radio custom-control-inline">
                                <input
                                  type="radio"
                                  :id="'RentalRadioA'+index"
                                  name="RentalRadio"
                                  class="custom-control-input"
                                  :ref="'RentalRadioA'+index"
                                  :disabled="purchasingCoalition.rentalGPODefault[index] || !editMode"
                                  @change="rentalGPODataRadio(rentalData,index)"
                                />
                                <label class="custom-control-label" :for="'RentalRadioA'+index"></label>
                              </div>
                            </td>
                          </tr>
                        </template>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <!-- <h3 class="gridName">Sales GPO</h3> -->
            <div class="fullPagetable">
              <div class="row">
                <div class="col-md-12">
                  <div class="table-responsive" style="height:230px;">
                    <table class="table softwareTable">
                      <thead>
                        <tr>
                          <th colspan="2">Sales GPO</th>
                          <th>Primary</th>
                        </tr>
                      </thead>
                      <tbody>
                        <template v-for="(salesData, index) in salesGPOOptions">
                          <tr>
                            <td width="3%">
                              <div class="checkBoxinFrom NoMargPad">
                                <div class="custom-control custom-checkbox">
                                  <input
                                    type="checkbox"
                                    class="custom-control-input"
                                    :id="'GPOCheck1'+index"
                                    :ref="'GPOCheck1'+index"
                                    :disabled="!editMode"
                                    v-model="purchasingCoalition.salesGPODefault[index]"
                                    checked="checked"
                                    @change="salesGPOData(salesData, index)"
                                  />
                                  <label class="custom-control-label" :for="'GPOCheck1'+index"></label>
                                </div>
                              </div>
                            </td>
                            <td>{{salesData.entityName}}</td>
                            <td>
                              <div class="custom-control custom-radio custom-control-inline">
                                <input
                                  type="radio"
                                  :id="'GPOR1'+index"
                                  :ref="'GPOR1'+index"
                                  :disabled="purchasingCoalition.salesGPODefault[index] || !editMode"
                                  name="GPOR"
                                  class="custom-control-input"
                                  @change="salesGPODataRadio(salesData,index)"
                                />
                                <label class="custom-control-label" :for="'GPOR1'+index"></label>
                              </div>
                            </td>
                          </tr>
                        </template>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <!-- <h3 class="gridName">Purchasing Coalition</h3> -->
            <div class="fullPagetable">
              <div class="row">
                <div class="col-md-12">
                  <div class="table-responsive" style="height:230px;">
                    <table class="table softwareTable">
                      <thead>
                        <tr>
                          <th colspan="2">Purchasing Coalition</th>
                          <th>Primary</th>
                        </tr>
                      </thead>
                      <tbody>
                        <template
                          v-for="(purchasingCoalitionData, index) in purchasingCoalitionOptions"
                        >
                          <tr>
                            <td width="3%">
                              <div class="checkBoxinFrom NoMargPad">
                                <div class="custom-control custom-checkbox">
                                  <input
                                    type="checkbox"
                                    :disabled="!editMode"
                                    class="custom-control-input"
                                    :id="'customCheckA'+index"
                                    :ref="'customCheckA'+index"
                                    checked="checked"
                                    v-model="purchasingCoalition.purchasingCoalDefault[index]"
                                    @change="purchasingCoalData(purchasingCoalitionData, index)"
                                  />
                                  <label class="custom-control-label" :for="'customCheckA'+index"></label>
                                </div>
                              </div>
                            </td>
                            <td>{{purchasingCoalitionData.entityName}}</td>
                            <td>
                              <div class="custom-control custom-radio custom-control-inline">
                                <input
                                  type="radio"
                                  :id="'customRadioInlinea'+index"
                                  :ref="'customRadioInlinea'+index"
                                  name="PurchasingRadio"
                                  class="custom-control-input"
                                  :disabled="purchasingCoalition.purchasingCoalDefault[index] || !editMode"
                                  @change="purchasingCoalitionDataRadio(purchasingCoalitionData,index)"
                                />
                                <label
                                  class="custom-control-label"
                                  :for="'customRadioInlinea'+index"
                                ></label>
                              </div>
                            </td>
                          </tr>
                        </template>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import partnerService from '../services/partners-service';
import { showToast } from '../../../shared/services/toast-service';
import { PartnersUrls, MasterUrls } from '../../../shared/constants/urls';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

export default {
  data() {
    return {
      validationMessages: VALIDATION_MESSAGE,
      editMode: false,
      rentalGPOOptions: [],
      salesGPOOptions: [],
      purchasingCoalitionOptions: [],
      idnOptions: [],
      purchasingCoalition: this.purchasingCoalitionForm(),
      error: false,
      primaryError: { rental: 0, sales: 0, coalition: 0 }
    };
  },
  created() {
    this.getFormData();
    // await this.getDropdownData();
    // if (this.$route.params.id) {
    //   this.purchasingCoalition.partnerId = parseInt(this.$route.params.id, 10);
    //   this.getPurchasingCoalitionData(this.$route.params.id);
    // }
  },
  computed: {
    pError() {
      return this.primaryError;
    }
  },
  methods: {
    purchasingCoalitionDataRadio(item, i) {
      console.log(i);
      this.purchasingCoalition.purchasingCoal.forEach((element, index) => {
        if (element.purchasingCoalitionId === item.entityID) {
          this.purchasingCoalition.purchasingCoal[index].isPrimary = true;
        } else {
          this.purchasingCoalition.purchasingCoal[index].isPrimary = false;
        }
      });
    },
    purchasingCoalData(result, index) {
      const refNameCheck = `customCheckA${index}`;
      const refNameRadio = `customRadioInlinea${index}`;
      if (this.$refs[refNameCheck][0].checked) {
        this.$refs[refNameRadio][0].checked = false;
        // this.purchasingCoalition.purchasingCoal[index].isPrimary = false;
        this.purchasingCoalition.purchasingCoal.forEach((element, index) => {
          if (element.purchasingCoalitionId === result.entityID) {
            this.purchasingCoalition.purchasingCoal[index].isPrimary = false;
          }
        });
      }
      if (!this.$refs[refNameCheck][0].checked) {
        const purchasingCoalRemIndex = this.purchasingCoalition.purchasingCoal.findIndex(item => item.purchasingCoalitionId === result.entityID);
        if (purchasingCoalRemIndex === -1) {
          this.purchasingCoalition.purchasingCoal.push({ id: 0, purchasingCoalitionId: result.entityID, isPrimary: false, isActive: true });
        } else {
          this.purchasingCoalition.purchasingCoal[purchasingCoalRemIndex].isActive = true;
        }
      } else {
        this.purchasingCoalition.purchasingCoal.forEach((element, i) => {
          if (element.purchasingCoalitionId === result.entityID) {
            if (element.id) {
              this.purchasingCoalition.purchasingCoal[i].isActive = false;
            } else {
              this.purchasingCoalition.purchasingCoal.splice(i, 1);
            }
          }
        });
      }
    },
    salesGPODataRadio(item, i) {
      console.log(i);
      this.purchasingCoalition.salesGPO.forEach((element, index) => {
        if (element.salesGPOId === item.entityID) {
          this.purchasingCoalition.salesGPO[index].isPrimary = true;
        } else {
          this.purchasingCoalition.salesGPO[index].isPrimary = false;
        }
      });
    },
    salesGPOData(result, index) {
      // const rentalCheckRes = result;
      const refNameCheck = `GPOCheck1${index}`;
      const refNameRadio = `GPOR1${index}`;
      if (this.$refs[refNameCheck][0].checked) {
        this.$refs[refNameRadio][0].checked = false;
        // this.purchasingCoalition.salesGPO[index].isPrimary = false;
        this.purchasingCoalition.salesGPO.forEach((element, index) => {
          if (element.salesGPOId === result.entityID) {
            this.purchasingCoalition.salesGPO[index].isPrimary = false;
          }
        });
      }
      if (!this.$refs[refNameCheck][0].checked) {
        const salesGPORemIndex = this.purchasingCoalition.salesGPO.findIndex(item => item.salesGPOId === result.entityID);
        if (salesGPORemIndex === -1) {
          this.purchasingCoalition.salesGPO.push({ id: 0, salesGPOId: result.entityID, isPrimary: false, isActive: true });
        } else {
          this.purchasingCoalition.salesGPO[salesGPORemIndex].isActive = true;
        }
      } else {
        // eslint-disable-next-line arrow-parens
        this.purchasingCoalition.salesGPO.forEach((element, i) => {
          if (element.salesGPOId === result.entityID) {
            if (element.id) {
              this.purchasingCoalition.salesGPO[i].isActive = false;
            } else {
              this.purchasingCoalition.salesGPO.splice(i, 1);
            }
          }
        });
      }
    },
    rentalGPODataRadio(item, i) {
      console.log(i);
      this.purchasingCoalition.rentalGPO.forEach((element, index) => {
        if (element.rentalGPOId === item.entityID) {
          this.purchasingCoalition.rentalGPO[index].isPrimary = true;
        } else {
          this.purchasingCoalition.rentalGPO[index].isPrimary = false;
        }
      });
    },
    rentalGPOData(result, index) {
      const rentalCheckRes = result;
      const refNameCheck = `RentalCheck1${index}`;
      const refNameRadio = `RentalRadioA${index}`;
      if (this.$refs[refNameCheck][0].checked) {
        this.$refs[refNameRadio][0].checked = false;
        // this.purchasingCoalition.rentalGPO[index].isPrimary = false;
        this.purchasingCoalition.rentalGPO.forEach((element, index) => {
          if (element.rentalGPOId === result.entityID) {
            this.purchasingCoalition.rentalGPO[index].isPrimary = false;
          }
        });
      }
      console.log(this.$refs[refNameCheck][0], rentalCheckRes, index);
      if (!this.$refs[refNameCheck][0].checked) {
        const rentalGPORemIndex = this.purchasingCoalition.rentalGPO.findIndex(item => item.rentalGPOId === result.entityID);
        if (rentalGPORemIndex === -1) {
          this.purchasingCoalition.rentalGPO.push({ id: 0, rentalGPOId: result.entityID, isPrimary: false, isActive: true });
          console.log(rentalGPORemIndex, this.purchasingCoalition.rentalGPO);
        } else {
          this.purchasingCoalition.rentalGPO[rentalGPORemIndex].isActive = true;
        }
      } else {
        // eslint-disable-next-line arrow-parens
        this.purchasingCoalition.rentalGPO.forEach((element, i) => {
          if (element.rentalGPOId === result.entityID) {
            if (element.id) {
              this.purchasingCoalition.rentalGPO[i].isActive = false;
            } else {
              this.purchasingCoalition.rentalGPO.splice(i, 1);
            }
          }
        });
      }
    },
    savePurchasingCoalition() {
      this.purchasingCoalition.partnerId = parseInt(this.$route.params.id);
      const rentalPrimaryIndex = this.purchasingCoalition.rentalGPO.findIndex(item => item.isPrimary === true);
      const salesPrimaryIndex = this.purchasingCoalition.salesGPO.findIndex(item => item.isPrimary === true);
      const pCoalPrimaryIndex = this.purchasingCoalition.purchasingCoal.findIndex(item => item.isPrimary === true);

      const rentalLength = this.purchasingCoalition.rentalGPO.filter(item => item.isActive === true);
      const salesLength = this.purchasingCoalition.salesGPO.filter(item => item.isActive === true);
      const purchasingCoalLength = this.purchasingCoalition.purchasingCoal.filter(item => item.isActive === true);
      if (rentalPrimaryIndex === -1 || salesPrimaryIndex === -1 || pCoalPrimaryIndex === -1) {
        this.error = true;

        // this.primaryError.push(rentalPrimaryIndex);
        if (rentalLength.length > 0) this.primaryError.rental = rentalPrimaryIndex;
        else this.primaryError.rental = 0;
        if (salesLength.length > 0) this.primaryError.sales = salesPrimaryIndex;
        else this.primaryError.sales = 0;
        if (purchasingCoalLength.length > 0) this.primaryError.coalition = pCoalPrimaryIndex;
        else this.primaryError.coalition = 0;
        console.log(
          rentalPrimaryIndex,
          salesPrimaryIndex,
          pCoalPrimaryIndex,
          'kkkk===+++',
          rentalLength.length,
          salesLength.length,
          purchasingCoalLength.length
        );
        if (
          (rentalLength.length > 0 && rentalPrimaryIndex === -1) ||
          (salesLength.length > 0 && salesPrimaryIndex === -1) ||
          (purchasingCoalLength.length > 0 && pCoalPrimaryIndex === -1)
        ) {
          return false;
        } else {
          this.error = false;
        }
      }
      console.log(this.purchasingCoalition, 'kkkk===+++');

      // delete this.purchasingCoalition.rentalGPODefault;
      // delete this.purchasingCoalition.salesGPODefault;
      // delete this.purchasingCoalition.purchasingCoalDefault;

      // eslint-disable-next-line arrow-parens
      partnerService.postPartnersData(`${PartnersUrls.SAVE_IDN_GPO_COALITION}`, this.purchasingCoalition).then(res => {
        if (res.data.apiResponseStatus === 'OK') {
          console.log(res);
          showToast('success');
          this.error = false;
          this.purchasingCoalition = this.purchasingCoalitionForm();
          this.getFormData();
          this.editMode = false;
        }
      });
    },
    getDropdownData() {
      // eslint-disable-next-line arrow-parens
      return partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=IDN%7CRentalGPO%7CSalesGPO%7CPurchasingCoalition`).then(res => {
        const result = res.data.data;
        this.idnOptions = result.IDN;
        this.rentalGPOOptions = result.RentalGPO;
        // eslint-disable-next-line arrow-parens
        this.rentalGPOOptions.forEach(() => {
          this.purchasingCoalition.rentalGPODefault.push(true);
        });
        this.salesGPOOptions = result.SalesGPO;
        // eslint-disable-next-line arrow-parens
        this.salesGPOOptions.forEach(() => {
          this.purchasingCoalition.salesGPODefault.push(true);
        });
        this.purchasingCoalitionOptions = result.PurchasingCoalition;
        // eslint-disable-next-line arrow-parens
        this.purchasingCoalitionOptions.forEach(() => {
          this.purchasingCoalition.purchasingCoalDefault.push(true);
        });
      });
    },
    getPurchasingCoalitionData(id) {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_IDN_GPO_COALITION}?partnerId=${id}`).then(res => {
        const result = res.data.data;
        console.log(result, '-----------purchasing Coalition get', result.rentalGPO, this.rentalGPOOptions);
        this.purchasingCoalition.idnid = result.idnid;
        this.purchasingCoalition.rentalGPO = [];
        // eslint-disable-next-line arrow-parens
        result.rentalGPO.forEach(element => {
          this.purchasingCoalition.rentalGPO.push({
            id: element.id,
            rentalGPOId: element.rentalGPOId,
            isPrimary: element.isPrimary,
            isActive: element.isActive
          });
          const index = this.rentalGPOOptions.findIndex(item => item.entityID === element.rentalGPOId);
          if (index !== -1) {
            const refNameCheck = `RentalCheck1${index}`;
            const refNameRadio = `RentalRadioA${index}`;
            this.$refs[refNameCheck][0].checked = false;
            if (element.isPrimary) this.$refs[refNameRadio][0].checked = true;
            this.purchasingCoalition.rentalGPODefault[index] = false;
          }
        });
        // ------sales data bind------//
        this.purchasingCoalition.salesGPO = [];
        // eslint-disable-next-line arrow-parens
        result.salesGPO.forEach(element => {
          this.purchasingCoalition.salesGPO.push({
            id: element.id,
            salesGPOId: element.salesGPOId,
            isPrimary: element.isPrimary,
            isActive: element.isActive
          });
          const index = this.salesGPOOptions.findIndex(item => item.entityID === element.salesGPOId);
          if (index !== -1) {
            const refNameCheck = `GPOCheck1${index}`;
            const refNameRadio = `GPOR1${index}`;
            this.$refs[refNameCheck][0].checked = false;
            if (element.isPrimary) this.$refs[refNameRadio][0].checked = true;
            this.purchasingCoalition.salesGPODefault[index] = false;
          }
        });
        // ------purchasing data bind------//
        this.purchasingCoalition.purchasingCoal = [];
        // eslint-disable-next-line arrow-parens
        result.purchasingCoal.forEach(element => {
          this.purchasingCoalition.purchasingCoal.push({
            id: element.id,
            purchasingCoalitionId: element.purchasingCoalitionId,
            isPrimary: element.isPrimary,
            isActive: element.isActive
          });
          const index = this.purchasingCoalitionOptions.findIndex(item => item.entityID === element.purchasingCoalitionId);
          if (index !== -1) {
            const refNameCheck = `customCheckA${index}`;
            const refNameRadio = `customRadioInlinea${index}`;
            this.$refs[refNameCheck][0].checked = false;
            if (element.isPrimary) this.$refs[refNameRadio][0].checked = true;
            this.purchasingCoalition.purchasingCoalDefault[index] = false;
          }
        });
      });
    },
    cancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.purchasingCoalition = this.purchasingCoalitionForm();
        this.getFormData();
        this.editMode = false;
        this.error = false;
      }
      return false;
    },
    getFormData() {
      // eslint-disable-next-line arrow-parens
      const dropDownPromise = new Promise(resolve => {
        resolve(this.getDropdownData());
      });
      dropDownPromise.then(() => {
        if (this.$route.params.id) {
          this.purchasingCoalition.partnerId = parseInt(this.$route.params.id, 10);
          this.getPurchasingCoalitionData(this.$route.params.id);
        }
      });
    },
    purchasingCoalitionForm() {
      return {
        partnerId: 0,
        idnid: 0,
        rentalGPODefault: [],
        rentalGPO: [],
        salesGPODefault: [],
        salesGPO: [],
        purchasingCoalDefault: [],
        purchasingCoal: [],
        userId: 1
      };
    }
  }
};
</script>