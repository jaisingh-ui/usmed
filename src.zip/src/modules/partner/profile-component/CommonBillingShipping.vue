<template>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          :data-target="'#'+acordianId"
          aria-expanded="false"
          :aria-controls="acordianId"
        >{{heading}}</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          :data-target="'#'+acordianId"
          aria-expanded="true"
        ></i>
      </div>
    </div>
    <div :id="acordianId" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
      <div class="card-body">
        <div id="billing-info1" data-billing="1" v-if="editMode">
          <div class="row">
            <div class="col-md-12 text-right mb-1 mt-1">
              <div id="billing-edit-1" class="mb-1 mt-1 BorderBottom pb-1">
                <button type="button" class="save-btn mr-1" @click="saveAddress()">Save</button>
                <button type="button" class="cancel-btn" @click="cancelClicked()">Cancel</button>
                <!-- <span class="">
                  <a href="javascript:void(0)" class="saveCancle"></a>
                </span>
                <span class="">
                  <a href="javascript:void(0)" class="saveCancle"></a>
                </span>-->
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label>
                  Departments
                  <i
                    class="icon-help-round-button"
                    data-container="body"
                    data-toggle="popover"
                    data-placement="right"
                    data-content="Help Text Here"
                    data-original-title
                    title
                  ></i>
                </label>
                <div class="button-group dropCheckbox">
                  <kendo-dropdowntree
                    :class="{'form-control':true}"
                    v-model="addressDataDepartment"
                    :data-source="departmentOptions"
                    :checkboxes="true"
                    :check-all="false"
                    :placeholder="'Select'"
                  ></kendo-dropdowntree>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4">
              <div class="form-group">
                <label>
                  Address 1
                  <i
                    class="icon-help-round-button"
                    data-container="body"
                    data-toggle="popover"
                    data-placement="right"
                    data-content="Help Text Here"
                    data-original-title
                    title
                  ></i>
                </label>
                <input
                  type="text"
                  maxlength="200"
                  class="form-control"
                  v-model.trim="addressData.address1"
                />
                <div v-if="submitted" class="error-message">
                  <p v-if="!$v.addressData.address1.required">{{validationMessages.REQUIRED}}</p>
                  <p
                    v-if="!$v.addressData.address1.alphaNumSpecialValidation"
                  >{{validationMessages.INVALIDMODELOPTION}}</p>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4">
              <div class="form-group">
                <label>
                  Address 2
                  <i
                    class="icon-help-round-button"
                    data-container="body"
                    data-toggle="popover"
                    data-placement="right"
                    data-content="Help Text Here"
                    data-original-title
                    title
                  ></i>
                </label>
                <input
                  type="text"
                  maxlength="200"
                  class="form-control"
                  v-model.trim="addressData.address2"
                />
                <div v-if="submitted" class="error-message">
                  <p
                    v-if="!$v.addressData.address2.alphaNumSpecialValidation"
                  >{{validationMessages.INVALIDMODELOPTION}}</p>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4">
              <div class="form-group">
                <label>
                  City
                  <i
                    class="icon-help-round-button"
                    data-container="body"
                    data-toggle="popover"
                    data-placement="right"
                    data-content="Help Text Here"
                    data-original-title
                    title
                  ></i>
                </label>
                <input type="text" class="form-control" v-model.trim="addressData.city" />
                <div v-if="submitted" class="error-message">
                  <p v-if="!$v.addressData.city.required">{{validationMessages.REQUIRED}}</p>
                  <p
                    v-if="!$v.addressData.city.alphawithspace"
                  >{{validationMessages.ALPHA_NUMERIC_SPACES}}</p>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4">
              <div class="form-group">
                <label>
                  State
                  <i
                    class="icon-help-round-button"
                    data-container="body"
                    data-toggle="popover"
                    data-placement="right"
                    data-content="Help Text Here"
                    data-original-title
                    title
                  ></i>
                </label>
                <select
                  id="inputMenu"
                  class="form-control"
                  v-model="addressData.stateId"
                  @change="addressData.countyId = null"
                >
                  <option value>Select</option>
                  <option
                    v-for="state in stateOptions"
                    :value="state.entityID"
                  >{{ state.entityName }}</option>
                </select>
                <div v-if="submitted" class="error-message">
                  <p v-if="!$v.addressData.stateId.required">{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4">
              <div class="form-group">
                <label>
                  ZIP
                  <i
                    class="icon-help-round-button"
                    data-container="body"
                    data-toggle="popover"
                    data-placement="right"
                    data-content="Help Text Here"
                    data-original-title
                    title
                  ></i>
                </label>
                <input
                  type="text"
                  maxlength="5"
                  class="form-control"
                  v-model.number="addressData.zip"
                />
                <div v-if="submitted" class="error-message">
                  <p v-if="!$v.addressData.zip.required">{{validationMessages.REQUIRED}}</p>
                  <p v-if="!$v.addressData.zip.numeric">{{validationMessages.INTEGER}}</p>
                  <p
                    v-if="!$v.addressData.zip.minLen"
                  >{{validationMessages.MIN_LENGTH}} {{$v.addressData.zip.$params.minLen.min}}</p>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4">
              <div class="form-group">
                <label>
                  County
                  <i
                    class="icon-help-round-button"
                    data-container="body"
                    data-toggle="popover"
                    data-placement="right"
                    data-content="Help Text Here"
                    data-original-title
                    title
                  ></i>
                </label>
                <select id="inputMenu" class="form-control" v-model="addressData.countyId">
                  <option :value="null">Select</option>
                  <option
                    v-for="county in countyOptionsResult"
                    :value="county.entityID"
                  >{{ county.entityName }}</option>
                </select>
              </div>
            </div>
            <div class="col-lg-4 col-md-4">
              <div class="form-group">
                <label>
                  Country
                  <i
                    class="icon-help-round-button"
                    data-container="body"
                    data-toggle="popover"
                    data-placement="right"
                    data-content="Help Text Here"
                    data-original-title
                    title
                  ></i>
                </label>
                <select id="inputMenu" class="form-control" v-model="addressData.countryId">
                  <option value>Select</option>
                  <option
                    v-for="country in countryOptions"
                    :value="country.entityID"
                  >{{ country.entityName }}</option>
                </select>
              </div>
            </div>
            <div class="col-lg-4 col-md-4">
              <div class="form-group">
                <label>
                  Fax
                  <i
                    class="icon-help-round-button"
                    data-container="body"
                    data-toggle="popover"
                    data-placement="right"
                    data-content="Help Text Here"
                    data-original-title
                    title
                  ></i>
                </label>
                <div class="custom-kendo-input">
                  <kendo-maskedtextbox
                    title="phone number"
                    v-model="addressData.fax"
                    mask="(999)-000-0000"
                  ></kendo-maskedtextbox>
                </div>
                <div v-if="submitted" class="error-message">
                  <p
                    v-if="!$v.addressData.fax.phoneCustomLimit"
                  >{{validationMessages.MIN_LENGTH}} 10</p>
                </div>
              </div>
            </div>
          </div>

          <div class="row" v-for="(contactInfo, index) in addressData.phone">
            <div class="col-md-4">
              <div class="form-group">
                <label v-if="index == 0">
                  Phone
                  <i
                    class="icon-help-round-button"
                    data-container="body"
                    data-toggle="popover"
                    data-placement="right"
                    data-content="Help Text Here"
                    data-original-title
                    title
                  ></i>
                </label>
                <!-- <input
                  :readonly="contactInfo.id != 0"
                  type="text"
                  maxlength="14"
                  class="form-control"
                  v-model="contactInfo.phone"
                  @change="formattedPhone($v.addressData.phone.$each[index], 'phone', index+1)"
                />-->
                <div class="custom-kendo-input" :class="{'disabled-class': contactInfo.id != 0}">
                  <kendo-maskedtextbox
                    title="phone number"
                    v-model="contactInfo.phone"
                    mask="(999)-000-0000"
                  ></kendo-maskedtextbox>
                </div>
                <div v-if="submitted" class="error-message">
                  <p
                    v-if="!$v.addressData.phone.$each[index].phone.phoneCustomLimit"
                  >{{validationMessages.MIN_LENGTH}} 10</p>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="row">
                <div class="col-md-10">
                  <div class="form-group">
                    <label v-if="index == 0">
                      Extension
                      <i
                        class="icon-help-round-button"
                        data-container="body"
                        data-toggle="popover"
                        data-placement="right"
                        data-content="Help Text Here"
                        data-original-title
                        title
                      ></i>
                    </label>
                    <input type="text" maxlength="8" class="form-control" v-model="contactInfo.ext" />
                    <!-- :readonly="contactInfo.id != 0" -->
                    <div v-if="submitted" class="error-message">
                      <p
                        v-if="!$v.addressData.phone.$each[index].ext.alphaNum"
                      >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
                    </div>
                  </div>
                </div>
                <div class="col-md-2 text-left">
                  <div :class="index == 0 ? 'mt-3 pt-3' : '' " class="form-group mt-1">
                    <a
                      href="javascript:void(0)"
                      @click="removeContactInfo(index)"
                      v-if="index !== addressData.phone.length-1"
                    >
                      <i
                        :class="{'AddDelBtn':contactInfo.isActive && contactInfo.id,'fas fa-trash AddDelBtn':true,'custom-delete-btn':!contactInfo.isActive && contactInfo.id}"
                        aria-hidden="true"
                      ></i>
                    </a>

                    <a
                      href="javascript:void(0)"
                      @click="contactInfo.phone ? addContactInfo() : ''"
                      v-if="index === addressData.phone.length-1"
                    >
                      <i
                        class="icon-model-options AddDelBtn"
                        aria-hidden="true"
                        :class="{'disable-btn':!contactInfo.phone}"
                      ></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="row" v-for="(em, index) in addressData.email">
            <div class="col-md-4">
              <div class="row">
                <div class="col-md-10">
                  <div class="form-group">
                    <label v-if="index == 0">
                      Email
                      <i
                        class="icon-help-round-button"
                        data-container="body"
                        data-toggle="popover"
                        data-placement="right"
                        data-content="Help Text Here"
                        data-original-title
                        title
                      ></i>
                    </label>
                    <input type="text" maxlength="100" class="form-control" v-model="em.email" />
                    <!-- :readonly="em.id != 0" -->
                    <div v-if="submitted" class="error-message">
                      <p
                        v-if="!$v.addressData.email.$each[index].email.isDuplicate"
                      >{{validationMessages.DUPLICATE_VALUES}}</p>
                      <p v-if="emailRequired[index]">{{validationMessages.REQUIRED}}</p>
                      <p
                        v-if="!$v.addressData.email.$each[index].email.email"
                      >{{validationMessages.EMAIL}}</p>
                    </div>
                  </div>
                </div>
                <div class="col-md-2 text-left">
                  <div :class="index == 0 ? 'mt-3 pt-3' : '' " class="form-group mt-1">
                    <a
                      href="javascript:void(0)"
                      @click="removeEmail(index)"
                      v-if="index !== addressData.email.length-1"
                    >
                      <i
                        :class="{'AddDelBtn':em.isActive && em.id,'fas fa-trash AddDelBtn':true,'custom-delete-btn':!em.isActive && em.id}"
                        aria-hidden="true"
                      ></i>
                    </a>
                    <a
                      href="javascript:void(0)"
                      @click="em.email ? addEmail() : ''"
                      v-if="index === addressData.email.length-1"
                    >
                      <i
                        class="icon-model-options AddDelBtn"
                        aria-hidden="true"
                        :class="{'disable-btn':!em.email}"
                      ></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="billing-block page1" data-page="1" v-else>
          <div class="row">
            <div class="col-lg-4 col-md-6 mb-3" v-for="(addressRes, index) in resultAddressLoop">
              <div class="contractsList-block mt-2">
                <div class="row border-bottom">
                  <div class="col-md-6 PrimaryHead">
                    <!-- PRIMARY -->
                  </div>
                  <div class="col-md-6 text-right mb-1">
                    <button
                      type="button"
                      class="delete-btn"
                      @click="deleteBillingShippingAddress(index)"
                    >Delete</button>
                    <button type="button" class="edit-btn" @click="onEditAddress(index)">Edit</button>

                    <!-- <span class="workingBtn">
                      <a
                        href="javascript:void(0)"
                        class="billing-btn-delete"
                        @click="deleteBillingShippingAddress(index)"
                      >
                        <i class="icon-delete" aria-hidden="true"></i>
                        Delete
                      </a>
                    </span>-->
                    <!-- <span class="workingBtn" @click="onEditAddress(index)">
                      <a href="javascript:void(0)" class="billing-btn-delete">
                        <i class="icon-edit-button-icon" aria-hidden="true"></i>
                        Edit
                      </a>
                    </span>-->
                  </div>
                </div>

                <div class="contact-body mt-1">
                  <div class="row">
                    <div class="col-md-12">
                      <strong>Address</strong>
                      <br />
                      {{addressRes.address1}}, {{addressRes.address2}}
                      <br />
                      {{addressRes.city}}, {{addressRes.stateName}}
                      <br />
                      {{addressRes.zip}} {{addressRes.countryName}}
                    </div>
                  </div>
                  <div class="row pt-2">
                    <div class="col-md-6">
                      <strong>Phone (Ext.)</strong>
                      <div
                        v-for="(phone, index) in addressRes.phone"
                      >{{phone.phone}} ({{phone.ext}})</div>
                    </div>

                    <div class="col-md-6">
                      <strong>Email</strong>
                      <div v-for="(email, index) in addressRes.email">{{email.email}}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-3" @click="addNewAddressClicked()">
              <div class="contractsList-block mt-2 vboxCenter">
                <div class="contact-body mt-1">
                  <div class="row">
                    <div class="col-md-12 text-center">
                      <i class="icon-model-options"></i>
                      <br />
                      <strong>Add New Address</strong>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
import Vue from 'vue';
import { DropDownTreeInstaller } from '@progress/kendo-dropdowntree-vue-wrapper';
import { required, email, minLength, alphaNum, numeric, helpers } from 'vuelidate/lib/validators';
import { PatternValidation, customValidation } from '../../../shared/constants/pattern-validation';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import partnerService from '../services/partners-service';
import { PartnersUrls, MasterUrls } from '../../../shared/constants/urls';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

Vue.use(DropDownTreeInstaller);
const alphaNumSpecialValidation = helpers.regex('alphaNumSpecialValidation', PatternValidation.alphaNumSpecialValidation);
const alphawithspace = helpers.regex('alphawithspace', /^[0-9a-zA-Z ]+$/);

const phoneCustomLimit = value => !helpers.req(value) || value.replace(/\D/g, '').substring(0, 10).length === 10;

export default {
  props: {
    heading: {
      type: String
    },
    editMode: {
      type: Boolean
    },
    acordianId: {
      type: String
    },
    saveAddressUrl: {
      type: String
    },
    getAddressUrl: {
      type: String
    }
  },
  data() {
    return {
      submitted: false,
      resultAddressLoop: [],
      validationMessages: VALIDATION_MESSAGE,
      customValidation,
      countyOptions: [],
      stateOptions: [],
      countyDataOptions: [],
      countryOptions: [],
      departmentOptions: [],
      addressDataDepartment: [],
      oldAddressDataDepartment: [],
      addressData: this.createAddressForm(),
      addressObject: [],
      emailRequiredValid: []
    };
  },
  validations: {
    addressData: {
      address1: { required, alphaNumSpecialValidation },
      address2: { alphaNumSpecialValidation },
      city: { required, alphawithspace },
      stateId: { required },
      zip: { required, numeric, minLen: minLength(5) },
      fax: { phoneCustomLimit },
      phone: {
        $each: {
          ext: { alphaNum },
          phone: { phoneCustomLimit }
        }
      },
      email: {
        $each: {
          email: {
            email,
            isDuplicate(email, emailItem) {
              const emailIndex = this.addressData.email.findIndex(item => item.email === email);
              let isEmailDuplicate = true;
              this.addressData.email.forEach((emailObject, index) => {
                if (index !== emailIndex) {
                  if (emailObject.email.trim() === emailItem.email.trim() && emailItem.email.trim() !== '') {
                    isEmailDuplicate = false;
                  }
                }
              });
              return isEmailDuplicate;
            }
          }
        }
      }
    }
  },
  created() {
    if (this.$route.params.id) {
      this.getBillingShippingAddress();
    }
    // console.log(this.editMode, ':::::::::::::::');
    this.getDropdownData();

    this.emailReq();
  },
  computed: {
    countyOptionsResult() {
      const stateId = this.addressData.stateId;
      this.countyOptions = this.countyDataOptions.filter(item => stateId === item.countyStateID);
      return this.countyOptions;
    },
    emailRequired() {
      return this.emailReq();
    }
  },
  methods: {
    emailReq() {
      const lastIndex = this.addressData.email.length - 1;
      const emailRequiredValidation = [];
      if (lastIndex === 0 && this.addressData.email[0].email.trim() === '') {
        emailRequiredValidation[0] = true;
      } else {
        this.addressData.email.forEach((element, index) => {
          if (index !== lastIndex && element.email.trim() === '') {
            emailRequiredValidation.push(true);
          } else {
            emailRequiredValidation.push(false);
          }
        });
      }
      this.emailRequiredValid = emailRequiredValidation;
      return emailRequiredValidation;
    },
    saveAddress() {
      const addressEmail = this.addressData.email;
      const addressPhone = this.addressData.phone;
      this.submitted = true;
      const emailReq = this.emailRequiredValid.filter(item => item === true);
      // console.log(emailReq.length, this.emailRequiredValid, 'kkkk');
      this.$v.$touch();
      if (this.$v.$invalid || emailReq.length > 0) {
        // alert('invalid');
        return;
      }
      /**
       * emailData & phoneData filter is applied for getting length
       * Reason : to show number of affected data in the confirm box
       */
      const emailData = this.addressData.email.filter(res => {
        if (res.id && !res.isActive) {
          return res;
        }
      });
      const phoneData = this.addressData.phone.filter(res => {
        if (res.id && !res.isActive) {
          return res;
        }
      });
      this.addressData.phone = this.addressData.phone.filter((res, index) => {
        if (!res.phone && !res.id) {
          return;
        } else {
          return res;
        }
      });
      this.addressData.email = this.addressData.email.filter((res, index) => {
        if (!res.email && !res.id) {
          return;
        } else {
          return res;
        }
      });

      let emailMsg = '';
      let phoneMsg = '';
      if (emailData.length) emailMsg = `${emailData.length} Email(s) Marked as Deleted. Do you want to continue?`;
      if (phoneData.length) phoneMsg = `${phoneData.length} Phone No.(s) Marked as Deleted. Do you want to continue?`;

      if (emailData.length || phoneData.length) {
        const answer = confirm(`${phoneMsg}\n${emailMsg}`);
        if (!answer) {
          this.addressData.email = addressEmail;
          this.addressData.phone = addressPhone;
          return false;
        }
      }
      this.formatOldNewDepartment();
      if (this.$route.params.id) this.addressData.partnerId = parseInt(this.$route.params.id, 10);
      this.onSaveAddress(this.addressData);
      /**
       * emit onSaveAddress to pass the form input to the component
       */
      this.$emit('onSaveAddress', this.addressData);
    },
    onSaveAddress(event) {
      // this.editMode = false;
      partnerService.postPartnersData(this.saveAddressUrl, event).then(res => {
        showToast('success');
        this.getBillingShippingAddress();
      });
    },
    getBillingShippingAddress() {
      this.resultAddressLoop = [];
      const id = this.$route.params.id;
      partnerService.getPartnersResult(`${this.getAddressUrl}?partnerId=${id}`).then(res => {
        const result = res.data.data;
        result.forEach(data => {
          const phoneArray = [];
          data.phone.forEach(element => {
            const phoneResult = { id: element.id, phone: element.phone, ext: element.ext, isPrimary: false, isActive: element.isActive };
            phoneArray.push(phoneResult);
          });

          const emailArray = [];
          data.email.forEach(element => {
            const emailResult = { id: element.id, email: element.email, isActive: element.isActive };
            emailArray.push(emailResult);
          });

          const departmentArray = [];
          const department = [];
          data.addressDepartment.forEach(element => {
            const departmentResult = { id: element.id, partnerDepartmentId: element.partnerDepartmentId, isActive: element.isActive };
            departmentArray.push(departmentResult);
            department.push(element.partnerDepartmentId);
          });
          this.addressDataDepartment = department;
          console.log(this.addressDataDepartment, 'gggggggggg');
          const addressArray = {
            addressId: data.addressId,
            partnerId: data.partnerId,
            address1: data.address1,
            address2: data.address2,
            city: data.city,
            stateId: data.stateId,
            zip: data.zip,
            countyId: data.countyId,
            countryId: data.countryId,
            countyName: data.countyName,
            countryName: data.countryName,
            stateName: data.stateName,
            fax: data.fax,
            isActive: true,
            userId: 0,
            phone: phoneArray,
            email: emailArray,
            addressDepartment: departmentArray
          };
          this.resultAddressLoop.push(addressArray);
        });
        //console.log(res, '========get billing address=============', this.addressDataArray);
      });
    },
    formatOldNewDepartment() {
      // console.log(this.oldAddressDataDepartment.length, this.addressDataDepartment.length);
      // console.log(this.oldAddressDataDepartment, this.addressDataDepartment);
      // console.log(this.addressObject);
      this.addressData.addressDepartment = [];
      if (this.oldAddressDataDepartment.length) {
        // eslint-disable-next-line arrow-parens
        this.oldAddressDataDepartment.forEach(element => {
          if (this.addressDataDepartment.indexOf(element) === -1) {
            const index = this.addressObject.findIndex(item => item.partnerDepartmentId === element);
            // this.addressData.addressDepartment.splice(index, 1);
            this.addressData.addressDepartment.push({ id: this.addressObject[index].id, partnerDepartmentId: element, isActive: false });
          }
        });
      }
      if (this.addressDataDepartment.length) {
        // eslint-disable-next-line arrow-parens
        this.addressDataDepartment.forEach(element => {
          if (this.oldAddressDataDepartment.length) {
            if (this.oldAddressDataDepartment.indexOf(element) === -1) {
              this.addressData.addressDepartment.push({ id: 0, partnerDepartmentId: element, isActive: true });
            } else {
              const index = this.addressObject.findIndex(item => item.partnerDepartmentId === element);
              // this.addressData.addressDepartment.splice(index, 1);
              this.addressData.addressDepartment.push({ id: this.addressObject[index].id, partnerDepartmentId: element, isActive: true });
              // console.log(index, element);
            }
          } else {
            this.addressData.addressDepartment.push({ id: 0, partnerDepartmentId: element, isActive: true });
          }
        });
      }
    },
    deleteBillingShippingAddress(index) {
      const answer = window.confirm('Are you sure, you want to delete?');
      if (answer) {
        const body = {
          addressId: this.resultAddressLoop[index].addressId,
          partnerId: this.resultAddressLoop[index].partnerId,
          userId: this.resultAddressLoop[index].userId
        };
        partnerService.postPartnersData(`${PartnersUrls.DELETE_PARTNERS_ADDRESS}`, body).then(() => {
          // console.log(res, '===============delete partners address===============');
          this.submitted = false;
          this.$v.$reset();
          this.resultAddressLoop.splice(index, 1);
          // this.$emit('onDeleteAddress');
        });
      }
    },
    onEditAddress(index) {
      this.addressData = this.resultAddressLoop[index];
      const department = [];
      this.addressData.addressDepartment.forEach(element => {
        department.push(element.partnerDepartmentId);
      });
      this.addressDataDepartment = department;
      this.addressData.email.push({ id: 0, email: '', isActive: true });
      this.addressData.phone.push({ id: 0, phone: '', ext: '', isPrimary: false, isActive: true });
      this.$emit('onEditAddress');
    },
    cancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.getBillingShippingAddress();
        this.$emit('onCancelClicked');
      }
      return false;
    },
    addNewAddressClicked() {
      this.submitted = false;
      this.addressData = this.createAddressForm();
      this.$emit('onAddNewAddressClicked');
    },
    /**
     * addContactInfo() add dynamic input for contact info
     */
    addContactInfo() {
      const newContactInfo = { id: 0, phone: '', ext: '', isPrimary: false, isActive: true };
      this.addressData.phone.push(newContactInfo);
    },
    /**
     * removeContactInfo() remove dynamic input for contact info
     */
    removeContactInfo(index) {
      if (this.addressData.phone[index].id) {
        this.addressData.phone[index].isActive = !this.addressData.phone[index].isActive;
      } else {
        this.addressData.phone = this.addressData.phone.filter((res, i) => i !== index);
      }
    },
    /**
     * addContactInfo() add dynamic input for contact info
     */
    addEmail() {
      const newEmail = { id: 0, email: '', isActive: true };
      this.addressData.email.push(newEmail);
    },
    /**
     * removeContactInfo() remove dynamic input for contact info
     */
    removeEmail(index) {
      if (this.addressData.email[index].id) {
        this.addressData.email[index].isActive = !this.addressData.email[index].isActive;
      } else {
        this.addressData.email = this.addressData.email.filter((res, i) => i !== index);
      }
    },
    getDropdownData() {
      partnerService
        .getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=State%7CCountry%7CCounty`)
        // eslint-disable-next-line arrow-parens
        .then(res => {
          const result = res.data.data;
          this.stateOptions = result.State;
          this.countyDataOptions = result.County;
          this.countryOptions = result.Country;
        });

      //* *******----------------DEpartment Mockup data api */
      if (this.$route.params.id) {
        partnerService
          .getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Departments&id=${this.$route.params.id}`)
          // eslint-disable-next-line arrow-parens
          .then(res => {
            // console.log(res, res.data.Departments, '============department=========');
            const partnerSpecificDepartment = res.data.data.Departments;
            if (partnerSpecificDepartment) {
              // eslint-disable-next-line arrow-parens
              partnerSpecificDepartment.forEach(element => {
                this.departmentOptions.push({ text: element.entityName, value: element.entityID });
              });
            }
          });
      }
    },
    createAddressForm() {
      return {
        addressId: 0,
        partnerId: 0,
        address1: '',
        address2: '',
        city: '',
        stateId: '',
        zip: null,
        countyId: null,
        countryId: 1,
        fax: '',
        isActive: true,
        userId: 0,
        phone: [{ id: 0, phone: '', ext: '', isPrimary: true, isActive: true }],
        email: [{ id: 0, email: '', isActive: true }],
        addressDepartment: []
      };
    },
    /**
     * formattedPhone(event, key) formatting phone to (XXX)-XXX-XXXX
     * event is used for passing current input value
     * key is used to pass the input name
     *
     */
    formattedPhone(event, skey, index) {
      if (index) {
        this.addressData.phone[index - 1].phone = this.customValidation.formattedPhone(event.$model.phone);
      } else {
        this.addressData[skey] = this.customValidation.formattedPhone(event);
      }
    }
    /** -----------END---------- */
  }
};
</script>

<style>
.disabled-class {
  background-color: #ececec;
  border: solid 1px #c5c5c5;
  color: #60666c;
  cursor: not-allowed;
}
.k-checkbox:checked {
  border-color: #0053a0;
  background-color: #0053a0;
}
</style>
