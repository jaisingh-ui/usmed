<template>
  <CommonBillingShipping
    :heading="heading"
    :acordianId="acordianId"
    :editMode="editMode"
    :saveAddressUrl="saveAddressUrl"
    :getAddressUrl="getAddressUrl"
    @onEditAddress="editMode = true"
    @onSaveAddress="editMode = false;"
    @onCancelClicked="editMode = false"
    @onAddNewAddressClicked="editMode = true"
  ></CommonBillingShipping>
</template>
<script>
/* eslint-disable */
import CommonBillingShipping from './CommonBillingShipping';
import partnerService from '../services/partners-service';
import { PartnersUrls } from '../../../shared/constants/urls';

export default {
  components: {
    CommonBillingShipping
  },
  data() {
    return {
      heading: 'Shipping Address',
      saveAddressUrl: PartnersUrls.SAVE_SHIPING_ADDRESS,
      getAddressUrl: PartnersUrls.GET_SHIPING_ADDRESS,
      editMode: false,
      acordianId: 'shippingAddress1'
    };
  }
};
</script>