<template>
  <div class="card">
    <div class="card-header" id="headingNine">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseNine"
          aria-expanded="false"
          aria-controls="collapseNine"
        >Flags</button>
      </h5>
      <div class="rightInfotext">
        <i class="fa fa-angle-down" data-toggle="collapse" data-target="#collapseNine"></i>
      </div>
    </div>
    <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordion">
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid rgb(239, 239, 239);">
          <div class="col-md-12 text-right mb-1 mt-1">
            <button v-if="!editMode" type="button" class="edit-btn" @click="editMode = true">Edit</button>
            <div v-else>
              <button type="button" class="save-btn mr-1" @click="savePartnersFlag()">Save</button>
              <button type="button" class="cancel-btn" @click="cancelClicked()">Cancel</button>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck1112"
                    @change="paperTktRequired()"
                    :checked="partnerFlag.paperTktRequired"
                  />
                  <label class="custom-control-label" for="customCheck1112">Paper Ticket Required</label>
                  <small>(If Checked, Manual Printouts are Required for that Partner)</small>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck2"
                    @change="callLogAccepted()"
                    :checked="partnerFlag.callLogAccepted"
                  />
                  <label class="custom-control-label" for="customCheck2">Call Log Accepted</label>
                  <small>(Notification to Partner)</small>
                </div>
              </div>
              <!--<input type="text" class="form-control" id="" placeholder="Commitment" value="">-->
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck3"
                    @change="showPreliminaryInvOnPartnerPortal()"
                    :checked="partnerFlag.showPreliminaryInvOnPartnerPortal"
                  />
                  <label
                    class="custom-control-label"
                    for="customCheck3"
                  >Show Preliminary Invoice on Partner Portal</label>
                </div>
              </div>
              <!--<input type="text" class="form-control" id="" placeholder="Commitment" value="">-->
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck4"
                    @change="rcvDelPickupTicketsOnMail()"
                    :checked="partnerFlag.rcvDelPickupTicketsOnMail"
                  />
                  <label
                    class="custom-control-label"
                    for="customCheck4"
                  >Receive Delivery/ Pickup Tickets on Mail</label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck5"
                    @change="qualforStandbyProduct()"
                    :checked="partnerFlag.qualforStandbyProduct"
                  />
                  <label
                    class="custom-control-label"
                    for="customCheck5"
                  >Qualified for Standby Product</label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck6"
                    @change="fullCallerInformation()"
                    :checked="partnerFlag.fullCallerInformation"
                  />
                  <label class="custom-control-label" for="customCheck6">Full Caller Information</label>
                  <small>(Full Name, Phone Number and Email)</small>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck7"
                    @change="useHeaters()"
                    :checked="partnerFlag.useHeaters"
                  />
                  <label class="custom-control-label" for="customCheck7">Use Heaters</label>
                  <small>(Prompt Dispatch to Ask for Heaters)</small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck8"
                    @change="takeDisposablesWithRental()"
                    :checked="partnerFlag.takeDisposablesWithRental"
                  />
                  <label
                    class="custom-control-label"
                    for="customCheck8"
                  >Take Disposables with Rental</label>
                  <small>(Prompt Dispatch and Branch to Add Disposables in the Order)</small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck9"
                    @change="acceptEmailDocs()"
                    :checked="partnerFlag.acceptEmailDocs"
                  />
                  <label class="custom-control-label" for="customCheck9">Accept Email Docs</label>
                  <small>(Email, Invoices, Proposals etc., if True Send Email else do not Send Emails)</small>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck10"
                    @change="useLegalNameOnInvoice()"
                    :checked="partnerFlag.useLegalNameOnInvoice"
                  />
                  <label class="custom-control-label" for="customCheck10">Use Legal Name on Invoice</label>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import partnerService from '../services/partners-service';
import { PartnersUrls } from '../../../shared/constants/urls';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

export default {
  data() {
    return {
      validationMessages: VALIDATION_MESSAGE,
      partnerFlag: {
        partnerID: this.$route.params.id,
        paperTktRequired: false,
        callLogAccepted: false,
        showPreliminaryInvOnPartnerPortal: false,
        rcvDelPickupTicketsOnMail: false,
        qualforStandbyProduct: false,
        fullCallerInformation: false,
        useHeaters: false,
        takeDisposablesWithRental: false,
        acceptEmailDocs: false,
        useLegalNameOnInvoice: false,
        userId: 1
      },
      editMode: false
    };
  },
  methods: {
    paperTktRequired() {
      this.partnerFlag.paperTktRequired = !this.partnerFlag.paperTktRequired;
    },
    callLogAccepted() {
      this.partnerFlag.callLogAccepted = !this.partnerFlag.callLogAccepted;
    },
    showPreliminaryInvOnPartnerPortal() {
      this.partnerFlag.showPreliminaryInvOnPartnerPortal = !this.partnerFlag.showPreliminaryInvOnPartnerPortal;
    },
    rcvDelPickupTicketsOnMail() {
      this.partnerFlag.rcvDelPickupTicketsOnMail = !this.partnerFlag.rcvDelPickupTicketsOnMail;
    },
    qualforStandbyProduct() {
      this.partnerFlag.qualforStandbyProduct = !this.partnerFlag.qualforStandbyProduct;
    },
    fullCallerInformation() {
      this.partnerFlag.fullCallerInformation = !this.partnerFlag.fullCallerInformation;
    },
    useHeaters() {
      this.partnerFlag.useHeaters = !this.partnerFlag.useHeaters;
    },
    takeDisposablesWithRental() {
      this.partnerFlag.takeDisposablesWithRental = !this.partnerFlag.takeDisposablesWithRental;
    },
    acceptEmailDocs() {
      this.partnerFlag.acceptEmailDocs = !this.partnerFlag.acceptEmailDocs;
    },
    useLegalNameOnInvoice() {
      this.partnerFlag.useLegalNameOnInvoice = !this.partnerFlag.useLegalNameOnInvoice;
    },
    getPartnerFlag(id) {
      /**
       * this scope of code get executed for getting partners flags
       */
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNER_FLAG}?partnerId=${id}`).then(res => {
        // console.log(res, 'get response flag');
        if (res.data.apiResponseStatus !== 'Failed' && res.data && res.data.data) {
          this.partnerFlag = res.data.data;
          // this.$emit('onShowHideLoader', false);
          // this.editMode = true;
        }
      });
    },
    cancelClicked() {
      // eslint-disable-next-line no-alert
      const cancel = showWindowConfrim();
      if (cancel) {
        this.getPartnerFlag(this.$route.params.id);
        this.editMode = false;
      }
      return false;

      // this.getPartnerFlag(this.partnerFlag.partnerID);
    },
    savePartnersFlag() {
      this.editMode = false;
      this.callAPItoSavePartnerFlag();
    },
    callAPItoSavePartnerFlag() {
      this.partnerFlag.partnerID = parseInt(this.$route.params.id, 10);
      // eslint-disable-next-line arrow-parens
      partnerService.postPartnersDataAction(`${PartnersUrls.SAVE_PARTNER_FLAG}`, this.partnerFlag).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.editMode = false;
          showToast('success');
        }
        // this.getPartnerFlag(this.partnerFlag.partnerID);
      });
    }
  },
  created() {
    if (this.$route.params.id) {
      this.partnerFlag.partnerID = parseInt(this.$route.params.id, 10);
      // call get API
      this.getPartnerFlag(this.partnerFlag.partnerID);
    }
  }
};
</script>