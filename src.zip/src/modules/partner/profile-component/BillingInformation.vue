<template>
  <div class="card">
    <div class="card-header" id="headingFive">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseFive"
          aria-expanded="false"
          aria-controls="collapseFive"
        >Billing Information</button>
      </h5>
      <div class="rightInfotext">
        <i class="fa fa-angle-down" data-toggle="collapse" data-target="#collapseFive"></i>
      </div>
    </div>
    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordion">
      <div class="card-body">
        <div class="row">
          <div class="col-md-12 text-right mb-1 mt-1">
            <button v-if="!editMode" type="button" class="edit-btn" @click="editMode = true">Edit</button>
            <div v-else>
              <button
                type="button"
                class="save-btn mr-1"
                @click="savePartnerBillingInformation()"
              >Save</button>
              <button type="button" class="cancel-btn" @click="cancelClicked()">Cancel</button>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Payment and Credit Information
                <i
                  aria-hidden="true"
                  title="Payment and Credit Information"
                  class="fa fa-info-circle"
                ></i>
              </label>

              <kendo-dropdowntree
                :disabled="!editMode"
                :class="{'disabled-class':!editMode, 'form-control':true}"
                v-model="partnerBillingInformation.paymentCreditInformation"
                :data-source="paymentInformation"
                :checkboxes="true"
                :check-all="false"
                :placeholder="'Select'"
              ></kendo-dropdowntree>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.partnerBillingInformation.paymentCreditInformation.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Credit Limit
                <i aria-hidden="true" title="Credit Limit" class="fa fa-info-circle"></i>
              </label>
              <input
                :disabled="!editMode"
                type="number"
                class="form-control"
                v-model="partnerBillingInformation.creditLimit"
                @keypress="isNumber($event)"
                maxlength="10"
                placeholder="00.00"
                step="0.50"
                min="0.10"
              />
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.partnerBillingInformation.creditLimit.checkDecimal"
                >{{validationMessages.DECIMAL}}</p>
                <p
                  v-if="!$v.partnerBillingInformation.creditLimit.maxLength"
                >{{validationMessages.MAX_LENGTH}} 13 digits.</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Close Bill Cycle On
                <i
                  aria-hidden="true"
                  title="Close Bill Cycle On"
                  class="fa fa-info-circle"
                ></i>
              </label>
              <input
                :disabled="!editMode"
                type="number"
                min="1"
                max="27"
                step="1"
                maxlength="2"
                @keypress="isStraightNumber($event)"
                v-model.number="partnerBillingInformation.billingCycleDay"
                class="form-control"
              />
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.partnerBillingInformation.billingCycleDay.checkRange"
                >{{validationMessages.RANGE}}</p>
                <p
                  v-if="!$v.partnerBillingInformation.billingCycleDay.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Billing Period
                <i
                  aria-hidden="true"
                  title="Billing Period"
                  class="fa fa-info-circle"
                ></i>
              </label>
              <select
                :disabled="!editMode"
                v-model="partnerBillingInformation.billingCycleId"
                class="form-control"
              >
                <option value>Select</option>
                <option
                  v-for="bPeriod in billingPeriod"
                  :value="bPeriod.entityID"
                  :key="bPeriod.entityID"
                >{{ bPeriod.entityName }}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.partnerBillingInformation.billingCycleId.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Billing Term
                <i aria-hidden="true" title="Billing Term" class="fa fa-info-circle"></i>
              </label>
              <select
                v-on:change="updateDescription"
                :disabled="!editMode"
                v-model="partnerBillingInformation.billingTermsId"
                class="form-control"
              >
                <option value>Select</option>
                <option v-for="bTerm in billingTerm" :value="bTerm.entityID">{{ bTerm.entityName }}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.partnerBillingInformation.billingTermsId.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Description of Billing Term
                <i
                  aria-hidden="true"
                  title="Description of Billing Term"
                  class="fa fa-info-circle"
                ></i>
              </label>
              <input
                :disabled="!editMode"
                type="text"
                class="form-control"
                readonly
                v-model="partnerBillingInformation.termDescription"
              />
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                PO Required
                <i aria-hidden="true" title="PO Required" class="fa fa-info-circle"></i>
              </label>
              <select
                :disabled="!editMode"
                v-model="partnerBillingInformation.poRequiredLevelId"
                class="form-control"
              >
                <option value>Select</option>
                <option v-for="poReq in poRequired" :value="poReq.entityID">{{ poReq.entityName }}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.partnerBillingInformation.poRequiredLevelId.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label></label>
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    :checked="partnerBillingInformation.isAutoSplitInvoice"
                    class="custom-control-input"
                    id="customCheck11"
                    @change="checkbocPartnerBillingInformation()"
                  />
                  <label class="custom-control-label" for="customCheck11">
                    Auto Split
                    Invoices
                  </label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>
                Split By
                <i aria-hidden="true" title="By" class="fa fa-info-circle"></i>
              </label>
              <select
                :disabled="!editMode || !partnerBillingInformation.isAutoSplitInvoice"
                v-model="partnerBillingInformation.splitBillingTypeID"
                class="form-control"
              >
                <option value>Select</option>
                <option v-for="byOpt in byOptions" :value="byOpt.entityID">{{byOpt.entityName}}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.partnerBillingInformation.splitBillingTypeID.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
import Vue from 'vue';
import { required, requiredIf, maxLength } from 'vuelidate/lib/validators';
import { DropDownTreeInstaller } from '@progress/kendo-dropdowntree-vue-wrapper';
import { PartnersUrls, MasterUrls } from '../../../shared/constants/urls';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import partnerService from '../services/partners-service';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

Vue.use(DropDownTreeInstaller);

export default {
  data() {
    return {
      validationMessages: VALIDATION_MESSAGE,
      submitted: false,
      editMode: false,
      partnerBillingInformation: {
        partnerId: 0,
        paymentCreditInformation: [],
        isCompanyCheck: false,
        isCheck: false,
        isCOD: false,
        isRentalCap: false,
        isCreditCard: false,
        creditLimit: 0,
        billingCycleDay: 0,
        billingCycleId: 0,
        billingTermsId: 0,
        termDescription: '',
        poRequiredLevelId: 0,
        isAutoSplitInvoice: false,
        splitBillingTypeID: '',
        userId: 1
      },
      paymentInformation: [
        { text: 'Company Check', value: 1 },
        { text: 'Check', value: 2 },
        { text: 'COD', value: 3 },
        { text: 'Enforce Rental Cap', value: 4 },
        { text: 'Credit Card', value: 5 }
      ],
      billingPeriod: [],
      billingTerm: [],
      poRequired: [],
      byOptions: []
    };
  },
  validations: {
    partnerBillingInformation: {
      paymentCreditInformation: { required },
      billingTermsId: { required },
      billingCycleId: { required },
      poRequiredLevelId: { required },
      splitBillingTypeID: {
        required: requiredIf(function(vm) {
          if (vm.isAutoSplitInvoice === true) {
            return true;
          }
          return false;
        })
      },
      creditLimit: {
        checkDecimal(value) {
          if (value === '' || typeof value === 'undefined') return true;
          return /^\d+(\.\d{0,2})?$/.test(value);
        },
        maxLength: maxLength(13)
      },
      billingCycleDay: {
        checkRange(value) {
          if (value === '' || typeof value === 'undefined') return true;
          return value >= 1 && value < 28;
        },
        required: requiredIf(function(vm) {
          if (vm.billingCycleDay === '') {
            return true;
          }
          return false;
        })
      }
    }
  },
  watch: {
    $route(to, from) {
      if (this.$route.params.id) {
        this.getDropdownData();
        this.getPartnerBillingInformation(this.$route.params.id);
      }
    }
  },
  methods: {
    /**
     * Stop User to insert -.+ amd etc signs
     */
    isNumber: function(evt) {
      evt = evt ? evt : window.event;
      var charCode = evt.which ? evt.which : evt.keyCode;
      //if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode !== 46 && (charCode === 101 || charCode === 69)) {
      if ((evt.which != 8 && evt.which !== 46 && evt.which != 0 && evt.which < 48) || evt.which > 57) {
        evt.preventDefault();
      } else {
        return true;
      }
    },
    isStraightNumber: function(evt) {
      evt = evt ? evt : window.event;
      var charCode = evt.which ? evt.which : evt.keyCode;
      // if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode === 46 && (charCode === 101 || charCode === 69)) {
      if ((evt.which != 8 && evt.which != 0 && evt.which < 48) || evt.which > 57) {
        evt.preventDefault();
      } else {
        return true;
      }
    },
    checkbocPartnerBillingInformation() {
      this.partnerBillingInformation.isAutoSplitInvoice = !this.partnerBillingInformation.isAutoSplitInvoice;
      if (this.partnerBillingInformation.isAutoSplitInvoice === true) {
        this.partnerBillingInformation.splitBillingTypeID = '';
      } else if (this.partnerBillingInformation.isAutoSplitInvoice === false) {
        this.partnerBillingInformation.splitBillingTypeID = '';
      }
    },
    getPartnerBillingInformation(partnerId) {
      partnerService.getPartnersResult(`${PartnersUrls.GET_BILLING_INFO}?partnerId=${partnerId}`).then(res => {
        if (res.data.data !== null) {
          const result = res.data.data;
          this.partnerBillingInformation.partnerId = Number(this.$route.params.id);
          this.partnerBillingInformation.isCompanyCheck = result.isCompanyCheck;
          this.partnerBillingInformation.isCheck = result.isCheck;
          this.partnerBillingInformation.isCOD = result.isCOD;
          this.partnerBillingInformation.isRentalCap = result.isRentalCap;
          this.partnerBillingInformation.isCreditCard = result.isCreditCard;
          this.partnerBillingInformation.creditLimit = parseFloat(result.creditLimit).toFixed(2);
          this.partnerBillingInformation.billingCycleDay = result.billingCycleDay;
          this.partnerBillingInformation.billingCycleId = result.billingCycleId;
          this.partnerBillingInformation.billingTermsId = result.billingTermsId;
          this.partnerBillingInformation.termDescription = result.termDescription;
          this.partnerBillingInformation.poRequiredLevelId = result.poRequiredLevelId;
          this.partnerBillingInformation.isAutoSplitInvoice = result.isAutoSplitInvoice;
          this.partnerBillingInformation.splitBillingTypeID = result.splitBillingTypeID;
          this.partnerBillingInformation.userId = 1;

          //MultiSelect Options for Payment and credit information

          const filteredPaymentinformation = [
            result.isCompanyCheck ? 1 : '',
            result.isCheck ? 2 : '',
            result.isCOD ? 3 : '',
            result.isRentalCap ? 4 : '',
            result.isCreditCard ? 5 : ''
          ];

          this.partnerBillingInformation.paymentCreditInformation = filteredPaymentinformation.filter(function(el) {
            return el !== '';
          });
        } else {
          //To-Do Cross check when user doesn't contains any data
          this.partnerBillingInformation.partnerId = Number(this.$route.params.id);
          this.partnerBillingInformation.creditLimit = 0.0;
          this.partnerBillingInformation.billingCycleDay = 1;
          this.partnerBillingInformation.billingCycleId = 3;
          this.partnerBillingInformation.billingTermsId = 3;
          this.partnerBillingInformation.termDescription = 'Net 30 days';
          this.partnerBillingInformation.poRequiredLevelId = 1;
          this.partnerBillingInformation.isAutoSplitInvoice = false;
          this.partnerBillingInformation.splitBillingTypeID = '';
          this.partnerBillingInformation.userId = 1;

          //MultiSelect Options for Payment and credit information
          this.partnerBillingInformation.paymentCreditInformation = [1];
        }
      });
    },
    updateDescription() {
      if (this.partnerBillingInformation.billingTermsId === 1) {
        this.partnerBillingInformation.termDescription = 'Cash';
      } else if (this.partnerBillingInformation.billingTermsId === 2) {
        this.partnerBillingInformation.termDescription = 'Cash on Delivery';
      } else if (this.partnerBillingInformation.billingTermsId === 3) {
        this.partnerBillingInformation.termDescription = 'Net 30 days';
      } else {
        this.partnerBillingInformation.termDescription = '';
      }
    },
    savePartnerBillingInformation() {
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      }

      //Make String to Float
      this.partnerBillingInformation.creditLimit = parseFloat(this.partnerBillingInformation.creditLimit);
      if (isNaN(this.partnerBillingInformation.creditLimit)) {
        return false;
      }
      for (let i = 0; i <= this.paymentInformation.length - 1; i++) {
        if (this.partnerBillingInformation.paymentCreditInformation.includes(1)) {
          this.partnerBillingInformation.isCompanyCheck = true;
        } else {
          this.partnerBillingInformation.isCompanyCheck = false;
        }
        if (this.partnerBillingInformation.paymentCreditInformation.includes(2)) {
          this.partnerBillingInformation.isCheck = true;
        } else {
          this.partnerBillingInformation.isCheck = false;
        }
        if (this.partnerBillingInformation.paymentCreditInformation.includes(3)) {
          this.partnerBillingInformation.isCOD = true;
        } else {
          this.partnerBillingInformation.isCOD = false;
        }
        if (this.partnerBillingInformation.paymentCreditInformation.includes(4)) {
          this.partnerBillingInformation.isRentalCap = true;
        } else {
          this.partnerBillingInformation.isRentalCap = false;
        }
        if (this.partnerBillingInformation.paymentCreditInformation.includes(5)) {
          this.partnerBillingInformation.isCreditCard = true;
        } else {
          this.partnerBillingInformation.isCreditCard = false;
        }
      }

      if (this.partnerBillingInformation.billingCycleId === 'Select Billing Period') {
        this.partnerBillingInformation.billingCycleId = 0;
      }

      if (this.partnerBillingInformation.splitBillingTypeID === '') {
        this.partnerBillingInformation.splitBillingTypeID = null;
      }

      partnerService.postPartnersDataAction(`${PartnersUrls.SAVE_BILLING_INFO}`, this.partnerBillingInformation).then(res => {
        if (res) {
          this.submitted = false;
          this.editMode = false;
          showToast('success');
          this.getPartnerBillingInformation(this.partnerBillingInformation.partnerId);
        }
      });
    },
    cancelClicked() {
      // cancel method
      const cancel = showWindowConfrim();
      if (cancel) {
        if (this.$route.params.id) {
          this.editMode = false;
          this.getPartnerBillingInformation(this.$route.params.id);
        }
      }
      return false;
    },
    getDropdownData() {
      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=BillingPeriod%7CBillingTerm%7CBy%7CPORequired`).then(res => {
        this.billingPeriod = res.data.data.BillingPeriod;
        this.byOptions = res.data.data.By;
        this.poRequired = res.data.data.PORequired;
        this.billingTerm = res.data.data.BillingTerm;
      });
    }
  },
  async created() {
    await this.getDropdownData();
    if (this.$route.params.id) {
      this.getPartnerBillingInformation(this.$route.params.id);
    }
  }
};
</script>