<template>
  <!-- right pannel section -->
  <div id="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="searchArea">
            <div class="row">
              <div class="col-lg-10 col-md-9">
                <h1 class="pageName">
                  {{headerData.head}} :
                  <span>{{headerData.name}}</span> &nbsp;
                  <span style="color:#000; font-size:15px;">(# {{headerData.id}})</span>
                  <span class="statusText">Status : {{headerData.status}}</span>
                </h1>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <div id="accordion">
              <div class="card">
                <div class="card-header">
                  <h5 class="mb-0">
                    <button class="btn btn-link">Partner Pricing Information</button>
                  </h5>
                </div>
                <div
                  id="collapseTwo"
                  class="collapse show"
                  aria-labelledby="headingTwo"
                  data-parent="#accordion"
                  style
                >
                  <div class="card-body">
                    <div class="row">
                      <div class="col-md-12 text-right mb-1 mt-1">
                        <button
                          v-if="editMode"
                          type="button"
                          class="edit-btn"
                          @click="editMode = false"
                        >Edit</button>
                        <div v-else>
                          <button
                            type="button"
                            class="save-btn mr-1"
                            @click="savePartnersPricing()"
                          >Save</button>
                          <button type="button" class="cancel-btn" @click="cancelClicked()">Cancel</button>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label>
                            Manufacturer
                            <i
                              class="icon-help-round-button"
                              data-container="body"
                              data-toggle="popover"
                              data-placement="right"
                              data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                              data-original-title
                              title
                            ></i>
                          </label>
                          <select
                            id="inputState"
                            class="form-control"
                            v-model="partnerPricing.manufacturerID"
                            :disabled="editMode || $route.params.MID"
                          >
                            <option :value="null">Select</option>
                            <option
                              v-for="manufacturer in manufacturerOptions"
                              :value="manufacturer.entityID"
                            >{{ manufacturer.entityName }}</option>
                          </select>
                          <div v-if="submitted" class="error-message">
                            <p
                              v-if="!$v.partnerPricing.manufacturerID.required"
                            >{{validationMessages.REQUIRED}}</p>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label>
                            Model Common Name
                            <i class="icon-help-round-button"></i>
                          </label>
                          <select
                            id="inputState"
                            class="form-control"
                            :disabled="editMode || $route.params.MID"
                            v-model="partnerPricing.modelID"
                          >
                            <option :value="null">Select</option>
                            <option
                              v-for="model in manufacturerModelResult"
                              :value="model.entityID"
                            >{{ model.entityName }}</option>
                          </select>
                          <div v-if="submitted" class="error-message">
                            <p
                              v-if="!$v.partnerPricing.modelID.required"
                            >{{validationMessages.REQUIRED}}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label>
                            Daily Price
                            <i class="icon-help-round-button"></i>
                          </label>
                          <input
                            type="number"
                            class="form-control"
                            :disabled="editMode"
                            v-model="partnerPricing.dailyPrice"
                          />
                          <div v-if="submitted" class="error-message">
                            <p
                              v-if="!$v.partnerPricing.dailyPrice.required"
                            >{{validationMessages.REQUIRED}}</p>
                            <p
                              v-if="!$v.partnerPricing.dailyPrice.numericUpToTwoDecimal"
                            >{{validationMessages.TWO_DIGIT_NUMERIC}}</p>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label>
                            Monthly Price
                            <i
                              class="icon-help-round-button"
                              data-container="body"
                              data-toggle="popover"
                              data-placement="right"
                              data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                              data-original-title
                              title
                            ></i>
                          </label>
                          <input
                            type="number"
                            class="form-control"
                            :disabled="editMode"
                            v-model="partnerPricing.monthlyRentalPrice"
                            @change="calculateDailyPrice()"
                          />
                          <div v-if="submitted" class="error-message">
                            <p
                              v-if="!$v.partnerPricing.monthlyRentalPrice.required"
                            >{{validationMessages.REQUIRED}}</p>
                            <p
                              v-if="!$v.partnerPricing.monthlyRentalPrice.numericUpToTwoDecimal"
                            >{{validationMessages.TWO_DIGIT_NUMERIC}}</p>
                          </div>
                        </div>
                      </div>

                      <div class="col-md-4">
                        <div class="form-group">
                          <label>
                            Sales Price
                            <i
                              class="icon-help-round-button"
                              data-container="body"
                              data-toggle="popover"
                              data-placement="right"
                              data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                              data-original-title
                              title
                            ></i>
                          </label>
                          <input
                            type="number"
                            class="form-control"
                            :disabled="editMode"
                            v-model="partnerPricing.salePrice"
                          />
                          <div v-if="submitted" class="error-message">
                            <p
                              v-if="!$v.partnerPricing.salePrice.numericUpToTwoDecimal"
                            >{{validationMessages.TWO_DIGIT_NUMERIC}}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-md-4" style="display:inline-block">
                        <div class="form-group" style="display: inline-block; width:92%">
                          <label>
                            Proposal Number
                            <i
                              class="icon-help-round-button"
                              data-container="body"
                              data-toggle="popover"
                              data-placement="right"
                              data-original-title
                              title
                            ></i>
                          </label>
                          <select
                            id="inputState"
                            class="form-control"
                            :disabled="editMode"
                            v-model="partnerPricing.proposalID"
                          >
                            <option :value="null">Select</option>
                            <option
                              v-for="proposal in proposalOptions"
                              :value="proposal.entityID"
                            >{{ proposal.entityName }}</option>
                          </select>
                          <div v-if="submitted" class="error-message">
                            <p
                              v-if="!$v.partnerPricing.proposalID.required"
                            >{{validationMessages.REQUIRED}}</p>
                          </div>
                        </div>&nbsp;
                        <div style="display: inline-block;">
                          <a href="http://www.orimi.com/pdf-test.pdf" target="_blank">
                            <i class="fas fa-external-link-square-alt" aria-hidden="true"></i>
                          </a>
                        </div>
                      </div>
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>
                            Comments
                            <i
                              class="icon-help-round-button"
                              data-container="body"
                              data-toggle="popover"
                              data-placement="right"
                              data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                              data-original-title
                              title
                            ></i>
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            :disabled="editMode"
                            v-model="partnerPricing.description"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import { required, requiredIf, helpers } from 'vuelidate/lib/validators';
import partnerService from './services/partners-service';
import { PatternValidation } from '../../shared/constants/pattern-validation';
import VALIDATION_MESSAGE from '../../shared/constants/messages';
import { showToast } from '../../shared/services/toast-service';
import { PartnersUrls, MasterUrls } from '../../shared/constants/urls';

import { showWindowConfrim } from '../../shared/services/window-confrim';

const numericUpToTwoDecimal = helpers.regex('numericUpToTwoDecimal', PatternValidation.numericUpToTwoDecimal);

export default {
  data() {
    return {
      editMode: true,
      validationMessages: VALIDATION_MESSAGE,
      submitted: false,
      // manufacturerID: null,
      partnerPricing: this.createAddEditPricingForm(),
      manufacturerOptions: [],
      proposalOptions: [],
      modelDataOptions: [],
      modelOptions: [],
      statusOptions: [],
      headerData: {
        head: 'Partner Pricing',
        id: '',
        name: '',
        status: ''
      }
    };
  },
  validations: {
    partnerPricing: {
      manufacturerID: { required },
      modelID: {
        required: requiredIf(function() {
          if (this.partnerPricing.manufacturerID !== null && this.partnerPricing.modelID === null) {
            return true;
          }
          return false;
        })
      },
      dailyPrice: { required, numericUpToTwoDecimal },
      monthlyRentalPrice: { required, numericUpToTwoDecimal },
      salePrice: { numericUpToTwoDecimal },
      proposalID: { required }
      // description: {}
    }
  },
  async created() {
    await this.getDropdownData();
    this.getPartnersInfo(this.$route.params.id);

    this.getDropdownData();
    if (this.$route.params.MID) {
      const MID = this.$route.params.MID;
      this.getPartnersPricing();
    } else {
      this.editMode = false;
    }
    // console.log(this.$route.params, '======');
  },
  computed: {
    manufacturerModelResult() {
      const manufacturer = this.partnerPricing.manufacturerID;
      this.modelOptions = this.modelDataOptions.filter(item => manufacturer === item.ManufacturerID);
      return this.modelOptions;
    }
  },
  methods: {
    savePartnersPricing() {
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      }
      this.partnerPricing.partnerId = parseInt(this.$route.params.id, 10);
      this.partnerPricing.dailyPrice = parseFloat(this.partnerPricing.dailyPrice);
      this.partnerPricing.monthlyRentalPrice = parseFloat(this.partnerPricing.monthlyRentalPrice);
      if (this.partnerPricing.salePrice) this.partnerPricing.salePrice = parseFloat(this.partnerPricing.salePrice);
      // console.log(this.partnerPricing, !this.$route.params.MID);
      // eslint-disable-next-line arrow-parens
      partnerService.postPartnersData(`${PartnersUrls.SAVE_PARTNER_PRICING}`, this.partnerPricing).then(res => {
        const result = res.data.data;
        showToast('success');
        this.editMode = true;
        if (!this.$route.params.MID) {
          this.$router.push(`/partners/manage-partner-pricing/${this.partnerPricing.partnerId}/${this.partnerPricing.modelID}`);
          this.getPartnersPricing();
        }
        // console.log(result, res.data);
      });
    },
    getPartnersPricing() {
      const id = this.$route.params.id;
      const MID = this.$route.params.MID;
      partnerService
        .getPartnersResult(`${PartnersUrls.GET_PARTNERS_PRICING}?partnerId=${id}&modelId=${MID}`)
        // eslint-disable-next-line arrow-parens
        .then(res => {
          const result = res.data.data;
          // console.log(res, res.data, '========get partner info=============', result);
          if (result) {
            this.partnerPricing.description = result[0].description;
            this.partnerPricing.monthlyRentalPrice = result[0].monthlyRentalPrice;
            this.partnerPricing.manufacturerID = result[0].manufacturerID;
            this.partnerPricing.modelID = result[0].modelID;
            this.partnerPricing.salePrice = result[0].salePrice;
            this.partnerPricing.dailyPrice = result[0].dailyPrice;
            this.partnerPricing.proposalID = result[0].proposalID;
          }
        });
    },
    getDropdownData() {
      // eslint-disable-next-line arrow-parens
      return partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Manufacturer%7CProposalNumber%7CModelName%7CStatus`).then(res => {
        const result = res.data.data;
        this.manufacturerOptions = result.Manufacturer;
        this.proposalOptions = result.ProposalNumber;
        this.modelDataOptions = result.ModelName;
        this.statusOptions = result.Status;
      });
    },
    getPartnersInfo(id) {
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_INFORMATION}?partnerId=${id}`).then(res => {
        if (res.data.apiResponseStatus === 'OK') {
          const result = res.data.data;
          const statusID = result.statusId;
          const displayStatus = this.statusOptions.filter(item => item.entityID === statusID);
          this.headerData.status = displayStatus[0].entityName;
          this.headerData.id = id;
          this.headerData.name = result.partnerName;
        }
      });
    },
    calculateDailyPrice() {
      const dPrice = this.partnerPricing.monthlyRentalPrice / 28;
      if (Number.isInteger(dPrice)) {
        this.partnerPricing.dailyPrice = this.partnerPricing.monthlyRentalPrice / 28;
      } else {
        this.partnerPricing.dailyPrice = (this.partnerPricing.monthlyRentalPrice / 28).toFixed(2);
      }
    },
    cancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        if (this.$route.params.MID) {
          this.editMode = true;
          this.submitted = false;
          this.getPartnersPricing();
        } else {
          this.submitted = false;
          this.$v.$reset();
          this.partnerPricing = this.createAddEditPricingForm();
        }
      }
      return false;
    },
    createAddEditPricingForm() {
      return {
        manufacturerID: null,
        partnerId: null,
        modelID: null,
        dailyPrice: null,
        monthlyRentalPrice: null,
        salePrice: null,
        proposalID: null,
        description: '',
        userId: 0
      };
    }
  }
};
</script>
<style>
</style>