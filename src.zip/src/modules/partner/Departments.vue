<template>
  <div id="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
              <span class="k-loading-text">Loading...</span>
              <div class="k-loading-image">
                <div class="k-loading-color"></div>
              </div>
            </div>
            <div id="accordion">
              <DepartmentGrid :headerData="headerData"></DepartmentGrid>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
import ModuleHeader from '../../components/ModuleHeader';
import { MasterUrls, PartnersUrls } from './../../shared/constants/urls';
import VALIDATION_MESSAGES from '../../shared/constants/messages';
import partnerService from './services/partners-service';
import DepartmentGrid from '../partner/departments/DepartmentGrid';

export default {
  components: {
    ModuleHeader,
    DepartmentGrid
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      componentToRender: {},
      showPanels: false,
      showLoader: false,
      statusOptions: [],
      headerData: {
        head: 'Partner Departments',
        id: '',
        name: '',
        status: ''
      }
    };
  },
  watch: {
    $route(to, from) {
      const id = to.params.id;
      if (id) {
        let dropDownPromise = new Promise((resolve, reject) => {
          resolve(this.getDropdownData());
        });
        dropDownPromise.then(() => {
          this.getPartnersInfo(this.$route.params.id);
        });
      }
    }
  },
  methods: {
    showNextPanels(index) {
      if (index === 0) {
        return true;
      } else if (this.showPanels) {
        return true;
      }
      return false;
    },
    partnerAdded() {
      this.showPanels = true;
      if (this.$route.params.id) {
        let dropDownPromise = new Promise((resolve, reject) => {
          resolve(this.getDropdownData());
        });
        dropDownPromise.then(() => {
          this.getPartnersInfo(this.$route.params.id);
        });
      }
    },
    showHideLoader(ev) {
      this.showLoader = ev;
    },
    getDropdownData() {
      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Status`).then(res => {
        const result = res.data.data;
        this.statusOptions = result.Status;
      });
    },
    getPartnersInfo(id) {
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_INFORMATION}?partnerId=${id}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          const result = res.data.data;
          const statusID = result.statusId;
          const displayStatus = this.statusOptions.filter(item => item.entityID === statusID);
          this.headerData.status = displayStatus[0].entityName;
          this.headerData.id = id;
          this.headerData.name = result.partnerName;
        }
      });
    }
    // getDropdownData() {
    //   partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Status`).then(res => {
    //     if (res) {
    //       const result = res.data.data;
    //       this.statusOptions = result.Status;
    //     }
    //   });
    // },
    // getPartnersInfo(id) {
    //   partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_INFORMATION}?partnerId=${id}`).then(res => {
    //     if (res.data.apiResponseStatus !== 'Failed') {
    //       const result = res.data.data;
    //       const statusID = result.statusId;
    //       const displayStatus = this.statusOptions.filter(item => item.entityID === statusID);
    //       this.headerData.status = displayStatus[0].entityName;
    //       this.headerData.id = id;
    //       this.headerData.name = result.partnerName;
    //     }
    //   });
    // }
  },
  created() {
    if (this.$route.params.id) {
      let dropDownPromise = new Promise((resolve, reject) => {
        resolve(this.getDropdownData());
      });
      dropDownPromise.then(() => {
        this.getPartnersInfo(this.$route.params.id);
      });
    }
    // /**
    //  * getSubMenuModulesFromLeftMenuConfigs(3, 11)
    //  * parameter one is for menu(eg..partners)
    //  * parameter two is for submenu (eg..partner profile)
    //  */
    //     console.log(this.componentToRender);
    // if (this.$route.params.id) {
    //   this.showPanels = true;
    // }
  }
};
</script>