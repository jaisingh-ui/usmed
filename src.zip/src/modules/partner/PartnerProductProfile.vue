<template>
  <div id="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="searchArea">
            <div class="row">
              <div class="col-md-8">
                <h1 class="pageName">
                  Partner Product profile:
                  <span>{{headerData.name}}</span> &nbsp;
                  <span style="color:#000; font-size:15px;">(# {{headerData.id}})</span>
                  <span class="statusText">Status : {{headerData.status}}</span>
                </h1>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <div id="accordion">
              <div class="card">
                <div class="card-header">
                  <h5 class="mb-0">
                    <button class="btn btn-link">Add Model to Preferred Model List</button>
                  </h5>
                </div>
                <div
                  id="collapseTwo"
                  class="collapse show"
                  aria-labelledby="headingTwo"
                  data-parent="#accordion"
                >
                  <div class="card-body">
                    <div class="row mt-1">
                      <div class="col-md-7">
                        <div class="row">
                          <!-- <label>
                            Search Model
                            <i
                              class="icon-help-round-button"
                              data-container="body"
                              data-toggle="popover"
                              data-placement="right"
                              data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                              data-original-title
                              title
                            ></i>
                          </label>-->
                          <div class="col-md-8 mt-2 mb-2">
                            <div class="custom-autocomplete">
                              <AutoComplete
                                :searchedItem="dataSourceArray"
                                :itemIndex="0"
                                :distroyThis="distroyItem "
                                :initialPlaceHolder="'Type Model Common Name'"
                                @setSeletecDataToInputs="setDataInputs"
                                @autoFilterData="searchModelResult"
                                @emptySelectedFields="removeSelectedFields"
                                :paramToBind="'modelCommonName'"
                                :bindToInput="'modelCommonName'"
                              ></AutoComplete>
                              <div
                                v-if="alreadyExist"
                                class="error-message"
                              >Item {{suggestedField}} already exist in list</div>
                            </div>
                            <!-- <kendo-autocomplete
                              class="form-control"
                              v-model="autocompleteValue"
                              :data-source="dataSourceArray"
                              :placeholder="'Type Model Name / Model Category / Reference Number'"
                              :separator="', '"
                              :filter="'contains'"
                            ></kendo-autocomplete>-->
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row BorderBottom mt-2">
        <div class="col-md-8">
          <h1 class="gridName">Preferred Model List</h1>
        </div>
        <div class="col-md-4 text-right">
          <div class="row">
            <div class="col-md-12 text-right mb-1 mt-1">
              <button v-if="!editMode" type="button" class="edit-btn" @click="editMode = true">Edit</button>
              <div v-else>
                <button
                  type="button"
                  class="save-btn mr-1"
                  @click="savePartnerBillingInformation()"
                >Save</button>
                <button type="button" class="cancel-btn" @click="cancelClicked()">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row mt-1">
        <div class="col-md-12">
          <div class="fullPagetable">
            <div class="card-body-form">
              <div v-if="PreferredModelList.length > 0" class="row">
                <div class="col-lg-1 col-md-1 text-center">
                  <label>
                    Select
                    <i
                      class="fa fa-info-circle"
                      aria-hidden="true"
                      title="Select Preffered Model"
                    ></i>
                  </label>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>
                      Model Common Name
                      <i
                        class="fa fa-info-circle"
                        aria-hidden="true"
                        title="Model Name"
                      ></i>
                    </label>
                  </div>
                </div>

                <div class="col-md-2 text-left">
                  <div class="form-group">
                    <label>
                      Average Order Qty
                      <i
                        class="fa fa-info-circle"
                        aria-hidden="true"
                        title="Average Order Qty"
                      ></i>
                    </label>
                  </div>
                </div>
                <div class="col-md-2 text-left">
                  <div class="form-group">
                    <label>
                      Max On Rent Qty
                      <i
                        class="fa fa-info-circle"
                        aria-hidden="true"
                        title="Max On Rent Qty"
                      ></i>
                    </label>
                  </div>
                </div>
                <div class="col-md-1 text-center"></div>
              </div>
              <div v-else>No records found</div>
              <div class="row" v-for="(item, index) in PreferredModelList">
                <div class="col-md-1 text-center">
                  <div class="pt-1">
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        :disabled="!editMode && item.id!=0"
                        type="radio"
                        :id="'s_'+index"
                        :value="item.id"
                        name="customRadioInline"
                        class="custom-control-input"
                        v-model="selectedOpt"
                        @click="getSelectedModelItems(index)"
                      />
                      <label class="custom-control-label" :for="'s_'+index">&nbsp;</label>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input disabled type="text" class="form-control" v-model="item.modelCommonName" />
                  </div>
                </div>
                <div class="col-md-2 text-left">
                  <div class="form-group">
                    <input
                      :disabled="!editMode && item.id!=0"
                      type="text"
                      class="form-control"
                      oninput="validity.valid||(value='');"
                      min="1"
                      pattern="\d*"
                      maxlength="9"
                      v-model.number="item.averageOrderQty"
                    />
                    <small
                      v-if="!$v.PreferredModelList.$each[index].averageOrderQty.numeric"
                      class="error-message"
                    >{{validationMessages.INTEGER}}</small>
                  </div>
                </div>
                <div class="col-md-2 text-left">
                  <div class="form-group">
                    <input
                      oninput="validity.valid||(value='');"
                      min="1"
                      pattern="\d*"
                      maxlength="9"
                      :disabled="!editMode && item.id!=0"
                      type="text"
                      class="form-control"
                      v-model.number="item.maxonRentQty"
                    />
                    <small
                      v-if="!$v.PreferredModelList.$each[index].maxonRentQty.numeric"
                      class="error-message"
                    >{{validationMessages.INTEGER}}</small>
                  </div>
                </div>
                <div class="col-md-1 text-center mt-2">
                  <div class="form-group">
                    <a @click.prevent="!editMode? '#':deleteElements(index)">
                      <i
                        :class="{'AddDelBtn':!editMode, 'fas fa-trash AddDelBtn':true, 'custom-delete-btn': !item.isActive}"
                        aria-hidden="true"
                      ></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div v-if="selectedOpt">
        <div class="row BorderBottom mt-2">
          <div class="col-md-8">
            <h1 class="gridName">{{selectedModel}}</h1>
          </div>
          <div class="col-md-4 text-right">
            <span class="save-btn">
              <a href="javascript:void(0)" @click.prevent="!editMode? '#':saveOptions()">Save</a>
            </span>
          </div>
        </div>

        <div class="row mt-2">
          <div class="col-md-4">
            <h3 class="gridName gridNameSmall">Select Model Options</h3>
            <div class="fullPagetable">
              <div class="row">
                <div class="col-md-12">
                  <div v-if="ModelOptions.length>0" class="table-responsive" style="height:230px;">
                    <table class="table softwareTable SelectTable">
                      <tbody>
                        <tr
                          v-for="(item, index1) in ModelOptions"
                          :class="(index1%2) ? '' : 'Row1' "
                        >
                          <td width="5%">
                            <div class="checkBoxinFrom">
                              <div class="custom-control custom-checkbox">
                                <input
                                  type="checkbox"
                                  class="custom-control-input"
                                  :id="'o_'+index1"
                                  v-model="item.isActive"
                                />
                                <label class="custom-control-label" :for="'o_'+index1"></label>
                              </div>
                            </div>
                          </td>
                          <td>{{item.modelProductName}}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div v-else>No records found</div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <h3 class="gridName gridNameSmall">Select Software Version</h3>
            <div class="fullPagetable">
              <div class="row">
                <div class="col-md-12">
                  <div
                    v-if="SoftwareVersion.length>0"
                    class="table-responsive"
                    style="height:230px;"
                  >
                    <table class="table softwareTable SelectTable">
                      <tbody>
                        <tr
                          v-for="(item, index) in SoftwareVersion"
                          :class="(index%2) ? '' : 'Row1' "
                        >
                          <td width="5%">
                            <div class="custom-control custom-radio custom-control-inline">
                              <input
                                type="radio"
                                :id="'soft_'+index"
                                name="sv"
                                :value="index"
                                v-model="svSelected"
                                class="custom-control-input"
                              />
                              <label class="custom-control-label" :for="'soft_'+index"></label>
                            </div>
                          </td>
                          <td>{{item.modelProductName}}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div v-else>No records found</div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <h3 class="gridName gridNameSmall">Select Model Accessories</h3>
            <div class="fullPagetable">
              <div class="row">
                <div class="col-md-12">
                  <div
                    v-if="ModelAccessories.length>0"
                    class="table-responsive"
                    style="height:230px;"
                  >
                    <table class="table softwareTable SelectTable">
                      <tbody>
                        <tr
                          v-for="(item, index) in ModelAccessories"
                          :class="(index%2) ? '' : 'Row1' "
                        >
                          <td width="5%">
                            <div class="checkBoxinFrom">
                              <div class="custom-control custom-checkbox">
                                <input
                                  type="checkbox"
                                  class="custom-control-input"
                                  :id="'acc'+index"
                                  v-model="item.isActive"
                                  :value="item.isActive"
                                />
                                <label class="custom-control-label" :for="'acc'+index"></label>
                              </div>
                            </div>
                          </td>
                          <td>{{item.modelProductName}}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div v-else>No records found</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { numeric } from 'vuelidate/lib/validators';

import AutoComplete from '../../components/AutoComplete';
import partnerService from './services/partners-service';
import { PartnersUrls, MasterUrls } from '../../shared/constants/urls';
import { showWindowConfrim } from './../../shared/services/window-confrim';
import { showToast } from './../../shared/services/toast-service';
import VALIDATION_MESSAGE from './../../shared/constants/messages';

export default {
  components: {
    AutoComplete
  },
  data() {
    return {
      alreadyExist: false,
      validationMessages: VALIDATION_MESSAGE,
      modelId: 'mod',
      distroyItem: null,
      autocompleteValue: '',
      PreferredModelList: {},
      ModelOptions: {},
      SoftwareVersion: {},
      ModelAccessories: {},
      dataSourceArray: [],
      selectedModel: '',
      editMode: false,
      selectedOpt: false,
      headerData: {
        head: 'Preferred Model',
        id: '',
        name: '',
        status: ''
      },
      statusOptions: [],
      svSelected: -1,
      selectedModelId: 0
    };
  },
  methods: {
    deleteElements(index) {
      if (this.PreferredModelList[index] !== undefined) {
        if (this.PreferredModelList[index].id !== 0) {
          this.PreferredModelList[index].isActive = !this.PreferredModelList[index].isActive;
        } else {
          this.PreferredModelList.splice(index, 1);
        }
      }
    },
    getDropdownData() {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Status`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          const result = res.data.data;
          this.statusOptions = result.Status;
        }
      });
    },
    getPartnersInfo(id) {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_INFORMATION}?partnerId=${id}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          const result = res.data.data;
          const statusID = result.statusId;
          const displayStatus = this.statusOptions.filter(item => item.entityID === statusID);
          this.headerData.status = displayStatus[0].entityName;
          this.headerData.id = id;
          this.headerData.name = result.partnerName;
        }
      });
    },
    cancelClicked() {
      // cancel method
      const cancel = showWindowConfrim();
      if (cancel) {
        if (this.$route.params.id) {
          this.editMode = false;
          this.selectedOpt = false;
          this.alreadyExist = false;
          this.getPreferredModelList(this.$route.params.id);
        }
      }
      return false;
    },
    savePartnerBillingInformation() {
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      }
      const delData = this.PreferredModelList.filter(item => item.isActive === false);
      if (delData.length !== 0) {
        // eslint-disable-next-line no-alert
        const answer = window.confirm(`${delData.length} ${this.validationMessages.INPUTDELETERECORD}`);
        if (answer) {
          this.savePreferredModels();
        } else {
          this.$emit('onShowHideLoader', false);
        }
      } else {
        this.savePreferredModels();
      }
    },
    savePreferredModels() {
      this.preferredModel = {};
      this.preferredModel.partnerId = parseInt(this.$route.params.id, 10);
      this.preferredModel.userId = 0;
      this.preferredModel.preferredModelList = this.PreferredModelList;
      // eslint-disable-next-line arrow-parens
      partnerService.postPartnersDataAction(`${PartnersUrls.SAVE_PREFERED_MODEL}`, this.preferredModel).then(res => {
        if (res) {
          this.submitted = false;
          this.editMode = false;
          showToast('success');
          this.selectedOpt = false;
          this.alreadyExist = false;
          this.getPreferredModelList(this.$route.params.id);
        }
      });
    },
    saveOptions() {
      const options = {};

      // eslint-disable-next-line no-plusplus
      for (let i = 0; i < this.SoftwareVersion.length; i++) {
        this.SoftwareVersion[i].isActive = false;
        delete this.SoftwareVersion[i].modelProductName;
      }
      // eslint-disable-next-line no-plusplus
      for (let i = 0; i < this.ModelOptions.length; i++) {
        delete this.ModelOptions[i].modelProductName;
      }
      // eslint-disable-next-line no-plusplus
      for (let i = 0; i < this.ModelAccessories.length; i++) {
        delete this.ModelAccessories[i].modelProductName;
      }
      if (typeof this.SoftwareVersion[this.svSelected] !== 'undefined') {
        this.SoftwareVersion[this.svSelected].isActive = true;
      }
      options.options = this.ModelOptions;
      options.softwareVersion = this.SoftwareVersion;
      options.accessories = this.ModelAccessories;
      options.userId = 0;
      console.log('alldata ', options);
      // eslint-disable-next-line arrow-parens
      partnerService.postPartnersDataAction(`${PartnersUrls.SAVE_PREFERED_MODEL_DETAILS}`, options).then(res => {
        if (res) {
          showToast('success');
          this.callAPIToGetPreModels(this.PreferredModelList[this.selectedModelId].modelId);
        }
      });
    },
    // eslint-disable-next-line no-unused-vars
    setDataInputs(selectedData, itemIndex) {
      this.alreadyExist = false;
      if (this.PreferredModelList.length === 0) {
        const modelObject = {
          id: 0,
          modelId: selectedData.modelId,
          modelCommonName: selectedData.modelCommonName,
          isActive: true,
          averageOrderQty: 0,
          maxonRentQty: 0
        };
        this.editMode = true;
        this.PreferredModelList.unshift(modelObject);
      } else {
        this.suggestedField = selectedData.modelCommonName;
        const standObj = this.PreferredModelList.find(item => item.modelCommonName.trim().toLowerCase() === selectedData.modelCommonName.trim().toLowerCase());
        if (!standObj) {
          this.editMode = true;
          const modelObject = {
            id: 0,
            modelId: selectedData.modelId,
            modelCommonName: selectedData.modelCommonName,
            isActive: true,
            averageOrderQty: 0,
            maxonRentQty: 0
          };
          this.PreferredModelList.unshift(modelObject);
        } else {
          this.alreadyExist = true;
        }
      }
    },
    /**
     * Get the model name as per the search string
     */
    searchModelResult(searchValue) {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PREFERED_SEARCH_MODEL}?searchedItem=${searchValue}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.dataSourceArray = res.data.data;
        }
      });
    },
    // eslint-disable-next-line no-unused-vars
    removeSelectedFields(textValue, index) {
      this.alreadyExist = false;
      this.suggestedField = textValue;
    },
    getPreferredModelList(partnerId) {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PREFERED_MODEL_LIST}?partnerId=${partnerId}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.PreferredModelList = res.data.data;
        }
      });
      // this.PreferredModelList = [
      //   {
      //     id: 1,
      //     modelName: 'Test1',
      //     averageteOrderQty: 2,
      //     maxOnRentQty: 2
      //   },
      //   {
      //     id: 2,
      //     modelName: 'Test2',
      //     averageteOrderQty: 2,
      //     maxOnRentQty: 2
      //   },
      //   {
      //     id: 3,
      //     modelName: 'Test3',
      //     averageteOrderQty: 2,
      //     maxOnRentQty: 2
      //   }
      // ];
    },
    callAPIToGetPreModels(modelId) {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PREFERED_MODEL_DETAILS}?modelId=${modelId}&partnerId=${this.$route.params.id}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.ModelOptions = res.data.data.options;
          this.SoftwareVersion = res.data.data.softwareVersion;
          // eslint-disable-next-line no-plusplus
          for (let i = 0; i < this.SoftwareVersion.length; i++) {
            if (this.SoftwareVersion[i].isActive === true) {
              this.svSelected = i;
            }
          }
          this.ModelAccessories = res.data.data.accessories;
        }
      });
    },

    getSelectedModelItems(index) {
      this.selectedModel = this.PreferredModelList[index].modelCommonName;
      const modelId = this.PreferredModelList[index].modelId;
      this.selectedModelId = index;
      this.callAPIToGetPreModels(modelId);
    }
  },
  created() {
    // const partnerId =
    this.getPreferredModelList(this.$route.params.id);
    // eslint-disable-next-line no-unused-vars
    const dropDownPromise = new Promise((resolve, reject) => {
      resolve(this.getDropdownData());
    });
    dropDownPromise.then(() => {
      this.getPartnersInfo(this.$route.params.id);
    });
  },
  validations: {
    PreferredModelList: {
      $each: { averageOrderQty: { numeric }, maxonRentQty: { numeric } }
    }
  }
};
</script>
