<template>
  <div id="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="searchArea">
            <div class="row">
              <div class="col-lg-10 col-md-9">
                <h1 class="pageName">
                  {{headerDataResult.head}} :
                  <span>{{headerDataResult.name}}</span> &nbsp;
                  <span style="color:#000; font-size:15px;">(# {{headerDataResult.id}})</span>
                  <span class="statusText">Status : {{headerDataResult.status}}</span>
                </h1>
              </div>

              <div class="col-lg-2 col-md-3 secondBtn">
                <router-link
                  style="text-decoration: none;"
                  :to="{ name: 'ManagePartnerPricing', params: { partnerId: $route.params.id }}"
                >
                  <button type="button" class="btn btn-lightRed btn-block">Add New Pricing</button>
                </router-link>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 text-right mb-1">
                <button
                  type="button"
                  class="btn delete-btn"
                  @click.prevent="deletePartnerPrice"
                >Delete</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
              <span class="k-loading-text">Loading...</span>
              <div class="k-loading-image">
                <div class="k-loading-color"></div>
              </div>
            </div>
            <div id="accordion">
              <PartnerPricingGrid ref="checkboxData"></PartnerPricingGrid>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
import ModuleHeader from '../../components/ModuleHeader';
import { MasterUrls, PartnersUrls } from './../../shared/constants/urls';
import VALIDATION_MESSAGES from '../../shared/constants/messages';
import partnerService from './services/partners-service';
import PartnerPricingGrid from '../partner/partner-pricing/PartnerPricingGrid';
import { showWindowConfrim } from '../../shared/services/window-confrim';

export default {
  components: {
    ModuleHeader,
    PartnerPricingGrid
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      componentToRender: {},
      showPanels: false,
      showLoader: false,
      statusOptions: [],
      headerData: {
        head: 'Partner Pricing',
        id: '',
        name: '',
        status: ''
      }
    };
  },
  computed: {
    headerDataResult() {
      return this.headerData;
    }
  },
  methods: {
    getDropdownData() {
      return partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Status`).then(res => {
        const result = res.data.data;
        if (result) {
          this.statusOptions = result.Status;
        }
      });
    },
    getPartnersInfo(id) {
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_INFORMATION}?partnerId=${id}`).then(res => {
        if (res.data.apiResponseStatus === 'OK') {
          const result = res.data.data;
          const statusID = result.statusId;
          const displayStatus = this.statusOptions.filter(item => item.entityID === statusID);
          this.headerData.status = displayStatus[0].entityName;
          this.headerData.id = id;
          this.headerData.name = result.partnerName;
        }
      });
    },
    deletePartnerPrice() {
      const partnerPriceIdArray = this.$refs.checkboxData.toBeDeletedPartnerPrice;
      const itemLength = partnerPriceIdArray.length;
      if (itemLength === 0) {
        alert('Please select at least one item from list');
      } else {
        const cancel = confirm('Are you sure, you want to delete ' + itemLength + ' item(s) !');
        if (cancel && itemLength > 0) {
          const body = {
            partnerId: parseInt(this.$route.params.id, 10),
            partnerPriceId: partnerPriceIdArray.toString(),
            userId: 0
          };
          console.log(this.$refs.checkboxData.toBeDeletedPartnerPrice, 'lllllll', body);
          partnerService.postPartnersData(`${PartnersUrls.DELETE_PARTNERS_PRICING}`, body).then(res => {
            console.log(res, '===============delete partners address===============');
            this.$refs.checkboxData.callAPItoFetchData(this.$route.params.id);
          });
        } else {
          return;
        }
      }
    }
  },
  created() {
    let dropDownPromise = new Promise((resolve, reject) => {
      resolve(this.getDropdownData());
    });
    dropDownPromise.then(() => {
      this.getPartnersInfo(this.$route.params.id);
    });
    // /**
    //  * getSubMenuModulesFromLeftMenuConfigs(3, 11)
    //  * parameter one is for menu(eg..partners)
    //  * parameter two is for submenu (eg..partner profile)
    //  */
    //     console.log(this.componentToRender);
    // if (this.$route.params.id) {
    //   this.showPanels = true;
    // }
  }
};
</script>