<template>
  <div>
    <!-- <div class="row">
      <div class="col-md-12 text-right mb-1">
        <button type="button" class="btn delete-btn" @click.prevent="deletePartnerPrice">Delete</button>
      </div>
    </div>-->
    <!-- @editRow="editElements" -->
    <div class="row">
      <div class="col-md-12">
        <div class="custom-kendo-part-grid">
          <ConfiguredColumnGrid
            :reorderable="true"
            @columnreorder="columnReorder"
            :gridObjects="partnerPricing"
            :gridColumns="partnerPricingColumn"
            @checkedItem="checkedPartnerPrice"
            :sorting="sort"
            @onRowClick="rowClicked"
          ></ConfiguredColumnGrid>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
import Vue from 'vue';
import ConfiguredColumnGrid from '../../../components/ConfiguredColumnGrid';
import AddEditDepartment from '../departments/AddEditDepartment';
import { PartnersUrls } from '../../../shared/constants/urls';
import partnerService from '../services/partners-service';
import { showToast } from '../../../shared/services/toast-service';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';

const CommandCellCheckBox = Vue.component('template-component', {
  props: {
    field: String,
    dataItem: Object,
    format: String,
    className: String,
    columnIndex: Number,
    columnsCount: Number,
    rowType: String,
    level: Number,
    expanded: Boolean,
    editor: String
  },
  template: ` <td >
                 <input type="checkbox" id="vehicle1" name="vehicle1" @click="elementChecked(this.dataItem)">
                   </td>`,
  methods: {
    elementChecked() {
      this.$emit('checkedElement', { dataItem: this.dataItem });
    },
    removeHandler() {
      this.$emit('remove', { dataItem: this.dataItem });
    },
    addUpdateHandler() {
      this.$emit('save', { dataItem: this.dataItem });
    },
    cancelDiscardHandler() {
      this.$emit('cancel', { dataItem: this.dataItem });
    }
  }
});
export default {
  components: {
    ConfiguredColumnGrid,
    AddEditDepartment
  },
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      componentHeader: '',
      toBeDeletedPartnerPrice: [],
      partnerId: null,
      validationsMessages: VALIDATION_MESSAGES,
      skip: 0,
      take: 10,
      partnerPricing: [],
      partnerPricingColumn: [
        { cell: CommandCellCheckBox, width: '80px', filterable: false, title: 'Select' },
        { field: 'partnerPriceID', editable: false, title: 'PartnerPriceID', hidden: true, filterable: false },
        { field: 'partnerID', editable: false, title: 'PartnerID', hidden: true, filterable: false },
        { field: 'manufacturer', width: '200px', editable: false, title: 'Manufacturer' },
        { field: 'modelCommonName', width: '200px', editable: false, title: 'Model Common Name' },
        { field: 'dailyPrice', width: '100px', editable: false, title: 'Daily Price' },
        { field: 'monthlyPrice', width: '100px', editable: false, title: 'Monthly Price' },
        { field: 'salesPrice', width: '100px', editable: false, title: 'Sales Price' },
        { field: 'proposal', width: '100px', title: 'Proposal No.' },
        { field: 'comments', width: '300px', title: 'Comments' }
      ],
      sort: [{ field: 'modelCommonName', dir: 'asc' }]
    };
  },
  methods: {
    rowClicked(ev) {
      const id = ev.dataItem.partnerID;
      const MID = ev.dataItem.modelId;
      this.$router.push(`/partners/manage-partner-pricing/${id}/${MID}`);
    },
    columnReorder(options) {
      console.log(options);
      this.partnerPricingColumn = options.columns;
    },
    checkedPartnerPrice(data) {
      // console.log('lllll', data.dataItem);
      const indexOfElement = this.toBeDeletedPartnerPrice.indexOf(data.dataItem.partnerPriceID);
      if (indexOfElement === -1) {
        this.toBeDeletedPartnerPrice.push(data.dataItem.partnerPriceID);
      } else {
        this.toBeDeletedPartnerPrice.splice(indexOfElement, 1);
      }
    },
    // eslint-disable-next-line no-unused-vars
    callAPItoFetchData(id) {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNER_PRICING}?partnerId=${id}`).then(res => {
        const result = res.data.data;
        // console.log(result, '----------');
        if (result) {
          this.partnerPricing = result;
        }
      });
    }
  },
  created() {
    if (this.$route.params.id) {
      this.partnerId = parseInt(this.$route.params.id, 10);
      this.callAPItoFetchData(this.partnerId);
    }
  }
};
</script>

<style>
/* custom classes for kendo grid start here */
.custom-kendo-part-grid .k-grid-header-wrap > table,
.custom-kendo-part-grid table.k-grid-table {
  width: 100% !important;
}

.custom-kendo-part-grid table.k-grid-table tr.k-master-row button {
  border: 0;
  background: none;
}

.custom-kendo-grid .k-grid-content-expander {
  width: auto !important;
}

.custom-kendo-part-grid th {
  font-weight: 500;
  font-size: 15px;
}

.custom-kendo-grid th.k-header .k-link {
  text-align: left;
  font-size: 15px;
  font-weight: 500;
}

.k-pager-numbers .k-state-selected {
  background-color: #0053a0;
}
.k-pager-numbers .k-link {
  color: #787878;
}
.k-pager-numbers .k-link:hover {
  color: #0053a0;
}
.k-pager-nav:hover {
  color: #0053a0;
}
.k-list .k-item.k-state-selected {
  background-color: #0053a0;
}
.k-list .k-item.k-state-selected:hover {
  background-color: #0053a0;
}
/* custom classes for kendo grid end here */

/* .custom-kendo-part-grid .k-textbox {
  width: auto !important;
} */
</style>
