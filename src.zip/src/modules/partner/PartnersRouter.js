import Partners from '../partner/Partners';
import PartnersProfile from '../partner/PartnersProfile';
import PartnerContactsList from '../partner/PartnerContactsList';
import PartnerContacts from '../partner/PartnerContacts';
import PartnerPricing from '../partner/PartnerPricing';
import PartnersNotes from '../partner/PartnersNotes';
import PartnerProductProfile from '../partner/PartnerProductProfile';
import AddEditPartnerPricing from '../partner/AddEditPartnerPricing';
import Departments from '../partner/Departments';
import PartnerDocumentation from '../partner/PartnerDocumentation';
import CallLogs from '../calllogs/CallLogs';

export default [
  {
    path: '/partners/search-view-partner-list',
    component: Partners
  },
  {
    path: '/partners/profile',
    component: PartnersProfile
  },
  {
    path: '/partners/profile/:id',
    component: PartnersProfile
  },
  {
    path: '/partners/search-view-partner-contact-list/:id',
    component: PartnerContactsList
  },
  {
    path: '/partners/partner-contacts/:id?',
    component: PartnerContacts
  },
  {
    path: '/partners/partner-pricing/:id',
    component: PartnerPricing
  },
  {
    path: '/partners/partner-product-profile/:id',
    component: PartnerProductProfile
  },
  {
    path: '/partners/manage-partner-pricing/:id',
    component: AddEditPartnerPricing,
    name: 'ManagePartnerPricing'
  },
  {
    path: '/partners/manage-partner-pricing/:id/:MID',
    component: AddEditPartnerPricing,
    name: 'ManagePartnerPricing'
  },
  {
    path: '/partners/departments/:id',
    component: Departments
  },
  {
    path: '/partners/notes/:id',
    component: PartnersNotes
  },
  {
    path: '/partners/partner-documentation/:id',
    component: PartnerDocumentation
  },
  {
    path: '/partners/call-log/:id',
    component: CallLogs
  }
];
