<template>
  <div id="content">
    <div class="container-fluid">
      <ModuleHeader moduleName="Model Details" :headerData="headerData"></ModuleHeader>
      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <!-- <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
              <span class="k-loading-text">Loading...</span>
              <div class="k-loading-image">
                <div class="k-loading-color"></div>
              </div>
            </div>-->
            <div id="accordion" v-if="componentToRender.subMenuModules.length > 0">
              <template v-for="(subModule, index) in componentToRender.subMenuModules">
                <component
                  v-if="subModule.subMenuModuleVisible"
                  v-show="showNextPanels(index)"
                  :is="subModule.subMenuModuleName"
                  :subModuleInfo="subModule"
                  :key="subModule.subMenuModuleId"
                  @onPartnerAdded="partnerAdded"
                  @onShowHideLoader="showHideLoader($event)"
                ></component>
                <!-- ref="child"
                @panelClicked="onClicked(index)"-->
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
import ModuleHeader from '../../components/ModuleHeader';
import PartnerInformation from './profile-component/PartnerInformation';
import PartnerFlag from './profile-component/PartnerFlag';
import AdditionalPartnerInformation from './profile-component/AdditionalPartnerInformation';
import BillingInformation from './profile-component/BillingInformation';
import ShippingAddress from './profile-component/ShippingAddress';
import IdnGpoPurchasing from './profile-component/IdnGpoPurchasing';
import BillingAddress from './profile-component/BillingAddress';
import PartnerAddress from './profile-component/PartnerAddress';
import PreliminaryInvoice from './profile-component/PreliminaryInvoice';
import partnerService from './services/partners-service';
import { PartnersUrls, MasterUrls } from './../../shared/constants/urls';
import VALIDATION_MESSAGES from '../../shared/constants/messages';

export default {
  components: {
    ModuleHeader,
    PartnerInformation,
    AdditionalPartnerInformation,
    BillingInformation,
    ShippingAddress,
    BillingAddress,
    PartnerAddress,
    IdnGpoPurchasing,
    PartnerFlag,
    PreliminaryInvoice
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      componentToRender: {},
      showPanels: false,
      showLoader: false,
      statusOptions: [],
      headerData: {
        head: 'Partner Profile',
        id: '',
        name: '',
        status: ''
      }
    };
  },
  watch: {
    $route(to, from) {
      const id = to.params.id;
      if (id) {
        let dropDownPromise = new Promise((resolve, reject) => {
          resolve(this.getDropdownData());
        });
        dropDownPromise.then(() => {
          this.getPartnersInfo(this.$route.params.id);
        });
      }
    }
  },
  methods: {
    showNextPanels(index) {
      if (index === 0) {
        return true;
      } else if (this.showPanels) {
        return true;
      }
      return false;
    },
    partnerAdded() {
      this.showPanels = true;
      if (this.$route.params.id) {
        let dropDownPromise = new Promise((resolve, reject) => {
          resolve(this.getDropdownData());
        });
        dropDownPromise.then(() => {
          this.getPartnersInfo(this.$route.params.id);
        });
      }
    },
    showHideLoader(ev) {
      this.showLoader = ev;
    },
    getDropdownData() {
      return partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Status`).then(res => {
        const result = res.data.data;
        this.statusOptions = result.Status;
      });
    },
    getPartnersInfo(id) {
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_INFORMATION}?partnerId=${id}`).then(res => {
        const result = res.data.data;
        const statusID = result.statusId;
        this.$store.dispatch('setPartnerId', Number(id));
        // console.log(res, result, '=====================', statusID);
        const displayStatus = this.statusOptions.filter(item => item.entityID === statusID);
        this.headerData.status = displayStatus[0].entityName;
        this.headerData.id = id;
        this.headerData.name = result.partnerName;
      });
    }
  },
  created() {
    if (this.$route.params.id) {
      let dropDownPromise = new Promise((resolve, reject) => {
        resolve(this.getDropdownData());
      });
      dropDownPromise.then(() => {
        this.getPartnersInfo(this.$route.params.id);
      });
    }
    /**
     * getSubMenuModulesFromLeftMenuConfigs(3, 11)
     * parameter one is for menu(eg..partners)
     * parameter two is for submenu (eg..partner profile)
     */
    // this.componentToRender = this.$store.getters.getSubMenuModulesFromLeftMenuConfigs(11, 11);
    this.componentToRender = {
      subMenuId: 11,
      subMenuName: 'Profile',
      subMenuUrl: '/profile',
      subMenuIcon: 'icon-profile',
      subMenuVisible: true,
      subMenuModules: [
        {
          subMenuModuleId: 20,
          subMenuModuleName: 'PartnerInformation',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        },
        {
          subMenuModuleId: 21,
          subMenuModuleName: 'PartnerAddress',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        },
        {
          subMenuModuleId: 22,
          subMenuModuleName: 'BillingAddress',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        },
        {
          subMenuModuleId: 23,
          subMenuModuleName: 'ShippingAddress',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        },
        {
          subMenuModuleId: 24,
          subMenuModuleName: 'BillingInformation',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        },
        {
          subMenuModuleId: 25,
          subMenuModuleName: 'AdditionalPartnerInformation',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        },
        {
          subMenuModuleId: 26,
          subMenuModuleName: 'IdnGpoPurchasing',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        },
        {
          subMenuModuleId: 27,
          subMenuModuleName: 'PartnerFlag',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        },
        {
          subMenuModuleId: 28,
          subMenuModuleName: 'PreliminaryInvoice',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        }
      ]
    };

    if (this.$route.params.id) {
      this.showPanels = true;
    }
  }
};
</script>