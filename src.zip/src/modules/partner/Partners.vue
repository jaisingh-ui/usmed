<template>
  <!-- right pannel section -->
  <div id="content">
    <div class="container-fluid">
      <div class="container-fluid">
        <Search
          :placeholder="placeholder"
          :headTitle="headTitle"
          :mySearchInput="mySearchInput"
          :showAllInput="showAllInput"
          :addButtonText="addButtonText"
          @searchInputValueChanged="mySearchInput = $event"
          @onSearchClicked="onTopSearch($event)"
          @onAddClicked="onAddNewModelClicked()"
        ></Search>
      </div>
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6">
            <h1 class="pageName">Partners List</h1>
          </div>
          <div class="col-md-6">
            <div class="form-group pull-right" style="padding:0; margin:0; margin-left:10px;">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck11"
                    checked="checked"
                    v-model="showAllInput"
                    @click="showAll($event)"
                  />
                  &nbsp;
                  <label
                    class="custom-control-label"
                    for="customCheck11"
                  >Show All</label>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
          <span class="k-loading-text">Loading...</span>
          <div class="k-loading-image">
            <div class="k-loading-color"></div>
          </div>
        </div>
        <div class="custom-kendo-part-grid">
          <ConfiguredColumnGrid
            :gridObjects="myData"
            :gridColumns="myColumns"
            :sorting="sort"
            @onRowClick="viewDetail"
          ></ConfiguredColumnGrid>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Vue from 'vue';
import Search from '../../components/Search';
import DataTable from '../../components/DataTable';
import ConfiguredColumnGrid from '../../components/ConfiguredColumnGrid';
import partnerService from './services/partners-service';
import { PartnersUrls } from '../../shared/constants/urls';

const CommandCellCheckBox = Vue.component('template-component', {
  props: {
    field: String,
    dataItem: Object,
    format: String,
    className: String,
    columnIndex: Number,
    columnsCount: Number,
    rowType: String,
    level: Number,
    expanded: Boolean,
    editor: String
  },
  template: `<td >
                <div class="dropleft">    
                  <a href="javascript:void(0)" 
                    title="Take Call" 
                    class="border rounded-circle create-new-call-btn dropdown-toggle"
                    data-toggle="dropdown"
                    aria-haspopup="true" 
                    aria-expanded="false">
                    <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                  </a>
                  <div class="dropdown-menu create-new-call-dropdown">                                 
                      <a href="javascript:void(0)" @click="addNewCall(this.dataitem)">
                          Take New Call
                      </a>                                                                              
                      <a href="javascript:void(0)">
                          Other Links
                      </a>                                                                           
                  </div>
                </div>
              </td>`,
  methods: {
    addNewCall() {
      this.$store.dispatch('resetEditCallLogStateToDefault');
      this.$router.push(`/partners/call-log/${this.dataItem.partnerId}`);
    }
  }
});

export default {
  data() {
    return {
      headTitle: 'Search Partner',
      placeholder: 'Type Partner Name / Partner Type / Partner Number',
      myToolbar: ['excel', 'pdf'],
      dataItemsSource: [],
      addButtonText: 'Add New Partner',
      myData: [],
      showLoader: false,
      // here checkbox is behaving oppositely
      showAllInput: false,
      mySearchInput: '',
      // myColumns getting used as column for grid
      myColumns: [
        { field: 'partnerId', hidden: true },
        { field: 'partnerName', title: 'Partner Name', filterable: true, sortable: true },
        { field: 'address1', title: 'Address 1' },
        { field: 'address2', title: 'Address 2' },
        { field: 'branchName', title: 'Branch' },
        { field: 'city', title: 'City' },
        { field: 'stateName', title: 'State' },
        { field: 'zip', title: 'Zip' },
        { field: 'partnerStatusName', title: 'Status' },
        { cell: CommandCellCheckBox, width: '100px', filterable: false }
      ],
      sort: [{ field: 'partnerName', dir: 'asc' }]
    };
  },
  methods: {
    /**
     * on click at the add new model button onAddNewModelClicked get called
     * and navigate user to add new model
     */
    onAddNewModelClicked() {
      this.$store.dispatch('setOperationMode', 'save');
      this.$router.push('/partners/profile');
    },
    /**
     * on click at the particular  model row viewDetail get called
     * and navigate user to view new model detail
     */
    viewDetail(event) {
      const id = event.dataItem.partnerId;
      this.$router.push(`/partners/profile/${id}`);
    },
    /**
     * on searching model from top search input onTopSearch method get call
     * and return the relevent data in to the grid
     */
    // eslint-disable-next-line consistent-return
    onTopSearch(event) {
      this.showLoader = true;
      const searchValue = event.trim();
      if (searchValue) {
        // this.showAllInput = true;
        // eslint-disable-next-line arrow-parens
        partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_SEARCH}?searcheditem=${searchValue}`).then(res => {
          const result = res.data.data;
          if (result) {
            this.myData = result;
            this.showLoader = false;
          }
        });
      } else if ((searchValue && !this.showAllInput) || (!searchValue && !this.showAllInput)) {
        // eslint-disable-next-line arrow-parens
        partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_SHOWALL}?searchItem=${this.mySearchInput}`).then(res => {
          const result = res.data.data;
          if (result) {
            this.myData = result;
            this.showLoader = false;
          }
        });
      } else {
        if (!this.showAllInput) {
          return false;
        }
        this.myData = this.dataItemsSource;
        this.showLoader = false;
      }
    },
    /**
     * on showAll checked get all model data
     * on showAll unchecked show no data for model
     */
    showAll(e) {
      this.showLoader = true;
      if (e.target.checked && this.mySearchInput) {
        // this.mySearchInput = '';
        // eslint-disable-next-line arrow-parens
        partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_SHOWALL}?searchItem=${this.mySearchInput}`).then(res => {
          const result = res.data.data;
          if (result) {
            this.myData = result;
            this.showLoader = false;
          }
        });
      } else if (e.target.checked && !this.mySearchInput) {
        // eslint-disable-next-line arrow-parens
        partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_SHOWALL}`).then(res => {
          const result = res.data.data;
          if (result) {
            this.myData = result;
            this.showLoader = false;
          }
        });
      } else if (e.target.checked && this.mySearchInput) {
        // eslint-disable-next-line arrow-parens
        partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_SEARCH}?searcheditem=${this.mySearchInput}`).then(res => {
          const result = res.data.data;
          if (result) {
            this.myData = result;
            this.showLoader = false;
          }
        });
      } else {
        this.myData = this.dataItemsSource;
        this.showLoader = false;
      }
    }
  },
  components: {
    Search,
    DataTable,
    ConfiguredColumnGrid
  }
};
</script>

<style>
.k-grid td {
  overflow: inherit;
}
</style>