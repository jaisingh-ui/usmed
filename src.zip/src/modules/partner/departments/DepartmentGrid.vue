<template>
  <div>
    <div class="row">
      <div class="col-md-12">
        <div class="searchArea">
          <div class="row">
            <div class="col-lg-10 col-md-9">
              <h1 class="pageName">
                {{headerData.head}} :
                <span>{{headerData.name}}</span> &nbsp;
                <span style="color:#000; font-size:15px;">(# {{headerData.id}})</span>
                <span class="statusText">Status : {{headerData.status}}</span>
              </h1>
            </div>
            <div class="col-md-2 secondBtn mb-3" v-if="isGridMode">
              <button type="button" class="btn btn-lightRed btn-block">
                <a href="javascript:void(0)" @click.prevent="addDepartment">Add New Department</a>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row" v-if="isGridMode">
      <div class="col-md-12">
        <ConfiguredColumnGrid
          :gridObjects="partnerDepartments"
          :gridColumns="partnerDepartmentsColumn"
          :sorting="sort"
          @onRowClick="deleteElements"
        ></ConfiguredColumnGrid>
      </div>
    </div>

    <div class="col-md-12 pt-3" v-if="isGridMode">
      <div
        style="width: 16px;height: 16px;background: rgb(251, 244, 202);border: 0px solid rgba(0, 0, 0, 0.125);display: inline-block;"
      ></div>
      <div style="display: inline-block;margin-left: 5px;">Department from Master List</div>
    </div>
    <div v-else>
      <AddEditDepartment
        @cancelPartnerDept="cancelDeptEvent"
        @savedPartnerDepartment="departmentDataSaved"
        :departmentData="departmentData"
        :saveUser="enableGridView"
        :mode="departmentMode"
        :buttonMode="departmentButtonModel"
        :panelHeader="componentHeader"
      ></AddEditDepartment>
    </div>
  </div>
</template>
<script>
import Vue from 'vue';
import { EventBus } from '../../../EventBus/event-bus';
import ConfiguredColumnGrid from '../../../components/ConfiguredColumnGrid';
import AddEditDepartment from '../departments/AddEditDepartment';
import { PartnersUrls } from '../../../shared/constants/urls';
import partnerService from '../services/partners-service';

import VALIDATION_MESSAGES from '../../../shared/constants/messages';

const checkBoxCellIsActive = Vue.component('template-check', {
  props: ['dataItem'],
  template: `<td :class="dataItem.departmentCategory === 'MasterDepartment' ? 'MasterData' : ''">
                <div class="custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input" disabled :id='"selectAllCheckisActive_"+ dataItem.departmentId' :checked="dataItem.isActive"  />
                    <label class="custom-control-label ml-1 js_check-box" :for="'selectAllCheckisActive_'+ dataItem.departmentId"></label>
                </div>
              </td>`
});

const checkBoxCellIsPORequired = Vue.component('template-check', {
  props: ['dataItem'],
  template: `<td :class="dataItem.departmentCategory === 'MasterDepartment' ? 'MasterData' : ''">
                <div class="custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input" disabled :id='"selectAllCheckPOREQ_"+ dataItem.departmentId' :checked="dataItem.isPORequired"  />
                    <label class="custom-control-label ml-1 js_check-box" :for="'selectAllCheckPOREQ_'+ dataItem.departmentId"></label>
                </div>
              </td>`
});

const checkBoxAllCellIsPoReq = Vue.component('template-check-all', {
  props: ['dataItem'],
  template: `<div class="custom-control custom-checkbox grid-checkbox-nouse"><input type="checkbox" class="custom-control-input" :id='"FilterIsPoRequired"' @change="change" />
                <label class="custom-control-label ml-1" :for="'FilterIsPoRequired'"></label></div>`,
  methods: {
    change(e) {
      EventBus.$emit('filter-is-po-required', e.target.checked);
    }
  }
});

const checkBoxAllCellIsActive = Vue.component('template-check-all', {
  props: ['dataItem'],
  template: `<div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" :id='"FilterIsActive"' @change="change" />
                <label class="custom-control-label ml-1" :for="'FilterIsActive'"></label></div>`,
  methods: {
    change(e) {
      EventBus.$emit('filter-is-active-required', e.target.checked);
    }
  }
});

export default {
  components: {
    ConfiguredColumnGrid,
    AddEditDepartment
  },
  props: {
    itemIndex: {
      type: Number
    },
    headerData: {
      type: Object
    }
  },
  data() {
    return {
      filterPo: false,
      filterActive: false,
      selectMaster: false,
      componentHeader: '',
      isGridMode: true,
      partnerId: null,
      validationsMessages: VALIDATION_MESSAGES,
      skip: 0,
      take: 10,
      partnerDepartments: [],
      partnerDepartmentsColumn: [
        { field: 'departmentId', editable: false, title: 'ID', hidden: true, filterable: false },
        { field: 'departmentName', editable: false, title: 'Department Name', cell: this.cellDepartmentNameFunction },
        { field: 'costCenter', editable: false, title: 'Cost Center', cell: this.cellCostCenterFunction },
        { field: 'floor', editable: false, title: 'Floor', cell: this.cellFloorFunction },
        { field: 'suite', editable: false, title: 'Suite', cell: this.cellSuiteFunction },

        { cell: checkBoxCellIsPORequired, field: 'isPORequired', title: 'PO Required', filterCell: checkBoxAllCellIsPoReq },
        { cell: checkBoxCellIsActive, field: 'isActive', title: 'Active', filterCell: checkBoxAllCellIsActive }
      ],
      changedUsableParts: [],
      departmentData: {
        departmentCategory: '',
        departmentId: '',
        departmentName: '',
        costCenter: '',
        floor: '',
        suite: '',
        isPORequired: false,
        isActive: false
      },
      departmentMode: false,
      departmentButtonModel: false,
      sort: []
    };
  },
  methods: {
    cellCostCenterFunction(h, tdElement, props) {
      return h(
        'td',
        {
          attrs: { class: props.dataItem.departmentCategory === 'MasterDepartment' ? 'MasterData' : '' }
        },
        props.dataItem.costCenter
      );
    },
    cellFloorFunction(h, tdElement, props) {
      return h(
        'td',
        {
          attrs: { class: props.dataItem.departmentCategory === 'MasterDepartment' ? 'MasterData' : '' }
        },
        props.dataItem.floor
      );
    },
    cellSuiteFunction(h, tdElement, props) {
      return h(
        'td',
        {
          attrs: { class: props.dataItem.departmentCategory === 'MasterDepartment' ? 'MasterData' : '' }
        },
        props.dataItem.suite
      );
    },
    cellDepartmentNameFunction(h, tdElement, props) {
      return h(
        'td',
        {
          attrs: { class: props.dataItem.departmentCategory === 'MasterDepartment' ? 'MasterData' : '' }
        },
        props.dataItem.departmentName
      );
    },

    deleteElements(ev) {
      this.isGridMode = false;
      this.departmentData = {
        partnerId: parseInt(this.$route.params.id, 10),
        isMapped: true,
        userId: 1,
        departmentCategory: ev.dataItem.departmentCategory ? ev.dataItem.departmentCategory : '',
        departmentId: ev.dataItem.departmentId,
        departmentName: ev.dataItem.departmentName ? ev.dataItem.departmentName : '',
        costCenter: ev.dataItem.costCenter ? ev.dataItem.costCenter : '',
        floor: ev.dataItem.floor ? ev.dataItem.floor : '',
        suite: ev.dataItem.suite ? ev.dataItem.suite : '',
        isPORequired: ev.dataItem.isPORequired,
        isActive: ev.dataItem.isActive
      };
      this.componentHeader = 'Edit Department';
    },
    callAPItoFetchData(id) {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNER_DEPARTMENTS}?partnerId=${id}`).then(res => {
        this.partnerDepartments = res.data.data.departments;
      });
    },
    addDepartment() {
      this.isGridMode = false;
      this.departmentData = {
        partnerId: parseInt(this.$route.params.id, 10),
        isMapped: false,
        userId: 1,
        departmentCategory: 'PartnerDepartment',
        departmentId: 0,
        departmentName: '',
        costCenter: '',
        floor: '',
        suite: '',
        isPORequired: false,
        isActive: true
      };
      this.departmentMode = true;
      this.departmentButtonModel = true;
      this.componentHeader = 'Add New Department';
    },
    enableGridView() {
      this.isGridMode = true;
    },
    selectMasterData() {
      this.selectMaster = !this.selectMaster;
      if (this.selectMaster) {
        this.partnerDepartments = this.partnerDepartments.filter(item => item.departmentCategory === 'MasterDepartment');
      } else {
        this.callAPItoFetchData(this.partnerId);
      }
    },
    departmentDataSaved() {
      this.isGridMode = true;
      this.callAPItoFetchData(this.partnerId);
    },
    cancelDeptEvent() {
      this.isGridMode = true;
      this.departmentButtonModel = false;
      this.callAPItoFetchData(this.partnerId);
    }
  },
  created() {
    this.partnerId = this.$route.params.id;
    this.callAPItoFetchData(this.partnerId);
    this.editMode = true;

    // eslint-disable-next-line arrow-parens
    EventBus.$on('filter-is-po-required', poRequiredCheckValue => {
      this.filterPo = poRequiredCheckValue;
      // eslint-disable-next-line no-console
      if (poRequiredCheckValue === true) {
        this.partnerDepartments = this.partnerDepartments.filter(item => item.isPORequired === poRequiredCheckValue);
      } else if (poRequiredCheckValue === false) {
        this.callAPItoFetchData(this.partnerId);
        this.partnerDepartments = this.partnerDepartments.filter(item => item.isPORequired === poRequiredCheckValue);
      }
    });

    // eslint-disable-next-line arrow-parens
    EventBus.$on('filter-is-active-required', isActiveCheckValue => {
      this.filterActive = isActiveCheckValue;
      // eslint-disable-next-line no-console
      if (isActiveCheckValue === true) {
        this.partnerDepartments = this.partnerDepartments.filter(item => item.isActive === isActiveCheckValue);
      } else if (isActiveCheckValue === false) {
        this.callAPItoFetchData(this.partnerId);
        this.partnerDepartments = this.partnerDepartments.filter(item => item.isActive === isActiveCheckValue);
      }
    });
  }
};
</script>
<style scoped>
.MasterData {
  background: #fbf4ca;
}
.k-textbox {
  width: 30px !important;
}
</style>