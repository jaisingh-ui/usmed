<template>
  <div>
    <div
      class="alert alert-warning alert-dismissible fade show text-center"
      role="alert"
      v-if="errors.length > 0"
    >
      <div v-for="message in errors">{{message.userMessage}}</div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="formTabSection">
          <div id="accordion">
            <div class="card">
              <div class="card-header">
                <h5 class="mb-0">
                  <button class="btn btn-link">
                    <!-- <template v-if="buttonMode">Add New Department</template>
                    <template v-else>Edit Department</template>-->
                    Department Information
                  </button>
                </h5>
              </div>
              <div
                id="collapseTwo"
                class="collapse show"
                aria-labelledby="headingTwo"
                data-parent="#accordion"
              >
                <div class="card-body">
                  <div class="row border-bottom">
                    <div class="col-md-12 pt-2 pb-2 text-right">
                      <div class="workingBtn" v-if="editMode">
                        <button type="button" class="edit-btn" @click.prevent="onEditClicked">Edit</button>
                      </div>
                      <div v-if="!editMode">
                        <button
                          type="button"
                          class="save-btn mr-1"
                          @click.prevent="onSaveClicked"
                        >Save</button>

                        <button
                          type="button"
                          class="cancel-btn"
                          @click.prevent="onCancelClicked"
                        >Cancel</button>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group">
                        <label>
                          Department Name
                          <i
                            class="fa fa-info-circle"
                            aria-hidden="true"
                            title="Department Name"
                          ></i>
                        </label>
                        <input
                          type="text"
                          v-model="departmentPartner.departmentName"
                          :class="editMode?'custom-disabled form-control': 'form-control'"
                          maxlength="100"
                          :disabled="departmentPartner.departmentCategory === 'MasterDepartment' ? true: editMode"
                        />
                        <p
                          class="error-message"
                          v-if="!$v.departmentPartner.departmentName.required && submitted"
                        >{{validationsMessages.REQUIRED}}</p>
                        <p
                          class="error-message"
                          v-if="!$v.departmentPartner.departmentName.alphaNumSpecialValidation"
                        >{{validationsMessages.ALPHA_SPECIAL_CHARACTER_RULE_TITLE}}</p>
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label>
                          Cost Center
                          <i
                            class="fa fa-info-circle"
                            aria-hidden="true"
                            title="Cost Centre"
                          ></i>
                        </label>
                        <input
                          type="text"
                          v-model="departmentPartner.costCenter"
                          :class="editMode?'custom-disabled form-control': 'form-control'"
                          maxlength="100"
                          :disabled="editMode"
                        />
                        <!-- departmentPartner.departmentCategory === 'MasterDepartment' ? true:  -->
                        <p
                          class="error-message"
                          v-if="!$v.departmentPartner.costCenter.alphaNumSpecialValidation"
                        >{{validationsMessages.ALPHA_SPECIAL_CHARACTER_RULE_TITLE}}</p>
                      </div>
                    </div>

                    <div class="col-md-2">
                      <div class="form-group">
                        <label>
                          Floor
                          <i class="fa fa-info-circle" aria-hidden="true" title="Floor"></i>
                        </label>
                        <input
                          v-model="departmentPartner.floor"
                          type="text"
                          :class="editMode?'custom-disabled form-control': 'form-control'"
                          maxlength="40"
                          :disabled="editMode"
                        />
                        <!-- departmentPartner.departmentCategory === 'MasterDepartment' ? true: -->
                        <p
                          class="error-message"
                          v-if="!$v.departmentPartner.floor.alphaNumSpaceValidation"
                        >{{validationsMessages.ALPHA_NUMERIC_SPACES}}</p>
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label>
                          Suite
                          <i class="fa fa-info-circle" aria-hidden="true" title="Suit"></i>
                        </label>
                        <input
                          v-model="departmentPartner.suite"
                          type="text"
                          :class="editMode?'custom-disabled form-control': 'form-control'"
                          maxlength="40"
                          :disabled="editMode"
                        />
                        <!-- departmentPartner.departmentCategory === 'MasterDepartment' ? true:  -->
                        <p
                          class="error-message"
                          v-if="!$v.departmentPartner.suite.alphaNumSpaceValidation"
                        >{{validationsMessages.ALPHA_NUMERIC_SPACES}}</p>
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label>
                          PO Required
                          <i
                            class="fa fa-info-circle"
                            aria-hidden="true"
                            title="PO Required"
                          ></i>
                        </label>
                        <div class="checkBoxinFrom">
                          <div class="custom-control custom-checkbox">
                            <input
                              :disabled="editMode"
                              :checked="departmentPartner.isPORequired"
                              type="checkbox"
                              class="custom-control-input"
                              id="customCheck12"
                              checked="checked"
                              @click="isPOClicked()"
                            />
                            <label class="custom-control-label" for="customCheck12"></label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-1">
                      <div class="form-group">
                        <label>
                          Active
                          <i class="fa fa-info-circle" aria-hidden="true" title="Active"></i>
                        </label>
                        <div class="checkBoxinFrom">
                          <div class="custom-control custom-checkbox">
                            <input
                              :disabled="editMode"
                              type="checkbox"
                              :checked="departmentPartner.isActive"
                              class="custom-control-input"
                              id="customCheck11"
                              checked="checked"
                              @click="isActiveClicked()"
                            />
                            <label class="custom-control-label" for="customCheck11"></label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { required, helpers } from 'vuelidate/lib/validators';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import { PartnersUrls } from '../../../shared/constants/urls';
import { showToast } from '../../../shared/services/toast-service';
import { PatternValidation } from '../../../shared/constants/pattern-validation';
import partnerService from '../services/partners-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

const alphaNumSpecialValidation = helpers.regex('alphaNumSpecialValidationRuleTitle', PatternValidation.alphaNumSpecialValidation);
const alphaNumSpaceValidation = helpers.regex('alphaNumSpaceValidation', PatternValidation.alphaNumSpace);

export default {
  props: {
    departmentData: {
      type: Object
    },
    panelHeader: {
      type: String
    },
    mode: {
      type: Boolean
    },
    buttonMode: {
      type: Boolean
    }
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      editMode: true,
      departmentPartner: this.checkDepartmentData(this.departmentData),
      savedOldData: {},
      errors: {},
      submitted: false,
      modeType: this.mode
    };
  },
  validations: {
    departmentPartner: {
      departmentCategory: {},
      departmentName: { required, alphaNumSpecialValidation },
      costCenter: { alphaNumSpecialValidation },
      floor: { alphaNumSpaceValidation },
      suite: { alphaNumSpaceValidation }
    }
  },
  methods: {
    isMaster() {
      let enableOrDisable = false;
      if (this.editMode) {
        enableOrDisable = true;
        if (this.departmentPartner.departmentCategory === 'MasterDepartment') {
          enableOrDisable = false;
        }
      } else {
        enableOrDisable = false;
      }
      return enableOrDisable;
    },
    checkDepartmentData(deptData) {
      let deptModel = deptData;
      if (deptModel === null) {
        deptModel = {
          partnerId: parseInt(this.$route.params.id, 10),
          isMapped: false,
          userId: 1,
          departmentCategory: 'PartnerDepartment',
          departmentId: 0,
          departmentName: '',
          costCenter: '',
          floor: '',
          suite: '',
          isPORequired: false,
          isActive: false
        };
      }
      return deptModel;
    },
    getOldData(data) {
      return JSON.parse(JSON.stringify(data));
    },
    onEditClicked() {
      this.editMode = false;
    },
    async onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.editMode = true;
        this.$emit('cancelPartnerDept', true);
        // this.departmentPartner = JSON.parse(JSON.stringify(this.savedOldData));
        this.submitted = false;
      }
      return false;
    },
    // Save functionality will go here
    onSaveClicked() {
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      }
      // eslint-disable-next-line arrow-parens,no-unused-vars
      partnerService.postPartnersDataAction(`${PartnersUrls.SAVE_PARTNER_DEPARTMENTS}`, this.departmentPartner).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.editMode = true;
          this.$emit('savedPartnerDepartment', this.editMode);
          showToast('success');
          this.submitted = false;
        } else {
          this.errors = res.data.errors;
        }
      });
    },
    isActiveClicked() {
      this.departmentPartner.isActive = !this.departmentPartner.isActive;
    },
    isPOClicked() {
      this.departmentPartner.isPORequired = !this.departmentPartner.isPORequired;
    }
  },
  created() {
    this.savedOldData = JSON.parse(JSON.stringify(this.departmentPartner));
    // if (this.buttonMode === true) {
    this.editMode = false;
    // }
  }
};
</script>