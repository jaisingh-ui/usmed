<template>
  <div id="content">
    <div class="container-fluid">
      <div class="row">
        <Loader v-if="showLoader"></Loader>
        <div class="col-md-12">
          <div class="searchArea">
            <div class="row">
              <div class="col-md-12">
                <h1 class="pageName">
                  Partner Notes :
                  <span>{{headerData.name}}</span> &nbsp;
                  <span style="color:#000; font-size:15px;">(# {{headerData.id}})</span>
                  <span class="statusText">Status : {{headerData.status}}</span>
                </h1>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12 text-right mb-2">
          <span v-if="!editMode" class="FormworkingBtn">
            <a @click="editMode=!editMode" href="javascript:void(0)">
              <i class="icon-model-options" aria-hidden="true"></i> Add New Note
            </a>
          </span>
          <div v-else>
            <button type="button" class="save-btn mr-1" @click="handleSave()">Save</button>
            <button type="button" class="cancel-btn" @click="handleCancel()">Cancel</button>
          </div>
        </div>
        <div class="col-md-12">
          <div class="form-group">
            <textarea
              :disabled="!editMode"
              v-model="noteData.noteDescription"
              class="form-control"
              rows="3"
              id="comment"
            ></textarea>
          </div>
          <div v-if="submitted" class="error-message">
            <p v-if="!$v.noteData.noteDescription.required">{{validationMessages.REQUIRED}}</p>
          </div>
        </div>
        <div class="col-md-12">
          <div class="form-group">
            <div class="checkBoxinFrom">
              <div class="custom-control custom-checkbox">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="customCheck11"
                  :checked="noteData.isAlert"
                  :disabled="!editMode"
                  @click="noteData.isAlert=!noteData.isAlert"
                />
                <label class="custom-control-label" for="customCheck11">Alert</label>&nbsp;
                <i
                  class="fa fa-exclamation-triangle"
                  aria-hidden="true"
                  style="color:#ff0000"
                ></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        v-for="(note,index) in notesInformation"
        class="row"
        style="border-top: 1px solid #efefef;"
      >
        <div class="col-md-12 mb-2"></div>
        <div class="col-md-12 mb-2">{{note.noteDescription}}</div>
        <div class="col-md-12 tcolor2 mb-1" style="color: #0053a0; font-size:13px;">
          {{note.userName}} &nbsp; &nbsp; {{note.createdDate | formatDateTime}} &nbsp;&nbsp;
          <i
            v-if="note.isAlert"
            class="fa fa-exclamation-triangle"
            aria-hidden="true"
            style="color:#ff0000"
          ></i> &nbsp;
          <a href="#" @click="handleEdit" v-if="index===0">
            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
          </a>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { required } from 'vuelidate/lib/validators';
import VALIDATION_MESSAGE from './../../shared/constants/messages';

import partnerService from './services/partners-service';
import { PartnersUrls, MasterUrls, NotesUrls } from './../../shared/constants/urls';
import { showToast } from './../../shared/services/toast-service';
import { showWindowConfrim } from './../../shared/services/window-confrim';

export default {
  props: {},
  components: {},
  data() {
    return {
      validationMessages: VALIDATION_MESSAGE,
      editMode: false,
      submitted: false,
      notesInformation: [],
      partnerID: 0,
      showLoader: false,
      noteData: { noteId: 0, uqId: this.partnerID, noteDescription: '', isAlert: false, userId: 1, ident: 'partners' },
      headerData: {
        head: 'Notes',
        id: '',
        name: '',
        status: ''
      },
      statusOptions: []
    };
  },
  methods: {
    getNotesInformation(partnerId) {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${NotesUrls.GET_NOTE}?RefId=${partnerId}&Identifier=partners`).then(res => {
        if (res.data !== null) {
          this.notesInformation = res.data.data;
        }
      });
    },
    handleSave() {
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        this.showLoader = false;
        return;
      }
      this.noteData.uqId = parseInt(this.partnerID, 10);
      // eslint-disable-next-line arrow-parens
      partnerService.postPartnersDataAction(`${NotesUrls.POST_NOTE}`, this.noteData).then(res => {
        if (res) {
          // this.$store.dispatch('setLoaderStatus', false);
          this.submitted = false;
          this.editMode = false;
          this.noteData.isAlert = false;
          this.noteData.noteDescription = '';
          this.noteData.noteId = 0;
          showToast('success');
          this.getNotesInformation(this.partnerID);
          this.showLoader = false;
        }
      });
    },
    handleCancel() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.$v.$reset();
        this.submitted = false;
        this.editMode = false;
        this.noteData.isAlert = false;
        this.noteData.noteDescription = '';
        this.noteData.noteId = 0;
      }
      return false;
    },
    handleEdit() {
      this.noteData.noteDescription = this.notesInformation[0].noteDescription;
      this.noteData.isAlert = this.notesInformation[0].isAlert;
      this.noteData.noteId = this.notesInformation[0].noteId;
      this.editMode = true;
    },
    getDropdownData() {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Status`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          const result = res.data.data;
          this.statusOptions = result.Status;
        }
      });
    },
    getPartnersInfo(id) {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_INFORMATION}?partnerId=${id}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          const result = res.data.data;
          const statusID = result.statusId;
          const displayStatus = this.statusOptions.filter(item => item.entityID === statusID);
          this.headerData.status = displayStatus[0].entityName;
          this.headerData.id = id;
          this.headerData.name = result.partnerName;
        }
      });
    }
    // async getDropdownData(id) {
    //   // eslint-disable-next-line arrow-parens
    //   await partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Status`).then(res => {
    //     const result = res.data;
    //     this.statusOptions = result.Status;
    //     this.getPartnersInfo(id);
    //   });
    // },
    // async getPartnersInfo(id) {
    //   // eslint-disable-next-line arrow-parens
    //   await partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_INFORMATION}?partnerId=${id}`).then(res => {
    //     const result = res.data;
    //     const statusID = result.data.statusId;
    //     const displayStatus = this.statusOptions.filter(item => item.entityID === statusID);
    //     this.headerData.status = displayStatus[0].entityName;
    //     this.headerData.id = id;
    //     this.headerData.name = result.partnerName;
    //   });
    // }
  },
  validations: {
    noteData: {
      noteDescription: { required }
    }
  },
  created() {
    if (this.$route.params.id) {
      this.partnerID = this.$route.params.id;
      // eslint-disable-next-line no-unused-vars
      const dropDownPromise = new Promise((resolve, reject) => {
        resolve(this.getDropdownData());
      });
      dropDownPromise.then(() => {
        this.getPartnersInfo(this.$route.params.id);
      });
      this.getNotesInformation(this.partnerID);
    }
  }
};
</script>