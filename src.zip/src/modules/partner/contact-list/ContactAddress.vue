<template>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseTwo"
          aria-expanded="false"
          aria-controls="collapseTwo"
          @click="CallGetAddressAPI()"
        >Contact Address</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseTwo"
          @click="CallGetAddressAPI()"
        ></i>
      </div>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <CotactAddressForm
        v-if="showBlock"
        :showBlock="showBlock"
        :validationMessages="validationMessages"
        @updateShowBlock="updateBlock"
      />

      <div id="tableOne" v-if="!showBlock">
        <div class="row">
          <div class="col-md-12">
            <div class="col-lg-4 col-md-6 mb-3" v-if="!noDataFound">
              <div class="contractsList-block mt-2">
                <div class="row" style="border-bottom: 1px solid #efefef;">
                  <div class="col-md-12 text-right mb-1">
                    <div class="standard-box">
                      <div>
                        <button type="button" class="edit-btn" @click="showBlock = !showBlock">Edit</button>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="contact-body mt-1">
                  <strong>Address</strong>
                  <br />
                  {{parterContactAddress.address1}}, {{parterContactAddress.address2}},
                  <br />
                  {{parterContactAddress.city}}
                  <br />
                  {{parterContactAddress.stateName}} {{parterContactAddress.zip}}, {{parterContactAddress.countryName}}
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-3" v-else>
              <div class="contractsList-block mt-2 vboxCenter" @click="showBlock = !showBlock">
                <div class="contact-body mt-1">
                  <div class="row">
                    <div class="col-md-12 text-center">
                      <i class="icon-model-options"></i>
                      <br />
                      <strong>Add New Address</strong>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { PartnersUrls } from '../../../shared/constants/urls';
import partnerService from '../services/partners-service';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
// import { required } from 'vuelidate/lib/validators';
// import { showToast } from '../../../shared/services/toast-service';
import CotactAddressForm from './elements/ContactAddressForm';

export default {
  name: 'ContactAddress',
  components: {
    CotactAddressForm
  },
  data() {
    return {
      componentTitle: 'Contact Address',
      validationMessages: VALIDATION_MESSAGE,
      editMode: false,
      submitted: false,
      showBlock: false,
      noDataFound: false,
      parterContactAddress: {
        address1: '',
        address2: '',
        city: '',
        stateId: 0,
        zip: '',
        countryId: 0,
        userId: 1,
        stateName: '',
        countryName: ''
      }
    };
  },
  methods: {
    /**
     * updateBlock
     */
    updateBlock(value) {
      this.showBlock = value;
      this.CallGetAddressAPI();
    },

    /**
     * CallGetAddressAPI method will load data based on param contact id
     * @param contactID (INT)
     */
    CallGetAddressAPI() {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNER_CONTACT_ADDRESS}?contactId=${this.$store.getters.getContactId}`).then(response => {
        if (response.data.data !== null) {
          const result = response.data.data;
          this.parterContactAddress = result;
          this.noDataFound = false;
        } else {
          this.noDataFound = true;
        }
      });
    }
  },
  mounted() {
    if (this.$store.getters.getContactId) {
      this.CallGetAddressAPI();
    }
  }
};
</script>


<style scoped>
.pointerClass {
  cursor: pointer;
}
</style>