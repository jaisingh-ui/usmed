<template>
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseOne"
          aria-expanded="false"
          aria-controls="collapseOne"
        >Contact Information</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down collapsed"
          data-toggle="collapse"
          data-target="#collapseOne"
          aria-expanded="false"
        ></i>
      </div>
    </div>

    <div
      id="collapseOne"
      class="collapse show"
      aria-labelledby="headingOne"
      data-parent="#accordion"
      style
    >
      <div class="card-body">
        <div class="row">
          <div class="col-md-12 text-right mb-1 mt-1">
            <div v-if="!editMode">
              <button type="button" class="edit-btn" @click="editMode = !editMode">Edit</button>
            </div>
            <div v-else>
              <button
                type="button"
                class="save-btn mr-1"
                @click.prevent="saveContactInfromation"
              >Save</button>

              <button
                type="button"
                class="cancel-btn"
                @click.prevent="cancelContactInfromation"
              >Cancel</button>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-2 col-md-4">
            <div class="form-group">
              <label>
                Salutation
                <i class="fa fa-info-circle" aria-hidden="true" title="Salutation"></i>
              </label>

              <select
                id="inputState"
                class="form-control"
                :disabled="!editMode"
                v-model="contactInformation.prefix"
              >
                <option value>Select</option>
                <option v-for="prefix in prefixs" :key="prefix.entityId">{{prefix.entityName}}</option>
              </select>
            </div>
          </div>
          <div class="col-lg-4 col-md-8">
            <div class="form-group">
              <label>
                First Name
                <i class="fa fa-info-circle" aria-hidden="true" title="First Name"></i>
              </label>
              <input
                type="text"
                class="form-control"
                :disabled="!editMode"
                v-model="contactInformation.firstName"
              />
              <div v-if="submitted" class="error-message">
                <p v-if="!$v.contactInformation.firstName.required">{{validationMessages.REQUIRED}}</p>
                <p
                  class="error-message"
                  v-if="!$v.contactInformation.firstName.alphaNumSpecialValidation"
                >{{validationMessages.ALPHA_SPECIAL_CHARACTER_RULE_TITLE}}</p>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-4">
            <div class="form-group">
              <label>
                Middle Initial
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Middle Initial"
                ></i>
              </label>
              <input
                type="text"
                class="form-control"
                maxlength="1"
                :disabled="!editMode"
                v-model="contactInformation.middleName"
              />
              <div v-if="submitted" class="error-message">
                <p v-if="!$v.contactInformation.middleName.alpha">{{validationMessages.ALPHAONLY}}</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-5">
            <div class="form-group">
              <label>
                Last Name
                <i class="fa fa-info-circle" aria-hidden="true" title="Last Name"></i>
              </label>
              <input
                type="text"
                class="form-control"
                :disabled="!editMode"
                v-model="contactInformation.lastName"
              />
              <div v-if="submitted" class="error-message">
                <p v-if="!$v.contactInformation.lastName.required">{{validationMessages.REQUIRED}}</p>
                <p
                  class="error-message"
                  v-if="!$v.contactInformation.lastName.alphaNumSpecialValidation"
                >{{validationMessages.ALPHA_SPECIAL_CHARACTER_RULE_TITLE}}</p>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-3">
            <div class="form-group">
              <label>
                Suffix
                <i class="fa fa-info-circle" aria-hidden="true" title="Suffix"></i>
              </label>
              <select
                id="inputState"
                class="form-control"
                :disabled="!editMode"
                v-model="contactInformation.suffix"
              >
                <option value>Select</option>
                <option v-for="suffix in suffixs" :key="suffix.entityId">{{suffix.entityName}}</option>
              </select>
            </div>
          </div>

          <div class="col-lg-4 col-md-4">
            <div class="form-group">
              <label>
                Position
                <i class="fa fa-info-circle" aria-hidden="true" title="Position"></i>
              </label>
              <input
                type="text"
                class="form-control"
                :disabled="!editMode"
                v-model="contactInformation.designation"
              />
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.contactInformation.designation.maxLength"
                >{{validationMessages.MAX_LENGTH}} 40</p>
                <p
                  class="error-message"
                  v-if="!$v.contactInformation.designation.alphaNumSpecialValidation"
                >{{validationMessages.ALPHA_SPECIAL_CHARACTER_RULE_TITLE}}</p>
              </div>
            </div>
          </div>

          <div class="col-lg-2 col-md-4">
            <div class="form-group">
              <label>
                Active
                <i class="fa fa-info-circle" aria-hidden="true" title="Active"></i>
              </label>
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    :checked="contactInformation.isActive"
                    class="custom-control-input"
                    id="customCheck27"
                    @change="checkboxContactActive()"
                  />
                  <label class="custom-control-label" for="customCheck27"></label>
                </div>
              </div>
            </div>
          </div>

          <div v-if="contactInformation.isActive != true " class="col-lg-4 col-md-8">
            <div class="form-group">
              <label>
                Reason for Inactive Status
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Reason for Inactive Status"
                ></i>
              </label>
              <select
                id="inputMenu"
                class="form-control"
                :disabled="!editMode || contactInformation.isActive"
                v-model="contactInformation.inactiveReasonId"
              >
                <option value>Select</option>
                <option
                  v-for="inactivestatus in reasonforInactiveStatus"
                  :key="inactivestatus.entityId"
                  :value="inactivestatus.entityID"
                >{{inactivestatus.entityName}}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.contactInformation.inactiveReasonId.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-2 col-md-4">
            <div class="form-group">
              <label>
                Impact Level
                <i class="fa fa-info-circle" aria-hidden="true" title="Impact Level"></i>
              </label>
              <select
                id="inputState"
                class="form-control"
                :disabled="!editMode"
                v-model="contactInformation.impactLevelID"
              >
                <option value>Select</option>
                <option
                  v-for="impactlevel in impactLevels"
                  :key="impactlevel.entityId"
                  :value="impactlevel.entityId"
                >{{impactlevel.entityName}}</option>
              </select>
            </div>
          </div>
          <div class="col-lg-4 col-md-4">
            <div class="form-group">
              <label>
                Contact Type
                <i class="fa fa-info-circle" aria-hidden="true" title="Contact Type"></i>
              </label>
              <select
                id="inputMenu"
                class="form-control"
                :disabled="!editMode"
                v-model="contactInformation.contactTypeID"
              >
                <option value>Select</option>
                <option
                  v-for="ctype in contactType"
                  :key="ctype.entityId"
                  :value="ctype.entityID"
                >{{ctype.entityName}}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.contactInformation.contactTypeID.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-4">
            <div class="form-group">
              <label>
                Active for Selected Partner
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Active for Selected Partner"
                ></i>
              </label>
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    :checked="contactInformation.inActiveforSelectedPartner"
                    class="custom-control-input"
                    id="customCheck37"
                    @change="checkboxContactActiveSelectPartner()"
                  />
                  <label class="custom-control-label" for="customCheck37"></label>
                </div>
                <div v-if="submitted" class="error-message">
                  <p
                    v-if="!$v.contactInformation.inActiveforSelectedPartner.required"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-5">
            <div class="form-group">
              <label>
                Departments
                <i class="fa fa-info-circle" aria-hidden="true" title="Departments"></i>
              </label>

              <div class="button-group dropCheckbox">
                <!-- <kendo-dropdowntree
                  :class="{'form-control':true, 'disabled': !editMode}"
                  v-model="departmentsModel"
                  :data-source="departmentOptions"
                  :checkboxes="true"
                  :data-text-field="'text'"
                  :data-value-field="'value'"
                  :placeholder="'Select'"
                ></kendo-dropdowntree>-->

                <kendo-multiselect
                  id="employees"
                  :class="{'form-control':true, 'disabled': !editMode}"
                  v-model="addressDataDepartment"
                  :data-source="departmentOptions"
                  :data-text-field="'text'"
                  :data-value-field="'value'"
                  :auto-bind="true"
                  :checkboxes="true"
                  :min-length="1"
                  :value-primitive="false"
                  :auto-close="false"
                  @select="select"
                  @deselect="deselect"
                ></kendo-multiselect>
              </div>
              <div v-if="submitted" class="error-message">
                <p v-if="!$v.addressDataDepartment.required">{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-4">
            <div class="form-group">
              <label>
                Fax
                <i class="fa fa-info-circle" aria-hidden="true" title="Fax"></i>
              </label>
              <div class="custom-kendo-input" :class="{'': !editMode}">
                <kendo-maskedtextbox
                  :disabled="!editMode"
                  title="phone number"
                  v-model="contactInformation.fax"
                  mask="(999)-000-0000"
                ></kendo-maskedtextbox>
              </div>
              <p
                class="error-message"
                v-if="!$v.contactInformation.fax.phoneCustomLimit"
              >{{validationMessages.MIN_LENGTH}} 10</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-8">
            <div class="form-group">
              <label>
                Email
                <i class="fa fa-info-circle" aria-hidden="true" title="Email"></i>
              </label>
              <input
                type="text"
                class="form-control"
                :disabled="!editMode"
                v-model="contactInformation.email"
              />
              <div v-if="submitted" class="error-message">
                <p v-if="!$v.contactInformation.email.required">{{validationMessages.REQUIRED}}</p>
                <p
                  class="error-message"
                  v-if="!$v.contactInformation.email.email"
                >{{validationMessages.EMAIL}}</p>
              </div>
              <div class="error-message" v-if="isEmailAlreadyExists">
                <p>{{validationMessages.EMAIL_ALREADY_EXISTS}}</p>
              </div>
            </div>
          </div>
        </div>

        <div class="row" v-for="(contactInfo, index) in contactInformation.contacts">
          <div class="col-md-4">
            <div class="form-group">
              <label v-if="index == 0">
                Phone
                <i class="fa fa-info-circle" aria-hidden="true" title="Phone"></i>
              </label>

              <div class="custom-kendo-input" :class="{'': contactInfo.id != 0}">
                <kendo-maskedtextbox
                  :disabled="!editMode"
                  title="phone number"
                  v-model="contactInfo.phone"
                  mask="(999)-000-0000"
                ></kendo-maskedtextbox>
                <div v-if="submitted" class="error-message">
                  <p
                    v-if="!$v.contactInformation.contacts.$each[index].phone.phoneCustomLimit"
                  >{{validationMessages.MIN_LENGTH}} 10</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label v-if="index == 0">
                Extension
                <i class="fa fa-info-circle" aria-hidden="true" title="Extension"></i>
              </label>
              <input
                :disabled="!editMode"
                type="text"
                pattern="\d*"
                maxlength="8"
                v-model.number="contactInfo.ext"
                class="form-control"
              />
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.contactInformation.contacts.$each[index].ext.alphaNum"
                >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
              </div>
            </div>
          </div>
          <div class="col-md-1">
            <div class="form-group">
              <label v-if="index == 0">
                Primary
                <i class="fa fa-info-circle" aria-hidden="true" title="Primary"></i>
              </label>
              <div class="checkBoxinFrom">
                <div class="custom-control custom-radio custom-control-inline">
                  <input
                    type="radio"
                    :id="'ContactRadioA'+index"
                    name="ContactRadio"
                    class="custom-control-input"
                    :ref="'ContactRadioA'+index"
                    :disabled="!editMode"
                    :value="true"
                    v-model="contactInfo.isPrimary"
                    @change="PartnerContactDataRadio(contactInfo,index)"
                  />
                  <label class="custom-control-label" :for="'ContactRadioA'+index"></label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-1 text-left">
            <div :class="index == 0 ? 'mt-3 pt-3' : '' " class="form-group mt-1">
              <a
                :disabled="!editMode"
                href="javascript:void(0)"
                @click.prevent="!editMode? '#':removeContactInfo(index)"
                v-if="index !== contactInformation.contacts.length-1 && !contactInfo.isPrimary"
              >
                <i
                  aria-hidden="true"
                  :class="contactInfo.isActive? 'fas fa-trash AddDelBtn': 'fas fa-trash AddDelBtn custom-delete-btn'"
                ></i>
              </a>

              <a
                href="javascript:void(0)"
                :disabled="!editMode"
                @click="!editMode ? '#' : addContactInfo()"
                v-if="index === contactInformation.contacts.length-1"
              >
                <i
                  :class="{'icon-model-options disabled':!editMode, 'icon-model-options AddDelBtn':true, 'disable-btn':!contactInfo.phone}"
                  aria-hidden="true"
                ></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import Vue from 'vue';
import { DropDownTree, DropDownTreeInstaller } from '@progress/kendo-dropdowntree-vue-wrapper';
import { required, alpha, helpers, maxLength, requiredIf, email, alphaNum } from 'vuelidate/lib/validators';
import { PartnersUrls, MasterUrls } from '../../../shared/constants/urls';
import partnerService from '../services/partners-service';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import { PatternValidation } from '../../../shared/constants/pattern-validation';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

Vue.use(DropDownTreeInstaller);
const alphaNumSpecialValidation = helpers.regex('alphaNumSpecialValidationRuleTitle', PatternValidation.alphaNumSpecialValidation);
const phoneCustomLimit = value => !helpers.req(value) || value.replace(/\D/g, '').substring(0, 10).length === 10;

export default {
  name: 'PartnerContactInfromation',
  props: ['headerData'],
  data() {
    return {
      validationMessages: VALIDATION_MESSAGE,
      editMode: false,
      submitted: false,
      isEmailAlreadyExists: false,
      reasonforInactiveStatus: [],
      contactType: [],
      //New Approch Starts here
      departmentResult: [],
      departmentOptions: [],
      addressDataDepartment: [],
      newArrayforDepartment: [],
      //New Approch Ends here
      prefixs: [
        {
          entityId: 'Mr.',
          entityName: 'Mr.'
        },
        {
          entityId: 'Ms',
          entityName: 'Ms.'
        },
        {
          entityId: 'Mrs',
          entityName: 'Mrs.'
        },
        {
          entityId: 'Miss',
          entityName: 'Miss'
        },
        {
          entityId: 'Dr',
          entityName: 'Dr.'
        }
      ],
      suffixs: [
        {
          entityId: 'Jr',
          entityName: 'Jr.'
        },
        {
          entityId: 'Sr',
          entityName: 'Sr.'
        },
        {
          entityId: 'I',
          entityName: 'I'
        },
        {
          entityId: 'II',
          entityName: 'II'
        }
      ],
      impactLevels: [
        {
          entityId: 1,
          entityName: 'Low'
        },
        {
          entityId: 2,
          entityName: 'Medium'
        },
        {
          entityId: 3,
          entityName: 'High'
        }
      ],
      contactInformation: {
        partnerId: Number(this.$route.params.id),
        contactId: 0,
        partnerContactID: 0,
        prefix: '',
        firstName: '',
        middleName: '',
        lastName: '',
        suffix: '',
        designation: '',
        isActive: false,
        inactiveReasonId: '',
        impactLevelID: '',
        contactTypeID: '',
        inActiveforSelectedPartner: true,
        fax: '',
        email: '',
        contacts: [{ phoneId: 0, phone: '', ext: '', isPrimary: true, isActive: true }],
        departments: []
      }
    };
  },
  validations: {
    addressDataDepartment: { required },
    contactInformation: {
      firstName: { required, alphaNumSpecialValidation },
      middleName: {
        alpha
        // OneUpperCaseAtleast
      },
      lastName: { required, alphaNumSpecialValidation },
      designation: { alphaNumSpecialValidation, maxLength: maxLength(40) },
      inactiveReasonId: {
        required: requiredIf(vm => {
          if (vm.isActive !== true) {
            return true;
          }
          return false;
        })
      },
      contactTypeID: { required },
      inActiveforSelectedPartner: { required },
      fax: { phoneCustomLimit },
      email: { required, email },
      contacts: {
        $each: {
          ext: { alphaNum },
          phone: { phoneCustomLimit }
        }
      }
    }
  },
  async created() {
    await this.getMasterData(this.$route.params.id);
    if (this.$route.params.id && this.$store.getters.getPartnerContactId !== '') {
      this.getContactInformation();
    } else {
      this.editMode = true;
      this.contactInformation.isActive = true;
    }
  },
  methods: {
    select: function(e) {
      var item = e.dataItem;
      const currentId = item.value;
      let obj = this.departmentResult.find(o => o.partnerDepartmentId === currentId);

      if (obj === undefined) {
        this.departmentResult.push({ id: 0, partnerDepartmentId: currentId, isActive: true });
      } else {
        obj.isActive = true;
      }
    },
    deselect: function(e) {
      var item = e.dataItem;
      const currentId = item.value;
      let obj = this.departmentResult.find(o => o.partnerDepartmentId === currentId);

      if (obj !== undefined && obj.id !== 0) {
        obj.isActive = false;
      } else {
        let index = this.departmentResult.findIndex(o => o.partnerDepartmentId === currentId);
        this.departmentResult.splice(index, 1);
      }
    },

    /**
     * PartnerContactDataRadio
     */
    PartnerContactDataRadio(item, i) {
      this.contactInformation.contacts.forEach((element, index) => {
        if (index === i) {
          this.contactInformation.contacts[index].isActive = true;
          this.contactInformation.contacts[index].isPrimary = true;
        } else {
          this.contactInformation.contacts[index].isPrimary = false;
        }
      });
    },
    /**
     * addContactInfo() add dynamic input for contact info
     */
    addContactInfo() {
      const newContactInfo = { phoneId: 0, phone: '', ext: '', isPrimary: false, isActive: true };
      this.contactInformation.contacts.push(newContactInfo);
    },
    /**
     * removeContactInfo() remove dynamic input for contact info
     */
    removeContactInfo(index) {
      if (this.contactInformation.contacts[index].contactId) {
        this.contactInformation.contacts[index].isActive = !this.contactInformation.contacts[index].isActive;
      }
    },
    /**
     * Get All Master Data Dropdown
     */
    getMasterData() {
      partnerService
        .getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Departments&id=${this.$route.params.id}`)
        // eslint-disable-next-line arrow-parens
        .then(res => {
          const partnerSpecificDepartment = res.data.data.Departments;
          if (partnerSpecificDepartment) {
            this.departmentData = partnerSpecificDepartment;
            // eslint-disable-next-line arrow-parens
            partnerSpecificDepartment.forEach(element => {
              this.departmentOptions.push({ text: element.entityName, value: element.entityID });
            });
          }
        });
      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=ReasonForInactiveStatus`).then(response => {
        if (response.data) {
          this.reasonforInactiveStatus = response.data.data.ReasonforInactiveStatus;
        }
      });
      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=ContactType`).then(response => {
        if (response.data) {
          this.contactType = response.data.data.ContactType;
        }
      });
    },
    /**
     * Cancel Method OnClick Event
     */
    cancelContactInfromation() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.submitted = false;
        if (this.$store.getters.getPartnerContactId !== '') {
          this.editMode = false;
          this.getContactInformation();
        } else {
          this.$emit('onGridCancel');
        }
      }
      return false;
    },
    /**
     * Get Partner Contact Details
     * Single Row Element
     */
    getContactInformation() {
      partnerService
        .getPartnersResult(
          `${PartnersUrls.GET_PARTNERS_SINGLE_CONTACT}?partnerId=${this.$route.params.id}&partnerContactId=${this.$store.getters.getPartnerContactId}`
        )
        .then(response => {
          if (response.data.data) {
            const result = response.data.data;

            const departmentArray = [];
            const department = [];
            result.departments.forEach(element => {
              const departmentResult = { id: element.id, partnerDepartmentId: element.partnerDepartmentId, isActive: element.isActive };
              departmentArray.push(departmentResult);
              department.push(element.partnerDepartmentId);
            });
            this.departmentResult = departmentArray;
            this.addressDataDepartment = department;
            this.newArrayforDepartment = department;
            this.contactInformation = result;
            this.contactInformation.departments = departmentArray;
            this.$store.dispatch('setContactId', this.contactInformation.contactId);
          }
        });
    },
    /**
     * Save Partner Contact Details
     */
    saveContactInfromation() {
      this.submitted = true;
      this.$v.$touch();

      if (this.$v.$invalid) {
        return;
      }

      const phoneArray = [];
      this.contactInformation.contacts.forEach(element => {
        phoneArray.push({ id: element.phoneId, phone: element.phone, ext: element.ext.toString(), isPrimary: element.isPrimary, isActive: element.isActive });
      });

      if (this.contactInformation.inactiveReasonId === '') {
        this.contactInformation.inactiveReasonId = 0;
      }
      this.contactInformation.partnerId = Number(this.$route.params.id);
      this.contactInformation.phone = phoneArray;
      this.contactInformation.middleName = this.contactInformation.middleName.toUpperCase();
      if (this.contactInformation.impactLevelID === '') {
        this.contactInformation.impactLevelID = null;
      }

      this.contactInformation.departments = this.departmentResult;

      partnerService.postPartnersDataAction(`${PartnersUrls.SAVE_PARTNER_CONTACT}`, this.contactInformation).then(response => {
        if (response.data.apiResponseStatus === 'OK') {
          this.editMode = false;
          this.$store.dispatch('setPartnerContactId', response.data.data);
          this.getContactInformation();
          this.$emit('onShowHideLoader', false);
          this.$emit('onPartnerAdded');
          this.isEmailAlreadyExists = false;
          showToast('success');
        } else {
          if (response.data.errors[0].userMessage === 'Email Id already exist') {
            this.isEmailAlreadyExists = true;
          }
        }
      });
    },

    /**
     * Reverse Engineering for Checkbox issue
     * checkboxContactActive()
     * checkboxContactActiveSelectPartner()
     */
    checkboxContactActive() {
      this.contactInformation.isActive = !this.contactInformation.isActive;
    },
    checkboxContactActiveSelectPartner() {
      this.contactInformation.inActiveforSelectedPartner = !this.contactInformation.inActiveforSelectedPartner;
    }
  }
};
</script>