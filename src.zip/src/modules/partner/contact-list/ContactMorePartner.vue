<template>
  <div class="card">
    <div class="card-header" id="headingFour">
      <h5 class="mb-0">
        <button
          class="btn btn-link"
          data-toggle="collapse"
          data-target="#collapseFour"
          aria-expanded="true"
          aria-controls="collapseThree"
          @click="callAPItoFetchData()"
        >More Partners…</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseFour"
          aria-expanded="true"
          @click="callAPItoFetchData()"
        ></i>
      </div>
    </div>
    <div
      id="collapseFour"
      class="collapse"
      aria-labelledby="headingThree"
      data-parent="#accordion"
      style
    >
      <div class="card-body">
        <div class="row border-bottom">
          <div class="col-md-12 pt-2 pb-2 text-right">
            <div class="workingBtn" v-if="editMode">
              <button type="button" class="edit-btn" @click="onEditClicked">Edit</button>
            </div>
            <span v-if="!editMode">
              <button type="button" class="save-btn mr-1" @click.prevent="onSaveClicked">Save</button>
              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </span>
          </div>
        </div>
        <div class="row">
          <div class="col-md-8 mt-2 mb-2" v-if="editMode">
            <!-- <label>
              Partner Name
              <i class="fa fa-info-circle" aria-hidden="true" title="Partner Name"></i>
            </label>-->
            <input type="text" class="form-control" disabled placeholder="Enter Partner Name..." />
          </div>
          <div class="col-md-8 mt-2 mb-2" v-if="!editMode">
            <!-- <label>
              Partner Name
              <i class="fa fa-info-circle" aria-hidden="true" title="Partner Name"></i>
            </label>-->

            <div :class="editMode?'custom-disabled custom-autocomplete': 'custom-autocomplete'">
              <AutoComplete
                :searchedItem="searchedPartner"
                :itemIndex="0"
                :distroyThis="distroyItem "
                :initialPlaceHolder="'Enter Partner Name...'"
                @autoFilterData="searchPartnerResult"
                @setSeletecDataToInputs="setDataInputs"
                @emptySelectedFields="removeSelectedFields"
                :paramToBind="'partnerName'"
                :bindToInput="'partnerName'"
              ></AutoComplete>
              <div
                v-if="alreadyExist"
                class="invalid-text"
              >Item {{suggestedField}} already exist in list</div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-8">
            <div class="form-group">
              <label>
                Partner Name
                <i class="fa fa-info-circle" aria-hidden="true" title="Partner Name"></i>
              </label>
            </div>
          </div>
          <div class="col-md-2">
            <div class="form-group">
              <label>
                Active
                <i class="fa fa-info-circle" aria-hidden="true" title="Active"></i>
              </label>
            </div>
          </div>
        </div>

        <div class="row" v-for="(contacts,index) in modelData.searchedPartner" :key="contacts.id">
          <div class="col-md-8">
            <div class="form-group">
              <input class="form-control" :disabled="true" :value="contacts.partnerName" />
            </div>
          </div>

          <div class="col-md-2">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div
                  :class=" contacts.isActive  ? 'custom-control custom-checkbox': 'custom-control custom-checkbox custom-disabled-check'"
                >
                  <input
                    :disabled="true"
                    class="custom-control-input"
                    type="checkbox"
                    :id="'customCheck' + index"
                    :checked="contacts.isActive"
                  />
                  <label class="custom-control-label" :for="'customCheck' + index"></label>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import partnerService from '../services/partners-service';
import { PartnersUrls } from '../../../shared/constants/urls';
import AutoComplete from '../../../components/AutoComplete';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { showToast } from '../../../shared/services/toast-service';

export default {
  name: 'ContactMorePartner',
  components: {
    AutoComplete
  },
  data() {
    return {
      contactId: null,
      validationsMessages: VALIDATION_MESSAGES,
      suggestedField: '',
      alreadyExist: false,
      searchedPartner: [],
      modelData: {},
      postPartnerData: {
        contactId: this.$store.getters.getContactId,
        partnerContact: [],
        userId: 1
      },
      editMode: true,
      distroyItem: null
    };
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    // cancel will revert whole edited data to previous state
    async onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.alreadyExist = false;
        this.editMode = true;
        this.$emit('togglePanel', this.editMode, this.itemIndex);
        await this.callAPItoFetchData();
      }
      return false;
    },
    async onChildCancelClicked() {
      this.alreadyExist = false;
      this.editMode = true;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
      await this.callAPItoFetchData();
    },
    // Save functionality will go here
    onSaveClicked() {
      this.alreadyExist = false;
      if (this.modelData && this.modelData.searchedPartner && this.modelData.searchedPartner.length > 0) {
        this.callAPIToSaveModelData();
        /**
         * This code is commented for future extend for delete functionlity
         */
        // const delData = this.modelData.searchedPartner.filter(item => item.isActive === false);
        // this.deletedRecord = delData.length;
        // if (this.deletedRecord !== 0) {
        // eslint-disable-next-line no-alert
        // const answer = window.confirm(`${this.deletedRecord} ${this.validationsMessages.INPUTDELETERECORD}`);
        // if (answer) {
        // this.callAPIToSaveModelData();
        // }
        // } else {
        // this.callAPIToSaveModelData();
        // }
      }
    },
    callAPIToSaveModelData() {
      // eslint-disable-next-line arrow-parens
      this.modelData.searchedPartner.forEach(element => {
        this.postPartnerData.partnerContact.push({
          id: element.id,
          partnerId: element.partnerId,
          isActive: true
        });
      });
      this.postPartnerData.contactId = this.$store.getters.getContactId;
      // eslint-disable-next-line arrow-parens
      partnerService.postPartnersData(PartnersUrls.SAVE_PARTNER_CONTACT_MAP, this.postPartnerData).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.postPartnerData.partnerContact.length = 0;
          this.callAPItoFetchData();
          this.editMode = true;
          this.$emit('togglePanel', this.editMode, this.itemIndex);
          showToast('success');
        }
      });
    },
    checkEmptyModelNameInArray() {
      // eslint-disable-next-line array-callback-return
      const items = this.modelData.searchedPartner.filter((item, index) => {
        // eslint-disable-next-line no-unused-expressions
        item.partnerName === '' && index !== this.modelData.searchedPartner.length - 1;
      });
      if (items) {
        return true;
      }
      return false;
    },
    onEditClicked() {
      this.alreadyExist = false;
      this.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    // eslint-disable-next-line no-unused-vars
    setDataInputs(selectedData, itemIndex) {
      this.alreadyExist = false;
      if (this.modelData.searchedPartner.length === 0) {
        const partnerObject = {
          id: 0,
          partnerId: selectedData.partnerId,
          partnerName: selectedData.partnerName,
          isActive: true
        };
        this.modelData.searchedPartner.push(partnerObject);
      } else {
        this.suggestedField = selectedData.partnerName;
        const standObj = this.modelData.searchedPartner.find(item => item.partnerName.trim().toLowerCase() === selectedData.partnerName.trim().toLowerCase());
        if (!standObj) {
          const partnerObject = {
            id: 0,
            partnerId: selectedData.partnerId,
            partnerName: selectedData.partnerName,
            isActive: true
          };
          this.modelData.searchedPartner.push(partnerObject);
        } else {
          this.alreadyExist = true;
        }
      }
    },
    // eslint-disable-next-line no-unused-vars
    searchPartnerResult(searchValue) {
      // eslint-disable-next-line arrow-parens
      partnerService
        .getPartnersResult(`${PartnersUrls.SEARCH_PARTNER_CONTACT_MAP}?searchedItem=${searchValue}&contactId=${this.$store.getters.getContactId}`)
        .then(res => {
          if (res.data.apiResponseStatus !== 'Failed') {
            this.searchedPartner = res.data.data;
          }
        });
    },
    deleteElements(index) {
      if (this.modelData.searchedPartner[index].modelsearchedPartnerId === 0) {
        this.modelData.searchedPartner.splice(index, 1);
      } else {
        this.modelData.searchedPartner[index].isActive = !this.modelData.searchedPartner[index].isActive;
      }
    },
    // eslint-disable-next-line no-unused-vars
    removeSelectedFields(textValue, index) {
      this.alreadyExist = false;
      this.suggestedField = textValue;
    },
    callAPItoFetchData() {
      setTimeout(() => {
        // eslint-disable-next-line arrow-parens
        partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNER_CONTACT_MAP}?contactId=${this.$store.getters.getContactId}`).then(res => {
          if (res.data.apiResponseStatus !== 'Failed') {
            this.postPartnerData.partnerContact.length = 0;
            this.modelData = {
              contactId: this.$store.getters.getContactId,
              userId: 1,
              searchedPartner: res.data.data
            };
          } else {
            this.modelData = {
              contactId: this.$store.getters.getContactId,
              userId: 1,
              searchedPartner: []
            };
          }
        });
      }, 400);
    },
    preventNav(event) {
      if (this.editMode) return;
      event.preventDefault();
      // Chrome requires returnValue to be set.
      // eslint-disable-next-line no-param-reassign
      event.returnValue = '';
    }
  },
  created() {
    if (this.$store.getters.getContactId) {
      this.callAPItoFetchData();
      this.editMode = true;
    }
  }
};
</script>