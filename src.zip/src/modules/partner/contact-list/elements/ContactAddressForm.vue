<template>
  <div class="card-body">
    <div class="row">
      <div class="col-md-12 text-right mb-1 mt-1">
        <div
          id="savebtn-box"
          class="mb-1 mt-1"
          style="border-bottom: 1px solid #efefef; padding-bottom:4px;"
        >
          <button type="button" class="save-btn mr-1" @click.prevent="saveAddress">Save</button>

          <button type="button" class="cancel-btn" @click.prevent="cancelAddress">Cancel</button>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-12">
        <div id="table1" class="edit-associated-block" style="border:none; padding: 0;">
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label>
                  Address 1
                  <i class="fa fa-info-circle" aria-hidden="true" title="Address 1"></i>
                </label>
                <input type="text" class="form-control" v-model="parterContactAddress.address1" />
                <div v-if="submitted" class="error-message">
                  <p
                    v-if="!$v.parterContactAddress.address1.required"
                  >{{validationMessages.REQUIRED}}</p>
                  <p
                    v-if="!$v.parterContactAddress.address1.alphaNumSpecialValidation"
                  >{{validationMessages.ALPHA_SPECIAL_CHARACTER_RULE_TITLE}}</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label>
                  Address 2
                  <i class="fa fa-info-circle" aria-hidden="true" title="Address 2"></i>
                </label>
                <input type="text" class="form-control" v-model="parterContactAddress.address2" />
                <div v-if="submitted" class="error-message">
                  <p
                    v-if="!$v.parterContactAddress.address2.alphaNumSpecialValidation"
                  >{{validationMessages.ALPHA_SPECIAL_CHARACTER_RULE_TITLE}}</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label>
                  City
                  <i class="fa fa-info-circle" aria-hidden="true" title="City"></i>
                </label>
                <input type="text" class="form-control" v-model="parterContactAddress.city" />
                <div v-if="submitted" class="error-message">
                  <p v-if="!$v.parterContactAddress.city.required">{{validationMessages.REQUIRED}}</p>
                  <p
                    v-if="!$v.parterContactAddress.city.alphaNumSpaceDot"
                  >{{validationMessages.ALPHA_NUMERIC_SPACES_DOT}}</p>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label>
                  State
                  <i class="fa fa-info-circle" aria-hidden="true" title="State"></i>
                </label>
                <select id="inputMenu" class="form-control" v-model="parterContactAddress.stateId">
                  <option value>Select</option>
                  <option
                    v-for="state in stateoptions"
                    :key="state.entityID"
                    :value="state.entityID"
                  >{{state.entityName}}</option>
                </select>
                <div v-if="submitted" class="error-message">
                  <p
                    v-if="!$v.parterContactAddress.stateId.required"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label>
                  Zip
                  <i class="fa fa-info-circle" aria-hidden="true" title="Zip"></i>
                </label>
                <input
                  maxlength="5"
                  pattern="\d*"
                  class="form-control"
                  v-model.number="parterContactAddress.zip"
                />
                <div v-if="submitted" class="error-message">
                  <p v-if="!$v.parterContactAddress.zip.required">{{validationMessages.REQUIRED}}</p>
                  <p v-if="!$v.parterContactAddress.zip.numeric">{{validationMessages.INTEGER}}</p>
                  <p
                    v-if="!$v.parterContactAddress.zip.minLen"
                  >{{validationMessages.MIN_LENGTH}} {{$v.parterContactAddress.zip.$params.minLen.min}}</p>
                  <p
                    v-if="!$v.parterContactAddress.zip.maxLen"
                  >{{validationMessages.MAX_LENGTH}} {{$v.parterContactAddress.zip.$params.maxLen.max}}</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label>
                  Country
                  <i class="fa fa-info-circle" aria-hidden="true" title="Country"></i>
                </label>
                <select
                  id="inputMenu"
                  class="form-control"
                  v-model="parterContactAddress.countryId"
                >
                  <option value>Select</option>
                  <option
                    v-for="country in countryOptions"
                    :key="country.entityID"
                    :value="country.entityID"
                  >{{country.entityName}}</option>
                </select>
                <div v-if="submitted" class="error-message">
                  <p
                    v-if="!$v.parterContactAddress.countryId.required"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import { PartnersUrls, MasterUrls } from '../../../../shared/constants/urls';
import partnerService from '../../services/partners-service';
import { required, helpers, minLength, maxLength, numeric } from 'vuelidate/lib/validators';
import { PatternValidation } from '../../../../shared/constants/pattern-validation';
import VALIDATION_MESSAGE from '../../../../shared/constants/messages';
import { showToast } from '../../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../../shared/services/window-confrim';

const alphaNumSpecialValidation = helpers.regex('alphaNumSpecialValidation', PatternValidation.alphaNumSpecialValidation);
const alphaNumSpaceDot = helpers.regex('alphaNumSpaceDot', PatternValidation.alphaNumSpaceDot);

export default {
  name: 'ContactAddressForm',
  data() {
    return {
      submitted: false,
      stateoptions: [],
      countryOptions: [],
      parterContactAddress: {
        address1: '',
        address2: '',
        city: '',
        stateId: '',
        zip: '',
        countryId: 1,
        addressId: 0,
        userId: 1
      }
    };
  },
  props: {
    showBlock: {
      type: Boolean,
      required: true
    },
    validationMessages: {
      required: true
    }
  },
  validations: {
    parterContactAddress: {
      address1: { required, alphaNumSpecialValidation },
      address2: { alphaNumSpecialValidation },
      city: { required, alphaNumSpaceDot },
      stateId: { required },
      zip: { required, numeric, minLen: minLength(5), maxLen: maxLength(5) },
      countryId: { required }
    }
  },
  methods: {
    cancelAddress() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.emitShowBlock();
      }
      return false;
    },
    saveAddress() {
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        // eslint-disable-next-line no-useless-return
        return;
      }

      const postData = {
        contactId: Number(this.$store.getters.getContactId),
        addressId: this.parterContactAddress.addressId,
        address1: this.parterContactAddress.address1,
        address2: this.parterContactAddress.address2,
        city: this.parterContactAddress.city,
        stateId: this.parterContactAddress.stateId,
        zip: Number(this.parterContactAddress.zip),
        countryId: this.parterContactAddress.countryId === '' ? null : this.parterContactAddress.countryId,
        isActive: true,
        userId: 1
      };

      partnerService.postPartnersDataAction(`${PartnersUrls.SAVE_PARTNER_CONTACT_ADDRESS}`, postData).then(response => {
        if (response.data.apiResponseStatus === 'OK') {
          showToast('success');
          this.emitShowBlock();
        }
      });
    },
    /**
     * Get All Master Data Dropdown
     */
    getMasterData() {
      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=State%7CCountry`).then(response => {
        if (response.data) {
          this.stateoptions = response.data.data.State;
          this.countryOptions = response.data.data.Country;
        }
      });
    },
    /**
     * emitShowBlock method will retuen prop data to parent component for toggle block
     */
    emitShowBlock() {
      this.$emit('updateShowBlock', false);
    },
    /**
     * CallGetAddressAPI method will load data based on param contact id
     * @param contactID (INT)
     */
    CallGetAddressAPI(contactID) {
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNER_CONTACT_ADDRESS}?contactId=${contactID}`).then(response => {
        if (response.data.data !== null) {
          const result = response.data.data;
          this.parterContactAddress = result;
        } else {
          this.noDataFound = true;
        }
      });
    }
  },
  async created() {
    this.getMasterData();
    if (this.$store.getters.getContactId) {
      await this.CallGetAddressAPI(this.$store.getters.getContactId);
    }
  }
};
</script>