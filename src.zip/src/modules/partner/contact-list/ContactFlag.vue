<template>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button
          class="btn btn-link"
          data-toggle="collapse"
          data-target="#collapseThree"
          aria-expanded="true"
          aria-controls="collapseThree"
          @click="callGetPartnerContactAPI()"
        >Flags</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseThree"
          aria-expanded="true"
          @click="callGetPartnerContactAPI()"
        ></i>
      </div>
    </div>
    <div
      id="collapseThree"
      class="collapse"
      aria-labelledby="headingThree"
      data-parent="#accordion"
      style
    >
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid rgb(239, 239, 239);">
          <div class="col-md-12 text-right mb-1 mt-1">
            <div v-if="!editMode">
              <button type="button" class="edit-btn" @click="editMode = !editMode">Edit</button>
            </div>
            <div v-else>
              <button
                type="button"
                class="save-btn mr-1"
                @click.prevent="savePartnerContactFlag()"
              >Save</button>
              <button type="button" class="cancel-btn" @click.prevent="cancelClicked()">Cancel</button>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck10"
                    @change="marketingEmail()"
                    :checked="partnerContactFlag.isOptForMarketing"
                  />
                  <label class="custom-control-label" for="customCheck10">Marketing Email</label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck11"
                    @change="appointmentRequired()"
                    :checked="partnerContactFlag.isAppointmentReq"
                  />
                  <label class="custom-control-label" for="customCheck11">
                    Appointment
                    Required
                  </label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck12"
                    @change="decisionMaker()"
                    :checked="partnerContactFlag.isDecisionMaker"
                  />
                  <label class="custom-control-label" for="customCheck12">Decision Maker</label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck13"
                    @change="mobileAccess()"
                    :checked="partnerContactFlag.isMobileUser"
                  />
                  <label class="custom-control-label" for="customCheck13">Mobile Access</label>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-3 mt-3">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck14"
                    @change="portalAccess()"
                    :checked="partnerContactFlag.isPortalUser"
                  />
                  <label class="custom-control-label" for="customCheck14">mySMARTS Access</label>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-3 mt-3" v-if="hideClass">
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck15"
                    @change="isNotifyDelivery()"
                    :checked="partnerContactFlag.isNotifyDelivery"
                  />
                  <label class="custom-control-label" for="customCheck15">
                    Receive Pickup/Delivery
                    Notification
                  </label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3" v-if="hideClass">
            <div class="form-group mt-3">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="!editMode"
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck16"
                    @change="isNotifyPM()"
                    :checked="partnerContactFlag.isNotifyPM"
                  />
                  <label class="custom-control-label" for="customCheck16">PM Due Recipient</label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3" v-if="hideClass">
            <div class="form-group">
              <label>User Group</label>
              <select
                id="inputState"
                class="form-control"
                v-model="partnerContactFlag.userGroupID"
                :disabled="!editMode"
              >
                <option value>Select</option>
                <option
                  v-for="usergroup in partnerGroupMockup"
                  :key="usergroup.id"
                  :value="usergroup.id"
                >{{usergroup.text}}</option>
              </select>
              <div v-if="submitted" class="error-message">
                <p
                  v-if="!$v.partnerContactFlag.userGroupID.required"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import partnerService from '../services/partners-service';
import { PartnersUrls } from '../../../shared/constants/urls';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import { showToast } from '../../../shared/services/toast-service';
import { requiredIf } from 'vuelidate/lib/validators';

export default {
  name: 'ContactFlag',
  data() {
    return {
      validationMessages: VALIDATION_MESSAGE,
      submitted: false,
      // TODO: Make it dynamic
      // Fetch Data from Master
      partnerGroupMockup: [
        {
          id: 1,
          text: 'Group 1'
        },
        {
          id: 2,
          text: 'Group 2'
        }
      ],
      hideClass: false,
      partnerContactFlag: {
        contactId: 3,
        isOptForMarketing: false,
        isAppointmentReq: false,
        isDecisionMaker: false,
        isMobileUser: false,
        isPortalUser: false,
        isNotifyDelivery: false,
        isNotifyPM: false,
        userGroupID: '',
        userId: 1,
        retValue: 0
      },
      editMode: false
    };
  },
  validations: {
    partnerContactFlag: {
      userGroupID: {
        required: requiredIf(vm => {
          if (vm.isPortalUser === true) {
            return true;
          }
          return false;
        })
      }
    }
  },
  methods: {
    /**
     * Process All checkboxes
     */
    marketingEmail() {
      this.partnerContactFlag.isOptForMarketing = !this.partnerContactFlag.isOptForMarketing;
    },
    appointmentRequired() {
      this.partnerContactFlag.isAppointmentReq = !this.partnerContactFlag.isAppointmentReq;
    },
    decisionMaker() {
      this.partnerContactFlag.isDecisionMaker = !this.partnerContactFlag.isDecisionMaker;
    },
    mobileAccess() {
      this.partnerContactFlag.isMobileUser = !this.partnerContactFlag.isMobileUser;
    },
    portalAccess() {
      this.partnerContactFlag.isPortalUser = !this.partnerContactFlag.isPortalUser;
      if (this.partnerContactFlag.isPortalUser) {
        this.partnerContactFlag.isNotifyDelivery = false;
        this.partnerContactFlag.isNotifyPM = false;
        this.partnerContactFlag.userGroupID = '';
        this.hideClass = true;
      } else {
        this.hideClass = false;
      }
    },
    isNotifyDelivery() {
      this.partnerContactFlag.isNotifyDelivery = !this.partnerContactFlag.isNotifyDelivery;
    },
    isNotifyPM() {
      this.partnerContactFlag.isNotifyPM = !this.partnerContactFlag.isNotifyPM;
    },
    /**
     * Save Button Action Method
     */
    savePartnerContactFlag() {
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      }
      // eslint-disable-next-line no-unused-vars
      if (this.partnerContactFlag.userGroupID === '') {
        this.partnerContactFlag.userGroupID = 0;
      }
      // eslint-disable-next-line arrow-parens
      partnerService.postPartnersData(`${PartnersUrls.SAVE_PARTNER_CONTACT_FLAGS}`, this.partnerContactFlag).then(response => {
        if (response.data.data) {
          this.callGetPartnerContactAPI();
          this.editMode = false;
          showToast('success');
          this.submitted = false;
        }
      });
    },
    /**
     * Cancel Button Action Method
     */
    cancelClicked() {
      // eslint-disable-next-line no-alert
      const cancel = showWindowConfrim();
      if (cancel) {
        this.editMode = false;
        this.callGetPartnerContactAPI();
      }
      return false;
    },
    /**
     * this scope of code get executed for getting partners flags
     */
    callGetPartnerContactAPI() {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNER_CONTACT_FLAGS}?contactId=${this.$store.getters.getContactId}`).then(res => {
        if (res.data && res.data.data) {
          this.partnerContactFlag = res.data.data;
          if (this.partnerContactFlag.isPortalUser) {
            this.hideClass = true;
          }
          if (this.partnerContactFlag.userGroupID === 0) {
            this.partnerContactFlag.userGroupID = '';
          }
        }
      });
    }
  },
  mounted() {
    if (this.$store.getters.getContactId) {
      this.callGetPartnerContactAPI();
    }
  }
};
</script>