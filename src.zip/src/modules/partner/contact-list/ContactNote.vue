<template>
  <div class="card">
    <div class="card-header" id="headingSeven">
      <h5 class="mb-0">
        <button
          class="btn btn-link"
          data-toggle="collapse"
          data-target="#collapseSeven"
          aria-expanded="true"
          aria-controls="collapseSeven"
          @click="getNotesInformation()"
        >Notes</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseSeven"
          aria-expanded="true"
          @click="getNotesInformation()"
        ></i>
      </div>
    </div>
    <div
      id="collapseSeven"
      class="collapse"
      aria-labelledby="headingThree"
      data-parent="#accordion"
      style
    >
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid #efefef;">
          <div class="col-md-12 text-right mb-1 pt-1">
            <div v-if="!editMode" class="FormworkingBtn">
              <a @click="editMode=!editMode" href="javascript:void(0)">
                <i class="icon-model-options" aria-hidden="true"></i> Add New Note
              </a>
            </div>
            <div v-else>
              <button type="button" class="save-btn mr-1" @click.prevent="handleSave">Save</button>
              <button type="button" class="cancel-btn" @click.prevent="handleCancel">Cancel</button>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-right mb-2"></div>
          <div class="col-md-12">
            <div class="form-group">
              <textarea
                :disabled="!editMode"
                v-model="noteData.noteDescription"
                class="form-control"
                rows="3"
                id="comment"
              ></textarea>
            </div>
            <div v-if="submitted" class="error-message">
              <p v-if="!$v.noteData.noteDescription.required">{{validationMessages.REQUIRED}}</p>
            </div>
          </div>
        </div>
        <div class="row borderonep" v-for="(note,index) in notesInformation">
          <div class="col-md-12 mb-2"></div>
          <div class="col-md-12 mb-2">{{note.noteDescription}}</div>
          <div class="col-md-6 tcolor2 mb-3" style="color: #0053a0; font-size:13px;">
            {{note.userName}} &nbsp; &nbsp; {{note.createdDate | formatDateTime}}
            &nbsp;
            <a
              href="#"
              @click="handleEdit"
              v-if="index===0"
            >
              <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { required } from 'vuelidate/lib/validators';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';

import partnerService from '../services/partners-service';
import { NotesUrls } from '../../../shared/constants/urls';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

export default {
  props: {},
  components: {},
  data() {
    return {
      validationMessages: VALIDATION_MESSAGE,
      editMode: false,
      submitted: false,
      notesInformation: [],
      contactId: 0,
      showLoader: false,
      noteData: { noteId: 0, uqId: this.$store.getters.getContactId, noteDescription: '', isAlert: false, userId: 1, ident: 'Contacts' },
      statusOptions: []
    };
  },
  methods: {
    getNotesInformation() {
      this.$store.dispatch('setLoaderStatus', true);
      // eslint-disable-next-line arrow-parens
      setTimeout(() => {
        // eslint-disable-next-line arrow-parens
        partnerService.getPartnersResult(`${NotesUrls.GET_NOTE}?RefId=${this.$store.getters.getContactId}&Identifier=Contacts`).then(res => {
          if (res.data !== null) {
            this.$store.dispatch('setLoaderStatus', false);
            this.notesInformation = res.data.data;
          }
        });
      }, 250);
    },
    handleSave() {
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        this.showLoader = false;
        return;
      }
      this.noteData.uqId = this.$store.getters.getContactId;
      // eslint-disable-next-line arrow-parens
      partnerService.postPartnersDataAction(`${NotesUrls.POST_NOTE}`, this.noteData).then(res => {
        if (res) {
          // this.$store.dispatch('setLoaderStatus', false);
          this.submitted = false;
          this.editMode = false;
          this.noteData.isAlert = false;
          this.noteData.noteDescription = '';
          this.noteData.noteId = 0;
          showToast('success');
          this.getNotesInformation();
          this.showLoader = false;
        }
      });
    },
    handleCancel() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.editMode = false;
        this.noteData.isAlert = false;
        this.noteData.noteDescription = '';
        this.noteData.noteId = 0;
        this.submitted = false;
      }
      return false;
    },
    handleEdit() {
      this.noteData.noteDescription = this.notesInformation[0].noteDescription;
      this.noteData.isAlert = this.notesInformation[0].isAlert;
      this.noteData.noteId = this.notesInformation[0].noteId;
      this.editMode = true;
    }
  },
  validations: {
    noteData: {
      noteDescription: {
        required
      }
    }
  },
  mounted() {
    if (this.$store.getters.getContactId) {
      this.getNotesInformation();
    }
  }
};
</script>

<style scoped>
.borderonep {
  border-top: 1px solid #efefef;
}
</style>