<template>
  <div id="content">
    <div class="container-fluid">
      <ModuleHeader moduleName="Model Details" :headerData="headerData"></ModuleHeader>
      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
              <span class="k-loading-text">Loading...</span>
              <div class="k-loading-image">
                <div class="k-loading-color"></div>
              </div>
            </div>
            <div id="accordion" v-if="componentToRender.length > 0">
              <template v-for="(subModule, index) in componentToRender">
                <component
                  :is="subModule.name"
                  v-show="showNextPanels(index)"
                  :subModuleInfo="subModule"
                  :key="subModule.id"
                  :acordianId="subModule.id.toString()"
                  @onPartnerAdded="partnerAdded"
                  @onShowHideLoader="showHideLoader($event)"
                  @onGridCancel="gridCancel"
                  :headerData="headerData"
                ></component>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
import ModuleHeader from '../../components/ModuleHeader';
import Contactinformation from './contact-list/Contactinformation';
import ContactAddress from './contact-list/ContactAddress';
import ContactFlag from './contact-list/ContactFlag';
import ContactMorePartner from './contact-list/ContactMorePartner';
import ContactNote from './contact-list/ContactNote';
import partnerService from './services/partners-service';
import { PartnersUrls, MasterUrls } from './../../shared/constants/urls';
import VALIDATION_MESSAGES from '../../shared/constants/messages';

export default {
  components: {
    ModuleHeader,
    Contactinformation,
    ContactAddress,
    ContactFlag,
    ContactMorePartner,
    ContactNote
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      componentToRender: {},
      showPanels: false,
      showLoader: false,
      statusOptions: [],
      headerData: {
        head: 'Partner Contacts',
        id: '',
        name: '',
        status: ''
      }
    };
  },
  watch: {
    $route(to, from) {
      const id = to.params.id;
      if (id) {
        const dropDownPromise = new Promise((resolve, reject) => {
          resolve(this.getDropdownData());
        });
        dropDownPromise.then(() => {
          this.getPartnersInfo(this.$route.params.id);
        });
      }
    }
  },
  methods: {
    showGrid() {
      this.$emit('showGridClicked', true);
    },
    gridCancel() {
      this.showGrid();
    },
    showNextPanels(index) {
      if (index === 0) {
        return true;
      } else if (this.showPanels) {
        return true;
      }
      return false;
    },
    partnerAdded() {
      this.showPanels = true;
      if (this.$route.params.id) {
        const dropDownPromise = new Promise((resolve, reject) => {
          resolve(this.getDropdownData());
        });
        dropDownPromise.then(() => {
          this.getPartnersInfo(this.$route.params.id);
        });
      }
    },
    showHideLoader(ev) {
      this.showLoader = ev;
    },
    getDropdownData() {
      partnerService.getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Status`).then(res => {
        const result = res.data.data;
        this.statusOptions = result.Status;
      });
    },
    getPartnersInfo(id) {
      // console.log(id);
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_INFORMATION}?partnerId=${id}`).then(res => {
        const result = res.data.data;
        const statusID = result.statusId;
        const displayStatus = this.statusOptions.filter(item => item.entityID === statusID);
        this.headerData.status = displayStatus[0].entityName;
        this.headerData.id = id;
        this.headerData.name = result.partnerName;
      });
    }
  },
  created() {
    if (this.$route.params.id) {
      const dropDownPromise = new Promise((resolve, reject) => {
        resolve(this.getDropdownData());
      });
      dropDownPromise.then(() => {
        this.getPartnersInfo(this.$route.params.id);
      });
    }

    this.componentToRender = [
      { name: 'Contactinformation', id: 1000 },
      { name: 'ContactAddress', id: 1100 },
      { name: 'ContactFlag', id: 1200 },
      { name: 'ContactMorePartner', id: 1300 },
      { name: 'ContactNote', id: 1400 }
    ];

    if (this.$store.getters.getPartnerContactId !== '') {
      this.showPanels = true;
    }
  }
};
</script>