<template>
  <div id="content">
    <div class="container-fluid" v-if="isGridMode">
      <div class="row">
        <div class="col-md-12">
          <div class="searchArea">
            <div class="row">
              <div class="col-lg-10 col-md-8">
                <h1 class="pageName">
                  {{headerData.head}} :
                  <span>{{headerData.name}}</span> &nbsp;
                  <span style="color:#000; font-size:15px;">(# {{headerData.id}})</span>
                  <span class="statusText">Status : {{headerData.status}}</span>
                </h1>
              </div>

              <div class="col-lg-2 col-md-4 secondBtn">
                <button type="button" class="btn btn-lightRed btn-block">
                  <a href="javascript:void(0)" @click="onAddNewModelClicked()">{{addButtonText}}</a>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row mb-0">
        <div class="col-md-12">
          <div class="form-group pull-right">
            <div class="checkBoxinFrom" style="margin-left:7px;">
              <div class="custom-control custom-checkbox">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="customCheck11"
                  checked="checked"
                  v-model="showAllInput"
                  @click="showAll($event)"
                />
                &nbsp;
                <label
                  class="custom-control-label"
                  for="customCheck11"
                >Show All</label>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
        <span class="k-loading-text">Loading...</span>
        <div class="k-loading-image">
          <div class="k-loading-color"></div>
        </div>
      </div>
      <ConfiguredColumnGrid
        :gridColumns="myColumns"
        :gridObjects="myData"
        @onRowClick="viewDetail"
        :sorting="sort"
      ></ConfiguredColumnGrid>
    </div>
    <PartnerContacts v-else @showGridClicked="showGrid(showLoader)" />
  </div>
</template>
<script>
import ConfiguredColumnGrid from '../../components/ConfiguredColumnGrid';
import partnerService from './services/partners-service';
import { PartnersUrls, MasterUrls } from '../../shared/constants/urls';
import PartnerContacts from './PartnerContacts';

export default {
  data() {
    return {
      isGridMode: true,
      myToolbar: ['excel', 'pdf'],
      dataItemsSource: [],
      addButtonText: 'Add New Contact',
      myData: [],
      statusOptions: [],
      headerData: {
        head: 'Partner Contacts',
        id: '',
        name: '',
        status: ''
      },
      showLoader: false,
      // here checkbox is behaving oppositely
      showAllInput: false,
      mySearchInput: '',
      // myColumns getting used as column for grid
      myColumns: [
        { field: 'partnerContactId', hidden: true },
        { field: 'designation', title: 'Designation' },
        { field: 'firstName', title: 'First Name' },
        { field: 'lastName', title: 'Last Name' },
        { field: 'email', title: 'Email Address' },
        { field: 'phone', title: 'Cell Phone' },
        { field: 'partnerDepartmentName', title: 'Department' },
        {
          field: 'isPortalUserDisplay',
          title: 'mySMARTS Access'
          // cell: this.cellIsPortalUserFunction
        },
        {
          field: 'isActiveDisplay',
          title: 'Status'
          // cell: this.cellIsActiveDisplayFunction
        }
      ],
      sort: [{ field: 'firstName', dir: 'asc' }]
    };
  },
  methods: {
    // cellIsPortalUserFunction(h, tdElement, props) {
    //   return h('td', [
    //     h(
    //       'span',
    //       {
    //         // attrs: { class: props.dataItem.isPortalUser === true ? 'status-demo status status-Active' : 'status-demo status status-Inactive' }
    //       },
    //       props.dataItem.isPortalUserDisplay
    //     )
    //   ]);
    // },
    // cellIsActiveDisplayFunction(h, tdElement, props) {
    //   return h('td', [
    //     h(
    //       'span',
    //       {
    //         // attrs: { class: props.dataItem.isActive === true ? 'status-demo status status-Active' : 'status-demo status status-Inactive' }
    //       },
    //       props.dataItem.isActiveDisplay
    //     )
    //   ]);
    // },
    /**
     * on click at the add new model button onAddNewModelClicked get called
     * and navigate user to add new model
     */
    onAddNewModelClicked() {
      this.$store.dispatch('resetEditAddStateToDefault');
      this.isGridMode = false;
    },
    /**
     * on click at the particular  model row viewDetail get called
     * and navigate user to view new model detail
     */
    viewDetail(event) {
      const id = event.dataItem.partnerContactId;
      this.$store.dispatch('setPartnerContactId', id);
      this.isGridMode = false;
    },
    showGrid() {
      this.isGridMode = true;
    },
    /**
     * on showAll checked get all model data
     * on showAll unchecked show no data for model
     */
    showAll(e) {
      this.showLoader = true;
      this.getPartnerContactDetail(e.target.checked);
      // if (e.target.checked && this.showAllInput) {
      //   // eslint-disable-next-line arrow-parens
      //   partnerService
      //     .getPartnersResult(`${PartnersUrls.GET_PARTNERS_CONTACT_LIST}?partnerId=${this.$route.params.id}&showall=true`)
      //     // eslint-disable-next-line arrow-parens
      //     .then(res => {
      //       if (res) {
      //         this.myData = res.data.data;
      //         this.showLoader = false;
      //       }
      //     });
      // } else {
      //   this.myData = this.dataItemsSource;
      //   this.showLoader = false;
      // }
    },
    getDropdownData() {
      // eslint-disable-next-line arrow-parens
      partnerService
        .getPartnersResult(`${MasterUrls.getMasterMockup}?identifier=Status`)
        // eslint-disable-next-line arrow-parens
        .then(res => {
          const result = res.data.data;
          this.statusOptions = result.Status;
        })
        // eslint-disable-next-line func-names
        .then(() => {
          if (this.$route.params.id) {
            this.getPartnersInfo();
          }
        });
    },
    /**
     * Header Information
     */
    getPartnersInfo() {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_INFORMATION}?partnerId=${this.$route.params.id}`).then(res => {
        const result = res.data.data;
        const statusID = result.statusId;
        const displayStatus = this.statusOptions.filter(item => item.entityID === statusID);
        this.headerData.status = displayStatus[0].entityName;
        this.headerData.id = this.$route.params.id;
        this.headerData.name = result.partnerName;
      });
    },
    /**
     * getPartnerContactDetail method will fetch data based on showAll Flag
     * @param parterId
     * @param showFlag
     */
    getPartnerContactDetail(showFlag) {
      // eslint-disable-next-line arrow-parens
      partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_CONTACT_LIST}?partnerId=${this.$route.params.id}&showall=${showFlag}`).then(res => {
        if (res) {
          this.myData = res.data.data;
          this.showLoader = false;
        }
      });
    }
  },
  components: {
    ConfiguredColumnGrid,
    PartnerContacts
  },
  created() {
    this.getDropdownData();
    if (this.$route.params.id) {
      this.getPartnerContactDetail(this.showAllInput);
    }
    // eslint-disable-next-line arrow-parens
    // partnerService.getPartnersResult(`${PartnersUrls.GET_PARTNERS_CONTACT_LIST}?partnerId=${this.$route.params.id}`).then(res => {
    //   if (res) {
    //     this.myData = res.data.data;
    //     this.showLoader = false;
    //   }
    // });
  }
};
</script>


<style>
/* .k-grid a {
  text-decoration: none;
} */
</style>