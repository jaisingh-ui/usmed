import CallLogGrid from '../calllogs/CallLogGrid';

export default [
  {
    path: '/call-log',
    component: CallLogGrid,
    name: 'CallLogGrid',
    meta: {
      requiresAuth: true
    }
  }
];
