<template>
    <div id="content">
        <div class="container-fluid">
            <div class="" v-if="isGridMode">
                <div class="row">
                    <div class="col-md-12">       
                    <h1 class="pageName"><i class="far fa-star mr-1 text-muted"></i> Call Log</h1>
                    </div>
                </div>
                <div class="row pt-2 light-tab-bg ml-1 mr-1">
                    <div v-if="assignCSRFlag" class="col-md-7">
                        <div class="row pt-2 light-tab-bg ml-1 mr-1">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="custom-label">Select Branch</label>
                                    <select v-model="selectedBranchId" id="inputState" class="form-control" @change="branchSelected">
                                        <option selected value="0">Select Branch</option>
                                        <option v-for="(branch, index) in brachOptions" :key="index" :value="branch.entityID">{{ branch.entityName }}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="custom-label">Select CSR</label>
                                    <select v-model="selectedCSRId" id="inputState" class="form-control">
                                        <option selected value="">Select CSR</option>
                                        <option v-for="(csr, index) in CSROptions" :key="index" :value="csr.entityID">{{ csr.entityName }}</option>
                                    </select>
                                    <p class="error-message" v-if="!$v.selectedCSRId.required && submitted">{{validationsMessages.REQUIRED}}</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="custom-label">&nbsp;</label>
                                    <!-- <button v-if="callsToAssign.length == 0" disabled @click="assignCalls()" type="button" class="btn btn-blue btn-block">Assign</button> -->
                                    <button @click="assignCalls()" type="button" class="btn btn-blue btn-block">Assign</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div v-else class="col-md-7"></div>
                    <div class="col-md-5">
                        <div class="row pt-2 light-tab-bg ml-1 mr-1">
                            <div class="col-md-12">
                                <div class="form-group pull-right mt-4 pt-3">
                                    <div class="checkBoxinFrom">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck11" @change="showAllChanged">
                                            <label class="custom-control-label ml-1" for="customCheck11">Show All</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div  class="col-md-12">
                        <div class="custom-kendo-part-grid">
                        <ConfiguredColumnGrid
                            :gridObjects="callLogData"
                            :gridColumns="callLogDataColumn"
                            @editRow="editCallLog"
                            @pageChange="handlePageChange"
                        ></ConfiguredColumnGrid>
                        </div>
                    </div>
                </div>
            </div>
             <div class="row" v-else>
                <CallLogs />
            </div>
            <div v-if="showLoader" class="k-loading-mask" style="width:100%;height:100%">
                <span class="k-loading-text">Loading...</span>
                <div class="k-loading-image">
                    <div class="k-loading-color"></div>
                </div>
            </div>
        </div>
        <div v-if="showModal" id="call-assign-warn-modal" class="modal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Warning !</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <span>PO is required for following Call Logs</span>
                        <table style="width: 100%">
                            <tr>
                                <th>Call Log #</th>
                                <th>Partner Name</th>
                            </tr>
                            <tr v-for="(warn, index) in warnCallData" :key="index">
                                <td>{{ warn.callLogId }}</td>
                                <td>{{ warn.partnerName }}</td>
                            </tr>
                        </table>
                        <br />
                        <h6>Do you still want to assign calls to the CSR ?</h6>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" @click="assignCalls(true)">Assign</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal" @click="hideAssignModal()">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<style>
    .k-grid-header-wrap tr,
    .k-grid-header-wrap tr th {
        border-width: 0 !important;
    }

    .k-grid-container .k-grid-content tr td {
        border-width: 0 !important;
    }

    .k-grid-container .k-grid-content tr td.color-red {
        color: #f31700;
        font-weight: 600;
    }

    .k-grid-container .k-grid-content tr div.options-container {
        text-align: center;
        padding: 8px;
    }

    .custom-control.custom-checkbox.grid-checkbox {
        text-align: center;
        padding: 8px;
        display: flex;
        justify-content: center;
    }

    .dropdown-menu {
        position: absolute;
        top: 0px;
        right: 28px !important;
        left: unset !important;
        transform: unset !important;
        will-change: transform;
    }
</style>
<script>
/* eslint-disable */
import Vue from 'vue';
import CallLogs from '../calllogs/CallLogs';
import ConfiguredColumnGrid from '../../components/ConfiguredColumnGrid';
import { CalllogUrls, MasterUrls } from '../../shared/constants/urls';
import { required, helpers } from 'vuelidate/lib/validators';
import VALIDATION_MESSAGES from '../../shared/constants/messages';
import CallLogService from "./services/CallLogServices";
import { CustomGridComponents } from "./elements/CustomGridComponents";
import { Modal } from "../../../node_modules/bootstrap/"

export default {
    name: 'CallLogGrid',
    components: {
        ConfiguredColumnGrid,
        CallLogs
    },
    data(){
        return {
            validationsMessages: VALIDATION_MESSAGES,
            showLoader: false,
            showModal: false,
            apiCallInterval: null,
            isGridMode: true,
            selectedBranchId: 0,
            selectedCSRId: '',
            callsToAssign: [],
            submitted: false,
            showAllFlag: false,
            brachOptions: [],
            CSROptions: [],
            callLogData: [],
            assignCSRFlag: false,
            modalInstance: null,
            userRoles: ["Branch Manager", "Dispatch Team"],
            user: {
                id: 1,
                branchId: 1,
                role: "Branch Manager"
            },
            callLogDataColumn: [
                { cell: CustomGridComponents.selectCall, field: '', editable: false, title: 'Select', hidden: false, filterable: false, filterCell: null },  // checkBoxAllCell
                { field: 'branchName', width: '200px', editable: false, title: 'Branch' },
                { field: 'callLogID', editable: false, title: 'Call Log #', filter: 'text' },
                { field: 'partnerName', editable: false, title: 'Partner Name' },
                { field: 'callDateTime', cell: CustomGridComponents.textColor, editable: false, title: 'Call Date Time', filter: 'text' },
                { field: 'schedule', editable: false, title: 'Delivery/Pickup Schedule' },
                { field: 'callee', title: 'Calee' },
                { field: 'caller', title: 'Caller' },
                { field: 'callType', title: 'Call Type' },
                { field: 'callStatus', title: 'Status', cell: CustomGridComponents.callStatus },
                { field: 'openSince', title: 'Open Since' },
                { field: 'csr', title: 'CSR' },
                { field: '', filter: false, title: '', cell: CustomGridComponents.optionsDropdown } 
            ] 
        }
    },
    validations: {
        
        selectedBranchId: { required },
        selectedCSRId: { required },
        // floor: { alphaNumSpaceValidation },
        // suite: { alphaNumSpaceValidation }
    },
    created() {
        // this.$on('CallsSelected', (data) => {
        //     console.log(data);
        // });
    },
    mounted() {
        if(this.isGridMode) {
            this.showLoader = true;
            if(this.user.role == this.userRoles[0]) {
                this.selectedBranchId = this.user.branchId;
                this.assignCSRFlag = true;
            }
            else {
                // branch id be 0
            }
            this.getDropdownData("Branch");
            this.getDropdownData("CSR");
            this.getCallLogsList();
        }
    },
    beforeDestroy() {
        clearInterval(this.apiCallInterval);
        this.apiCallInterval = null;
    },
    methods: {
        branchSelected(ev) {
            // console.log(ev);
            this.selectedCSRId = '';
            this.getDropdownData("CSR");
            this.getCallLogsList();
        },
        getDropdownData(type) {
            let url = `${MasterUrls.getMasterMockup}`;
            if(type == "Branch") {
                url += `?identifier=Branch`;
            }
            else {
                url += `?identifier=CSR&id=${this.selectedBranchId}`;
            }
            CallLogService.getCallLogResult(url).then(res => {
                // console.log(res, res.data, '=====================');
                const result = res.data.data;
                if(type == "Branch")
                    this.brachOptions = result.Branch;
                else
                    this.CSROptions = result.CSR;
            });
        },
        handlePageChange(ev) {
            document.getElementById("selectAllCheck").setAttribute("checked", false);
            // document.getElementById("selectAllCheck").removeAttribute("checked");
        },
        showAllChanged(ev) {
            // console.log(ev.target.checked);
            this.showLoader = true;
            this.showAllFlag = ev.target.checked;
            this.getCallLogsList();
        },
        getCallLogsList() {
            CallLogService.getCallLogResult(`${CalllogUrls.GET_CALL_LOG}?userId=1&branchId=${this.selectedBranchId}&isShowAll=${this.showAllFlag}`).then(res => {
                const result = res.data.data;
                if (result) {
                    this.callLogData = result;
                    this.$store.dispatch('setSelectedCallsToAssign', []);
                    const intervalTime = 150;      // In Seconds from API;
                    if(this.apiCallInterval == null)
                        this.setApiCallInterval(intervalTime);
                }
                this.showLoader = false;
            });
        },
        assignCalls(warningKey=false) {
            this.callsToAssign = this.$store.getters.getSelectedCallsToAssign;
            this.submitted = true;
            this.showModal = false; 
            this.$v.$touch();
            if (this.$v.$invalid) {
                return;
            }
            const data = {
                "callLogsId": this.callsToAssign,
                "csrId": this.selectedCSRId,
                "isWarningOverride": warningKey,
                "userId": this.user.id
            }
            CallLogService.postCallLogData(`${CalllogUrls.ASSIGN_CALL}`, data).then(res => {
                // console.log(res);
                const result = res.data.data;
                if (result) {
                    if(result.length > 0) {
                        this.warnCallData = result;
                        this.showModal = true;
                        this.modalInstance = null;
                        setTimeout(() => {
                            var myModal = document.getElementById('call-assign-warn-modal');
                            this.modalInstance = new Modal(myModal, {
                                backdrop: 'static',
                                keyboard: false
                            });
                            this.modalInstance.show();
                        }, 100);
                    }
                    else {
                        if(warningKey) {
                            this.modalInstance.hide();
                            this.showModal = false;
                        }
                        this.showLoader = true;
                        this.callLogData = [];
                        // this.$store.dispatch('setSelectedCallsToAssign', []);
                        this.getCallLogsList();
                    }
                    this.submitted = false;
                }
            });
        },
        hideAssignModal() {
            this.modalInstance.hide();
        },
        setApiCallInterval(time) {
            this.apiCallInterval = setInterval(() => {
                this.showLoader = true;
                this.getCallLogsList();
            }, time*1000);
        },
        editCallLog(ev) {
            // console.log("edit call", ev);
            const id = ev.dataItem.partnerID;
            const MID = ev.dataItem.modelId;
            // this.$router.push(`/call-log/${id}/${MID}`);
            this.isGridMode = false;
        }
    }
}
</script>