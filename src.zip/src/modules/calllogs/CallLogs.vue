<template>
  <div id="content">
    <div class="container-fluid">
      <RightPanel />
      <AlertMessages />
      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <Callinformation />
            <RequestCart />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import AlertMessages from '../calllogs/elements/AlertMessages';
import Callinformation from '../calllogs/elements/Callinformation';
import RequestCart from '../calllogs/elements/RequestCart';
import RightPanel from '../calllogs/elements/RightPanel';

export default {
  name: 'CallLogs',
  components: {
    RightPanel,
    AlertMessages,
    Callinformation,
    RequestCart
  }
};
</script>