/* eslint-disable indent */
import axiosMethods from '../../../shared/services/base-service';


const CallLogService = {
    getCallLogResult(url, body) {
        return axiosMethods.getRequest(url, body).then(res => res);
    },
    postCallLogData(url, body) {
        return axiosMethods.postRequest(url, body).then(res => res);
    }
};


export default CallLogService;
