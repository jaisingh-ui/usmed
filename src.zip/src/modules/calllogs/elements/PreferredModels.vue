<template>
  <div>
    <table class="table data-table">
      <thead>
        <tr>
          <th scope="col">Model Common Name</th>
          <th scope="col">Model Accessories</th>
          <th scope="col">Model Options</th>
          <th scope="col">Software Version</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="preferred in preferredModels" :key="preferred.modelId">
          <td>{{preferred.modelCommonName}}</td>
          <td>{{preferred.modelAccessories}}</td>
          <td>{{preferred.modelOptions}}</td>
          <td>{{preferred.softwareVersion}}</td>
          <td class="text-right">
            <span class="FormworkingBtn" @click="AddToCart(preferred)">
              <a href="javascript:void(0)">
                <i class="fa fa-cart-plus" aria-hidden="true"></i> Add to
                cart
              </a>
            </span>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
/* eslint-disable */
import CallLogService from '../services/CallLogServices';
import { CalllogUrls, MasterUrls } from '../../../shared/constants/urls';

export default {
  name: 'PreferredModels',
  data() {
    return {
      userId: 1,
      partnerId: this.$route.params.id,
      curentCartData: this.$store.getters.getDeliveryCart,
      preferredModels: [],
      softwareVersionArray: []
    };
  },
  methods: {
    AddToCart(preferredModelObject) {
      //console.log(this.curentCartData);
      // Check if model Already present in store object
      // let alreadyExists = this.curentCartData.findIndex(obj => obj.modelId === preferredModelObject.modelId);
      //console.log(alreadyExists);
      // if (alreadyExists !== -1) {
      //   // update base array and update using setter
      //   this.curentCartData[alreadyExists].quantity += 1;
      //   this.curentCartData[alreadyExists].quantity += 1;
      //   let storeValuesOfCart = this.curentCartData;
      //   this.$store.dispatch('resetEditCallLogStateToDefault');
      //   console.log(storeValuesOfCart);
      //   //this.$store.dispatch('setDeliveryCart', storeValuesOfCart);
      //   //than update old array with count and modelID
      // } else {
      // send model/software version data in this object

      const preferredModelObjectData = preferredModelObject;
      // eslint-disable-next-line no-new
      new Promise(resolve => {
        setTimeout(resolve => {
          this.getModelDropdown(preferredModelObjectData.modelId);
          this.getSoftwareVersionnsDropdown(preferredModelObjectData.modelId);

          preferredModelObjectData.activeStatus = true;
          preferredModelObjectData.quantity = 1;
          //console.log(typeof this.softwareVersionArray);
          preferredModelObjectData.softwareVersionArray = this.softwareVersionArray;
          this.$store.dispatch('setDeliveryCart', preferredModelObjectData);
        }, 500);
      });
      //}
    },
    CallGetAPI() {
      // eslint-disable-next-line arrow-parens
      CallLogService.getCallLogResult(`${CalllogUrls.GET_PREFERRED_MODEL}?partnerId=${this.partnerId}`).then(res => {
        const result = res.data.data;
        if (result) {
          this.preferredModels = result;
        }
      });
    },
    getModelDropdown(modelId) {
      // eslint-disable-next-line arrow-parens
      CallLogService.getCallLogResult(`${MasterUrls.getMasterMockup}?identifier=PreferredModelOptions&id=${this.$route.params.id}&id2=${modelId}`).then(
        // eslint-disable-next-line arrow-parens
        response => {
          // eslint-disable-next-line no-console
          console.log(response);
          // if (response.data) {
          //   this.branchList = response.data.data.Branch;
          // }
        }
      );
    },
    getSoftwareVersionnsDropdown(modelId) {
      CallLogService.getCallLogResult(`${MasterUrls.getMasterMockup}?identifier=SoftwareVersion&id=${modelId}`).then(
        // eslint-disable-next-line arrow-parens
        response => {
          if ('data' in response.data) {
            this.softwareVersionArray = response.data.data.SoftwareVersion;
          } else {
            this.softwareVersionArray = [];
          }
        }
      );
    }
  },
  async created() {
    if (this.$route.params.id) {
      await this.CallGetAPI();
    }
    // this.getSoftwareVersionnsDropdown(244);
  }
};
</script>