<template>
  <div class="card">
    <div class="card-header" id="headingFour">
      <h5 class="mb-0">
        <button class="btn btn-link">Request Cart</button>
      </h5>
    </div>
    <div id="collapseFour">
      <div class="card-body">
        <div class="row">
          <div class="col-md-12 text-right pt-1 pb-1">
            <span class="FormworkingBtn" @click="emptyCart()">
              <a href="javascript:void(0)">
                <i class="fa fa-shopping-cart" aria-hidden="true"></i> EMPTY CART
              </a>
            </span>
          </div>
        </div>

        <div class="common-tab">
          <div class="row">
            <div class="col-lg-4">
              <div class="form-group">
                <label>Expected Delivery Date and Time</label>
                <div class="row">
                  <div class="col">
                    <div class="input-group">
                      <kendo-datepicker :date-input="true" :format="'MM/dd/yyyy'" ref="picker"></kendo-datepicker>
                    </div>
                  </div>
                  <div class="col">
                    <div class="input-group">
                      <kendo-timepicker></kendo-timepicker>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-1 mt-4 pt-2 text-center">OR</div>
            <div class="col-lg-3">
              <div class="form-group">
                <label>ASAP Delivery</label>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <div class="input-group-text">
                      <input type="checkbox" aria-label="Checkbox for following text input" />
                    </div>
                  </div>
                  <select class="form-control" id="exampleFormControlSelect1">
                    <option>Select Time</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-lg-2">
              <label>PO #</label>
              <div class="form-group">
                <input type="text" class="form-control" />
              </div>
            </div>
            <div class="col-lg-2">
              <label>Fullfill Branch</label>
              <div class="form-group">
                <select
                  id="inputState"
                  class="form-control"
                  v-model="selectedBranch"
                  :disabled="true"
                >
                  <option value>Select</option>
                  <option
                    v-for="branch in branchList"
                    :key="branch.entityID"
                    :value="branch.entityID"
                  >{{branch.entityName}}</option>
                </select>
              </div>
            </div>
          </div>

          <ul class="nav nav-tabs pl-0 slide-tab" id="callTab" role="tablist">
            <li class="nav-item">
              <a
                class="nav-link active"
                id="delivery-tab"
                data-toggle="tab"
                href="#delivery"
                role="tab"
                aria-controls="delivery"
                aria-selected="true"
              >Delivery</a>
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                id="pickup-tab"
                data-toggle="tab"
                href="#pickup"
                role="tab"
                aria-controls="pickup"
                aria-selected="false"
              >Pickup</a>
            </li>
          </ul>

          <div class="tab-content" id="callTabContent">
            <div
              class="tab-pane fade pl-0 pr-0 pt-3 pb-3 active show"
              id="delivery"
              role="tabpanel"
              aria-labelledby="delivery-tab"
            >
              <RequestSection />
            </div>

            <div
              class="tab-pane fade pl-0 pr-0 pt-3 pb-3"
              id="pickup"
              role="tabpanel"
              aria-labelledby="pickup-tab"
            >
              <PickupSection />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { EventBus } from '../../../EventBus/event-bus';
import RequestSection from './RequestSection';
import PickupSection from './PickupSection';
import { MasterUrls } from '../../../shared/constants/urls';
import CallLogService from '../services/CallLogServices';

export default {
  name: 'RequestCart',
  components: {
    RequestSection,
    PickupSection
  },
  data() {
    return {
      branchList: [],
      selectedBranch: 1
    };
  },
  methods: {
    emptyCart() {
      EventBus.$emit('clear-cart', true);
    },
    getDropDownoptions() {
      // eslint-disable-next-line arrow-parens
      CallLogService.getCallLogResult(`${MasterUrls.getMasterMockup}?identifier=Branch`).then(response => {
        if (response.data) {
          this.branchList = response.data.data.Branch;
        }
      });
    }
  },
  created() {
    this.getDropDownoptions();
  }
};
</script>