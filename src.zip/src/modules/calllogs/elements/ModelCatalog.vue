<template>
  <div>
    <div class="input-group mb-3">
      <input
        type="text"
        class="form-control"
        placeholder="Search"
        v-model.trim="searchInput"
        @keyup.enter="onSearchMethod()"
      />
      <div class="input-group-append">
        <template v-if="!showCrossItem">
          <span class="input-group-text" @click="onSearchMethod()">
            <i class="fa fa-search" aria-hidden="true"></i>
          </span>
        </template>
        <template v-else>
          <span class="input-group-text" @click="getModelData()">
            <i class="fa fa-times" aria-hidden="true"></i>
          </span>
        </template>
      </div>
    </div>
    <div class="fullPagetable">
      <div class="row softwareTable">
        <ConfiguredColumnGrid
          :gridObjects="modelCatalogData"
          :gridColumns="modelCatalogColumn"
          :sorting="sort"
        ></ConfiguredColumnGrid>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import Vue from 'vue';
import modelService from '../../modelcatalog/services/model-service';
import { ModelUrls } from '../../../shared/constants/urls';
import ConfiguredColumnGrid from '../../../components/ConfiguredColumnGrid';
import CallLogService from '../services/CallLogServices';
import { CalllogUrls, MasterUrls } from '../../../shared/constants/urls';

const statusCell = Vue.component('template-status', {
  props: ['dataItem'],
  template: `<td>
                 <span class="FormworkingBtn">
                  <a href="javascript:void(0)" @click="AddToCart(dataItem)">
                    <i class="fa fa-cart-plus" aria-hidden="true"></i>
                    Add to cart
                  </a>
                 </span>
            </td>`,
  methods: {
    AddToCart(dataItem) {
      console.log(dataItem);
      // console.log(this.curentCartData);
      // Check if model Already present in store object
      // let alreadyExists = this.curentCartData.findIndex(obj => obj.modelId === preferredModelObject.modelId);
      // console.log(alreadyExists);
      // if (alreadyExists !== -1) {
      //   // update base array and update using setter
      //   this.curentCartData[alreadyExists].quantity += 1;
      //   this.curentCartData[alreadyExists].quantity += 1;
      //   let storeValuesOfCart = this.curentCartData;
      //   this.$store.dispatch('resetEditCallLogStateToDefault');
      //   console.log(storeValuesOfCart);
      //   //this.$store.dispatch('setDeliveryCart', storeValuesOfCart);
      //   //than update old array with count and modelID
      // } else {
      // send model/software version data in this object

      const preferredModelObjectData = dataItem;
      new Promise(resolve => {
        setTimeout(resolve => {
          this.getModelDropdown(preferredModelObjectData.modelId);
          this.getSoftwareVersionnsDropdown(preferredModelObjectData.modelId);

          preferredModelObjectData.activeStatus = true;
          preferredModelObjectData.quantity = 1;
          // console.log(typeof this.softwareVersionArray);
          preferredModelObjectData.softwareVersionArray = this.softwareVersionArray;
          this.$store.dispatch('setDeliveryCart', preferredModelObjectData);
        }, 500);
      });
      // }
    },
    getModelDropdown(modelId) {
      // eslint-disable-next-line arrow-parens
      CallLogService.getCallLogResult(`${MasterUrls.getMasterMockup}?identifier=PreferredModelOptions&id=${this.$route.params.id}&id2=${modelId}`).then(
        // eslint-disable-next-line arrow-parens
        response => {
          // eslint-disable-next-line no-console
          console.log(response);
          // if (response.data) {
          //   this.branchList = response.data.data.Branch;
          // }
        }
      );
    },
    getSoftwareVersionnsDropdown(modelId) {
      CallLogService.getCallLogResult(`${MasterUrls.getMasterMockup}?identifier=SoftwareVersion&id=${modelId}`).then(
        // eslint-disable-next-line arrow-parens
        response => {
          if ('data' in response.data) {
            this.softwareVersionArray = response.data.data.SoftwareVersion;
          } else {
            this.softwareVersionArray = [];
          }
        }
      );
    }
  }
});

export default {
  name: 'ModelCatalog',
  components: {
    ConfiguredColumnGrid
  },
  data() {
    return {
      searchInput: '',
      showCrossItem: false,
      modelCatalogData: [],
      modelCatalogColumn: [
        { field: 'modelId', editable: false, title: 'ID', hidden: true, filterable: false },
        { field: 'modelCommonName', editable: false, title: 'Model Common Name' },
        { field: 'modelCategoryName', editable: false, title: 'Category' },
        { cell: statusCell }
      ],
      sort: [{ field: 'modelCommonName', dir: 'asc' }]
    };
  },
  methods: {
    /**
     * Get Model Data For Grid
     */
    getModelData() {
      this.searchInput = '';
      this.showCrossItem = false;
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.modelListShowAll}`).then(res => {
        const result = res.data.data;
        if (result) {
          this.modelCatalogData = result;
          this.showLoader = false;
        }
      });
    },
    /**
     * Search Key Press
     */
    onSearchMethod() {
      this.showLoader = true;
      this.showCrossItem = true;
      const searchValue = this.searchInput.trim();
      if (searchValue) {
        // eslint-disable-next-line arrow-parens
        modelService.getModelRequest(`${ModelUrls.modelListSearch}?searchedItem=${searchValue}`).then(res => {
          const result = res.data.data;
          if (result) {
            this.modelCatalogData = result;
            this.showLoader = false;
          }
        });
      }
    }
  },
  created() {
    this.getModelData();
  }
};
</script>