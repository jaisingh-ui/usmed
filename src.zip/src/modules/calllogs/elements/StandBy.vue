<template>
  <div>
    <div class="row">
      <div class="col-md-7">
        <table class="table data-table">
          <thead>
            <tr>
              <th scope="col" class="text-nowrap">Barcode #</th>
              <th scope="col" class="text-nowrap">Model Common Name</th>
              <th scope="col" class="text-nowrap">Category</th>
              <th scope="col" class="text-nowrap">Out of Box Failure</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>58692</td>
              <td class="idRef text-nowrap">Philips v60 Bipap</td>
              <td class="text-nowrap">Equipment</td>
              <td>
                <div class="checkBoxinFrom">
                  <div class="custom-control custom-checkbox">
                    <input
                      type="checkbox"
                      class="custom-control-input"
                      id="customCheck48"
                      checked="checked"
                    />
                    &nbsp;
                    <label class="custom-control-label">&nbsp;</label>
                  </div>
                </div>
              </td>
              <td>
                <span class="FormworkingBtn">
                  <a href="javascript:void(0)">
                    <i class="fa fa-cart-plus" aria-hidden="true"></i>
                    Add to cart
                  </a>
                </span>
              </td>
            </tr>
            <tr>
              <td>632541</td>
              <td class="idRef text-nowrap">Philips Heartstart XL</td>
              <td class="text-nowrap">Equipment</td>
              <td>
                <div class="checkBoxinFrom">
                  <div class="custom-control custom-checkbox">
                    <input
                      type="checkbox"
                      class="custom-control-input"
                      id="customCheck48"
                      checked="checked"
                    />
                    &nbsp;
                    <label class="custom-control-label">&nbsp;</label>
                  </div>
                </div>
              </td>
              <td>
                <span class="FormworkingBtn">
                  <a href="javascript:void(0)">
                    <i class="fa fa-cart-plus" aria-hidden="true"></i>
                    Add to cart
                  </a>
                </span>
              </td>
            </tr>
            <tr>
              <td>58692</td>
              <td class="idRef text-nowrap">Medex Medfusion 3500</td>
              <td class="text-nowrap">Equipment</td>
              <td>
                <div class="checkBoxinFrom">
                  <div class="custom-control custom-checkbox">
                    <input
                      type="checkbox"
                      class="custom-control-input"
                      id="customCheck48"
                      checked="checked"
                    />
                    &nbsp;
                    <label class="custom-control-label">&nbsp;</label>
                  </div>
                </div>
              </td>
              <td>
                <span class="FormworkingBtn">
                  <a href="javascript:void(0)">
                    <i class="fa fa-cart-plus" aria-hidden="true"></i>
                    Add to cart
                  </a>
                </span>
              </td>
            </tr>
            <tr>
              <td>458692</td>
              <td class="idRef text-nowrap">Philips v60 Bipap</td>
              <td class="text-nowrap">Equipment</td>
              <td>
                <div class="checkBoxinFrom">
                  <div class="custom-control custom-checkbox">
                    <input
                      type="checkbox"
                      class="custom-control-input"
                      id="customCheck48"
                      checked="checked"
                    />
                    &nbsp;
                    <label class="custom-control-label">&nbsp;</label>
                  </div>
                </div>
              </td>
              <td>
                <span class="FormworkingBtn">
                  <a href="javascript:void(0)">
                    <i class="fa fa-cart-plus" aria-hidden="true"></i>
                    Add to cart
                  </a>
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="col-md-5">
        <table class="table data-table stand-by-tab">
          <thead>
            <tr>
              <th scope="col" class="text-nowrap">Start/Stop Rental</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <div class="row">
                  <div class="col-md-5">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="01/21/2020" />
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-calendar" aria-hidden="true"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-5">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="04:00 PM" />
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-clock-o" aria-hidden="true"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <span class="FormworkingBtn rounded-circle mt-2">
                      <a href="javascript:void(0)">
                        <i class="fa fa-pause" aria-hidden="true"></i>
                      </a>
                    </span>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <div class="row">
                  <div class="col-md-5">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="05/21/2020" />
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-calendar" aria-hidden="true"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-5">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="03:35 PM" />
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-clock-o" aria-hidden="true"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <span class="FormworkingBtn rounded-circle mt-2">
                      <a href="javascript:void(0)">
                        <i class="fa fa-play" aria-hidden="true"></i>
                      </a>
                    </span>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <div class="row">
                  <div class="col-md-5">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="01/21/2020" />
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-calendar" aria-hidden="true"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-5">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="04:00 PM" />
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-clock-o" aria-hidden="true"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <span class="FormworkingBtn rounded-circle mt-2">
                      <a href="javascript:void(0)">
                        <i class="fa fa-pause" aria-hidden="true"></i>
                      </a>
                    </span>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <div class="row">
                  <div class="col-md-5">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="01/21/2020" />
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-calendar" aria-hidden="true"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-5">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="04:00 PM" />
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-clock-o" aria-hidden="true"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <span class="FormworkingBtn rounded-circle mt-2">
                      <a href="javascript:void(0)">
                        <i class="fa fa-pause" aria-hidden="true"></i>
                      </a>
                    </span>
                  </div>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'StandBy'
};
</script>