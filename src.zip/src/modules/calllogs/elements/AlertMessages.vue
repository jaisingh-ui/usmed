<template>
  <div>
    <div class="row">
      <div class="col-md-12">
        <div class="searchArea">
          <div class="row">
            <div class="col-lg-9 col-md-9">
              <h1 class="pageName">
                Call Log :
                <span>{{headerData.partnerName}}</span>
              </h1>
            </div>
            <div class="col-lg-3 col-md-3 text-right">
              <span class="save-btn">
                <a href="javascript:void(0)">Save</a>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12">
        <div
          class="alert alert-warning custom-warning"
          v-if="partnerAlerts.length > 0 && partnerAlerts[0] !== null"
          role="alert"
        >
          <span v-for="(alert, index) in partnerAlerts" :key="index" class="mr-4">
            <i class="fa fa-exclamation-circle custom-warning-icon" aria-hidden="true"></i>
            <span class>{{ alert }}</span>
            <br v-if="alert.length > 50" />
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { CalllogUrls } from '../../../shared/constants/urls';
import CallLogService from '../services/CallLogServices';

export default {
  name: 'AlertMessages',
  props: {
    messages: {
      type: Array
    }
  },
  data() {
    return {
      headerData: [],
      partnerAlerts: []
    };
  },
  mounted() {
    this.partnerId = this.$route.params.id;
    this.getCallMetaData();
  },
  methods: {
    getCallMetaData() {
      // eslint-disable-next-line arrow-parens
      CallLogService.getCallLogResult(`${CalllogUrls.GET_CALL_METADATA}?partnerId=${this.partnerId}`).then(res => {
        const result = res.data.data;
        if (result) {
          this.headerData = result;
          this.partnerAlerts = result.partnerAlerts;
        }
      });
    }
  }
};
</script>