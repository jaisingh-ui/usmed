<template>
  <div>
    <table class="table data-table">
      <thead>
        <tr>
          <th scope="col">Model Common Name</th>
          <th scope="col">Category</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="idRef text-nowrap">Philips v60 Bipap</td>
          <td class="text-nowrap">Equipment</td>
          <td class="text-right">
            <span class="FormworkingBtn">
              <a href="javascript:void(0)">
                <i class="fa fa-cart-plus" aria-hidden="true"></i> Add to
                cart
              </a>
            </span>
          </td>
        </tr>
        <tr>
          <td class="idRef text-nowrap">GE Giraffe Omnibed Incubaltor</td>
          <td class="text-nowrap">Equipment</td>
          <td class="text-right">
            <span class="FormworkingBtn">
              <a href="javascript:void(0)">
                <i class="fa fa-cart-plus" aria-hidden="true"></i> Add to
                cart
              </a>
            </span>
          </td>
        </tr>
        <tr>
          <td class="idRef text-nowrap">Philips Heartstart XL</td>
          <td class="text-nowrap">Equipment</td>
          <td class="text-right">
            <span class="FormworkingBtn">
              <a href="javascript:void(0)">
                <i class="fa fa-cart-plus" aria-hidden="true"></i> Add to
                cart
              </a>
            </span>
          </td>
        </tr>
        <tr>
          <td class="idRef text-nowrap">Philips v60 Bipap</td>
          <td class="text-nowrap">Equipment</td>
          <td class="text-right">
            <span class="FormworkingBtn">
              <a href="javascript:void(0)">
                <i class="fa fa-cart-plus" aria-hidden="true"></i> Add to
                cart
              </a>
            </span>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: 'RentalHistory'
};
</script>