<template>
  <div>
    <table class="table data-table">
      <thead>
        <tr>
          <th scope="col">Barcode #</th>
          <th scope="col">Model Common Name</th>
          <th scope="col">Category</th>
          <th scope="col">PM Status</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>565232</td>
          <td>Philips v60 Bipap</td>
          <td>Equipment</td>
          <td>Due on 6/51/2020</td>
          <td class="text-right">
            <span class="FormworkingBtn">
              <a href="javascript:void(0)">
                <i class="fa fa-cart-plus" aria-hidden="true"></i> Add to
                cart
              </a>
            </span>
          </td>
        </tr>
        <tr>
          <td>748596</td>
          <td>Philips Heartstart XL</td>
          <td>Equipment</td>
          <td>Due in 7 days</td>
          <td class="text-right">
            <span class="FormworkingBtn">
              <a href="javascript:void(0)">
                <i class="fa fa-cart-plus" aria-hidden="true"></i> Add to
                cart
              </a>
            </span>
          </td>
        </tr>
        <tr>
          <td>562341</td>
          <td>Medex Medfusion 3500</td>
          <td>Equipment</td>
          <td>Due on 6/51/2020</td>
          <td class="text-right">
            <span class="FormworkingBtn">
              <a href="javascript:void(0)">
                <i class="fa fa-cart-plus" aria-hidden="true"></i> Add to
                cart
              </a>
            </span>
          </td>
        </tr>
        <tr>
          <td>565232</td>
          <td>Philips v60 Bipap</td>
          <td>Equipment</td>
          <td>Due on 6/51/2020</td>
          <td class="text-right">
            <span class="FormworkingBtn">
              <a href="javascript:void(0)">
                <i class="fa fa-cart-plus" aria-hidden="true"></i> Add to
                cart
              </a>
            </span>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: 'PMDue'
};
</script>