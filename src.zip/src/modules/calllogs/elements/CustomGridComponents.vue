<script>
    /* eslint-disable */
    import Vue from 'vue';
    let selectedCallIds = [];
    const optionsCell = Vue.component('template-options', {
        props: ['dataItem'],
        data: function() {
            return {
                title: "Options",
                type: 'complete',
                showNotes: false
            }
        },
        template: `<div class="options-container"><div class="btn-group dropleft">                                                            
                <a href="Javascript:void(0);" @click="showNotes = false" title="Take Call" class="border rounded-circle create-new-call-btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                </a>
                <div v-if="!showNotes" class="dropdown-menu create-new-call-dropdown">
                    <a href="javascript:void(0);" @click="dropdownOptionClick($event, 'cancel')">
                        Cancel
                    </a>                                                                              
                    <a href="javascript:void(0);" @click="dropdownOptionClick($event, 'complete')">
                        Complete
                    </a>                                                                           
                </div>
                <div v-else class="dropdown-menu create-new-call-dropdown">
                    <template-notes :dataItem="dataItem" :type="type"></template-notes>
                </div>
            </div></div>`,
        methods: {
            dropdownOptionClick(ev, type) {
                ev.stopPropagation();
                // console.log(">>>", ev, type);
                this.showNotes = true;
                this.type = type;
            },

            dropdownHidden(ev) {
                // console.log("Hide >");
            }
        }
    });

    const notesComponent = Vue.component('template-notes', {
        props: ['dataItem', 'type'],
        data: function() {
            return {
                title: "Notes"
            }
        },
        template: `<div class="cancel-call-wrapper">
                    <div class="BorderBottom">
                        <h4>{{ dataItem.partnerName }}
                            <span>(Call Log #{{ dataItem.callLogID }})</span>
                        </h4>
                    </div>
                    <div class="pt-2 pr-3 pb-3 pl-3">
                        <div class="form-group">
                            <label v-if="type == 'complete'" for="exampleInputEmail1" class="custom-label">Complete Note</label>
                            <label v-else for="exampleInputEmail1" class="custom-label">Cancel Note</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn save-btn mr-2">Save</button>
                        <button type="submit" class="btn cancel-btn">cancel</button>
                    </div>
                </div>`,
        methods: {
        }
    });


    const statusCell = Vue.component('template-status', {
        props: ['dataItem'],
        data: function() {
            return {
                title: "Status"
            }
        },
        template: `<td>
                    <span v-if="dataItem.callStatus == 'Active'" class="status-demo status status-Active">{{ dataItem.callStatus }}</span>
                    <span v-else class="status-demo status status-Inactive">{{ dataItem.callStatus }}</span>
                </td>`,
        methods: {
            change(e) {
                // console.log(e);
            }
        }
    });

    const customColorCell = Vue.component('template-color-cell', {
        props: ['dataItem'],
        template: `<td colspan="1" class="color-red" v-if="dataItem.isDateDisplayInRed" selectionchange="function () { [native code] }" dataindex="1">{{ dataItem.callDateTime }}</td>
                <td v-else colspan="1" selectionchange="function () { [native code] }" dataindex="1">{{ dataItem.callDateTime }}</td>`,
        methods: {
        }
    });

    const checkBoxCell = Vue.component('template-check', {
        props: ['dataItem'],
        template: `<div class="custom-control custom-checkbox grid-checkbox"><input type="checkbox" class="custom-control-input" :id='"selectAllCheck_"+ dataItem.callLogID' @change="change" />
                <label class="custom-control-label ml-1 js_check-box" :for="'selectAllCheck_'+ dataItem.callLogID"></label></div>`,
        methods: {
            change(e) {
                // console.log(e, this.dataItem);
                // this.$emit('CallsSelected', (e, this.dataItem));
                selectedCallIds = this.$store.getters.getSelectedCallsToAssign;
                if(e.target.checked)
                    selectedCallIds.push(this.dataItem.callLogID);
                else {
                    let i = selectedCallIds.indexOf(this.dataItem.callLogID);
                    if(i !== -1)
                        selectedCallIds.splice(i, 1);
                }
                this.$store.dispatch('setSelectedCallsToAssign', selectedCallIds);
                // console.log(selectedCallIds);
            }
        }
    });

    const checkBoxAllCell = Vue.component('template-check-all', {
        props: ['dataItem'],
        template: `<div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" :id='"selectAllCheck"' @change="change" />
                <label class="custom-control-label ml-1" :for="'selectAllCheck'"></label></div>`,
        methods: {
            change(e) {
                // console.log(document.getElementsByClassName("js_check-box"), e.target.checked);
                const els = document.getElementsByClassName("js_check-box");
                const isChecked = e.target.checked;
                Array.from(els).forEach((el) => {
                    // console.log(el);
                    if(isChecked)
                        el.click();
                        // el.setAttribute("checked", e.target.checked);
                    else {
                        el.click();
                        // el.setAttribute("checked", false);
                        // el.removeAttribute("checked");
                    }
                });
            }
        }
    });

    export const CustomGridComponents = {
        optionsDropdown: optionsCell,
        callLogNotes: notesComponent,
        callStatus: statusCell,
        textColor: customColorCell,
        selectCall: checkBoxCell,
        selectAllCalls: checkBoxAllCell
    };
</script>