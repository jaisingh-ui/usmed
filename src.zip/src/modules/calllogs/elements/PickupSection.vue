<template>
  <div>
    <table class="table data-table">
      <thead>
        <tr>
          <th scope="col">Barcode #</th>
          <th scope="col">Model Common Name</th>
          <th scope="col">Out of Box Failure</th>
          <th scope="col">PM Due</th>
          <th scope="col">Department</th>
          <th scope="col">Quantity</th>
          <!-- <th scope="col">Fullfillment Location</th> -->
          <th scope="col">Billing End Date</th>
          <th scope="col"></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>57655757</td>
          <td>Care Fusion 211</td>
          <td>
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck11"
                    checked="checked"
                  />
                  <label class="custom-control-label" for="customCheck11"></label>
                </div>
              </div>
            </div>
          </td>
          <td>
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input" id="customCheck22" />
                  <label class="custom-control-label" for="customCheck22"></label>
                </div>
              </div>
            </div>
          </td>
          <td>
            <select id="inputState" class="form-control">
              <option selected="selected">Cardiology</option>
              <option selected="selected">Radiology</option>
            </select>
          </td>
          <td>
            <input type="text" class="form-control" id placeholder value="3" />
          </td>
          <!-- <td>
                        <select id="inputState" class="form-control">
                            <option selected="selected">Houston</option>
                            <option selected="selected">Dallas</option>
                        </select>
          </td>-->
          <td>
            <div class="input-group">
              <input type="text" class="form-control" placeholder="End Date" value />
              <div class="input-group-prepend">
                <span class="input-group-text">
                  <i class="fa fa-calendar" aria-hidden="true"></i>
                </span>
              </div>
            </div>
          </td>
          <td>
            <div class="form-group mt-2">
              <a href="#">
                <i class="fas fa-trash AddDelBtn" aria-hidden="true"></i>
              </a>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
    <div class="row">
      <div class="col-md-12">
        <div class="form-group">
          <label>
            Pickup Notes
            <i
              class="icon-help-round-button"
              data-container="body"
              data-toggle="popover"
              data-placement="right"
              data-content="Help Text Here"
              data-original-title
              title
            ></i>
          </label>
          <textarea class="form-control" rows="5" id="comment"></textarea>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PickupSection'
};
</script>