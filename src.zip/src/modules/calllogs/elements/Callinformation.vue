<template>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn btn-link">Call Information</button>
      </h5>
    </div>

    <div
      id="collapseTwo"
      class="collapse show"
      aria-labelledby="headingTwo"
      data-parent="#accordion"
    >
      <div class="card-body">
        <div class="row border-bottom">
          <div v-if="!editMode" class="col-md-12 text-right mb-1 pt-1">
            <span v-if="selectedCallerId != ''" class="workingBtn">
              <a href="javascript:void(0)" @click="editMode = true">
                <i class="fa fa-repeat" aria-hidden="true"></i> Update Caller detail
              </a>
            </span>
            <span v-else class="workingBtn">
              <a href="javascript:void(0)" @click="editMode = true">
                <i class="fa fa-plus" aria-hidden="true"></i> Add new contact
              </a>
            </span>
          </div>
          <div v-else class="col-md-12 text-right mb-1 pt-1">
            <button type="button" class="save-btn mr-1" @click="saveContactInformation()">Save</button>
            <button type="button" class="cancel-btn" @click="cancelClicked()">Cancel</button>
          </div>
        </div>
        <div class="row pt-1">
          <div v-if="!editMode" class="col-lg-3 col-md-6">
            <div class="form-group">
              <label>Select Caller</label>
              <select v-model="selectedCallerId" id="inputState" class="form-control" @change="getContactInformation()">
                <option selected="selected" value="">Select Caller</option>
                <option v-for="(caller, index) in callerOptions" :key="index" :value="caller.entityID">{{ caller.entityName }}</option>
              </select>
            </div>
          </div>
          <div v-if="editMode" class="col-lg-3 col-md-6">
            <div class="row pt-1">
              <div class="col-lg-6 col-md-6">
                <div class="form-group">
                  <label>First Name</label>
                  <input v-if="selectedCallerId != ''" type="text" class="form-control" id placeholder :value="contactInformation.firstName" />
                  <input v-else type="text" class="form-control" id placeholder value="" />
                </div>
              </div>
              <div class="col-lg-6 col-md-6">
                <div class="form-group">
                  <label>Last Name</label>
                  <input v-if="selectedCallerId != ''" type="text" class="form-control" id placeholder :value="contactInformation.lastName" />
                  <input v-else type="text" class="form-control" id placeholder value="" />
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="form-group">
              <label>Department</label>
              <select v-model="selectedDepartmentId" id="inputState" class="form-control">
                <option selected="selected" value="0">Select Department</option>
                <option v-for="(department, index) in departmentOptions" :key="index" :value="department.entityID">{{ department.entityName }}</option>
              </select>
              <!-- <input type="text" class="form-control" id placeholder /> -->
            </div>
          </div>
          <div class="col-lg-2 col-md-6">
            <div class="form-group">
              <label>Phone</label>
              <input v-if="selectedCallerId != ''" type="text" class="form-control" id placeholder :value="contactInformation.phone" />
              <input v-else type="text" class="form-control" id placeholder />
            </div>
          </div>
          <div class="col-lg-2 col-md-6">
            <div class="form-group">
              <label>Extension</label>
              <input v-if="selectedCallerId != ''" type="text" class="form-control" id placeholder :value="contactInformation.ext" />
              <input v-else type="text" class="form-control" id placeholder />
            </div>
          </div>
          <div class="col-lg-2 col-md-12">
            <div class="form-group">
              <label>Email</label>
              <input v-if="selectedCallerId != ''" type="text" class="form-control" id placeholder :value="contactInformation.email" />
              <input v-else type="text" class="form-control" id placeholder />
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-6">
            <div class="form-group">
              <label>Call Date and Time</label>
              <div class="row">
                <div class="col">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder />
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                      </span>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder />
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="fa fa-clock-o" aria-hidden="true"></i>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- <div class="col-lg-3 col-md-6">
            <div class="form-group">
                <label>Call Type</label>
                <select id="inputState" class="form-control">
                    <option selected="selected">Both</option>
                </select>
            </div>
          </div>-->
          <div class="col-lg-3 col-md-6">
            <label></label>
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck48"
                    checked="checked"
                  />
                  &nbsp;
                  <label class="custom-control-label" for="customCheck48">
                    Exclude from
                    KPI
                  </label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-6">
            <label></label>
            <div class="form-group">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck49"
                    @change="isDemoLoanerCheck()"
                    :checked="isDemoLoaner"
                  />
                  &nbsp;
                  <label
                    class="custom-control-label"
                    for="customCheck49"
                  >Demo/Loaner</label>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import { CalllogUrls, MasterUrls } from '../../../shared/constants/urls';
// import { required, helpers } from 'vuelidate/lib/validators';
// import VALIDATION_MESSAGES from '../../shared/constants/messages';
import CallLogService from "../services/CallLogServices";
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { EventBus } from '../../../EventBus/event-bus';

export default {
    name: 'CallInformation',
    data() {
        return {
            callerOptions: [],
            departmentOptions: [],
            selectedCallerId: '',
            selectedDepartmentId: 0,
            contactInformation: null,
            editMode: false,
            isDemoLoaner:false
        }
    },
    mounted() {
        this.getDropdownData("Caller");
        this.getDropdownData("Department");
    },
    methods: {
        isDemoLoanerCheck() {
            this.isDemoLoaner = !this.isDemoLoaner;
            EventBus.$emit('is-demo-loaner', this.isDemoLoaner);
        },
        getDropdownData(type) {
            let url = `${MasterUrls.getMasterMockup}`;
            if(type == "Caller") {
                url += `?identifier=Caller&id=${this.$route.params.id}`;
            }
            else {
                url += `?identifier=Departments&id=${this.$route.params.id}`;
            }
            CallLogService.getCallLogResult(url).then(res => {
                // console.log(res, '=====================');
                const result = res.data.data;
                if(type == "Caller")
                    this.callerOptions = result.Caller;
                else
                    this.departmentOptions = result.Departments;
            });
        },
        getContactInformation() {
            if(this.selectedCallerId == '')
                return;
            
            // console.log(this.selectedCallerId);
            CallLogService.getCallLogResult(`${CalllogUrls.PARTNER_CONTACT_DETAILS}?partnerContactId=${this.selectedCallerId}`).then(res => {
                // console.log(res, '=====================');
                const result = res.data.data;
                this.contactInformation = result;
                this.selectedDepartmentId = this.contactInformation.partnerDepartmentId;
            });
        },
        cancelClicked() {
          const cancel = showWindowConfrim();
          if (cancel) {
            console.log("cancel", cancel);
            // if (this.$route.params.id) {
              this.editMode = false;
              // this.getPartnersInfo(this.$route.params.id);
            // } else {
            //   this.submitted = false;
            //   this.$v.$reset();
            //   this.partnerInformation = this.createPartnerInfoForm();
            // }
          }
          return false;
        },
        saveContactInformation() {
          
        }
    }
};
</script>