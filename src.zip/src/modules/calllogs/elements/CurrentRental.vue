<template>
  <div>
    <div class="row pt-2 mb-2 light-tab-bg">
      <div class="col-md-5">
        <div class="form-group">
          <label class="custom-label">Add Model for Pickup</label>
          <input type="text" class="form-control" id placeholder />
        </div>
      </div>
      <div class="col-md-4">
        <div class="form-group">
          <label class="custom-label">Quantity</label>
          <input type="text" class="form-control" id placeholder />
        </div>
      </div>
      <div class="col-md-2 text-left">
        <div class="form-group mt-4 pt-2">
          <span class="FormworkingBtn">
            <a href="javascript:void(0)">
              <i class="fa fa-cart-plus" aria-hidden="true"></i>
              Add to cart
            </a>
          </span>
        </div>
      </div>
    </div>
    <div class="fullPagetable">
      <div class="row">
        <div class="col-md-12 tab-subheading pb-2">Add Product for Pickup</div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="table-responsive">
            <table class="table softwareTable">
              <thead>
                <tr>
                  <th width="15%">
                    <div class="headText text-nowrap">
                      <span>Barcode #</span>
                      <i class="icon-filter-filled-tool-symbol"></i>
                    </div>
                    <div class="form-group">
                      <input type="text" class="form-control" id placeholder />
                    </div>
                  </th>
                  <th width="25%">
                    <div class="headText text-nowrap">
                      <span>Model Common Name</span>
                      <i class="icon-filter-filled-tool-symbol"></i>
                    </div>
                    <div class="form-group">
                      <input type="text" class="form-control" id placeholder />
                    </div>
                  </th>
                  <th width="20%">
                    <div class="headText text-nowrap">
                      <span>Category</span>
                      <i class="icon-filter-filled-tool-symbol"></i>
                    </div>
                    <div class="form-group">
                      <input type="text" class="form-control" id placeholder />
                    </div>
                  </th>
                  <th width="15%">
                    <div class="headText text-nowrap">
                      <span>Out of Box Failure</span>
                    </div>
                  </th>
                  <th width="20%"></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="idRef text-nowrap">526398</td>
                  <td class="idRef text-nowrap">Philips v60 Bipap</td>
                  <td>Equipment</td>
                  <td>
                    <div class="checkBoxinFrom">
                      <div class="custom-control custom-checkbox">
                        <input
                          type="checkbox"
                          class="custom-control-input"
                          id="customCheck48"
                          checked="checked"
                        />
                        &nbsp;
                        <label class="custom-control-label">&nbsp;</label>
                      </div>
                    </div>
                  </td>
                  <td class="text-right">
                    <span class="FormworkingBtn">
                      <a href="javascript:void(0)">
                        <i class="fa fa-cart-plus" aria-hidden="true"></i>
                        Add to cart
                      </a>
                    </span>
                  </td>
                </tr>
                <tr>
                  <td>452136</td>
                  <td class="idRef text-nowrap">Philips Heartstart XL</td>
                  <td>Equipment</td>
                  <td>
                    <div class="checkBoxinFrom">
                      <div class="custom-control custom-checkbox">
                        <input
                          type="checkbox"
                          class="custom-control-input"
                          id="customCheck48"
                          checked="checked"
                        />
                        &nbsp;
                        <label class="custom-control-label">&nbsp;</label>
                      </div>
                    </div>
                  </td>
                  <td class="text-right">
                    <span class="FormworkingBtn">
                      <a href="javascript:void(0)">
                        <i class="fa fa-cart-plus" aria-hidden="true"></i>
                        Add to cart
                      </a>
                    </span>
                  </td>
                </tr>
                <tr>
                  <td>785412</td>
                  <td class="idRef text-nowrap">Medex Medfusion 3500</td>
                  <td>Equipment</td>
                  <td>
                    <div class="checkBoxinFrom">
                      <div class="custom-control custom-checkbox">
                        <input
                          type="checkbox"
                          class="custom-control-input"
                          id="customCheck48"
                          checked="checked"
                        />
                        &nbsp;
                        <label class="custom-control-label">&nbsp;</label>
                      </div>
                    </div>
                  </td>
                  <td class="text-right">
                    <span class="FormworkingBtn">
                      <a href="javascript:void(0)">
                        <i class="fa fa-cart-plus" aria-hidden="true"></i>
                        Add to cart
                      </a>
                    </span>
                  </td>
                </tr>
                <tr>
                  <td>856321</td>
                  <td class="idRef text-nowrap">GE Giraffe Omnibed Incubator</td>
                  <td>Equipment</td>
                  <td>
                    <div class="checkBoxinFrom">
                      <div class="custom-control custom-checkbox">
                        <input
                          type="checkbox"
                          class="custom-control-input"
                          id="customCheck48"
                          checked="checked"
                        />
                        &nbsp;
                        <label class="custom-control-label">&nbsp;</label>
                      </div>
                    </div>
                  </td>
                  <td class="text-right">
                    <span class="FormworkingBtn">
                      <a href="javascript:void(0)">
                        <i class="fa fa-cart-plus" aria-hidden="true"></i>
                        Add to cart
                      </a>
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="row">
            <div class="col-md-5">
              <div class="tablePagination">
                <nav aria-label="Page navigation example">
                  <ul class="pagination">
                    <li class="page-item">
                      <a class="page-link" href="#" aria-label="Previous">
                        <span aria-hidden="true">
                          <i class="fa fa-angle-left" aria-hidden="true"></i>
                        </span>
                        <span class="sr-only">Previous</span>
                      </a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">1</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">2</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">3</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">4</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">5</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">6</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">7</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">8</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">9</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">10</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#" aria-label="Next">
                        <span aria-hidden="true">
                          <i class="fa fa-angle-right" aria-hidden="true"></i>
                        </span>
                        <span class="sr-only">Next</span>
                      </a>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>

            <div class="col-md-3 form-inline">
              Page Size &nbsp;
              <select
                class="form-control"
                style="width:60px; padding:0; margin:0; height:25px;"
              >
                <option selected="selected">10</option>
                <option>20</option>
                <option>30</option>
              </select>
            </div>

            <div class="col-md-4">
              <div class="tablelistInfo">91 items in 10 pages</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CurrentRental'
};
</script>