<template>
  <div>
    <table class="table data-table" v-if="requestCart.length > 0">
      <thead>
        <tr>
          <th scope="col">Model Common Name</th>
          <th scope="col">Model Options</th>
          <th scope="col">Software Version</th>
          <th scope="col">Department</th>
          <th scope="col">Quantity</th>
          <th scope="col">Fullfillment Location</th>
          <th scope="col" v-if="!displayDemoLoanerSections">Billing Start Date</th>
          <th scope="col" v-if="displayDemoLoanerSections">Demo/Loaner Start & End Date</th>
          <th scope="col"></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(deliverycart,index) in requestCart" :key="deliverycart.modelId+index">
          <td>{{deliverycart.modelCommonName}}</td>
          <td>
            <select id="inputState" class="form-control">
              <option>Select</option>
              <option>Model Option 1</option>
            </select>
          </td>
          <td>
            <select
              id="inputState"
              class="form-control"
              v-model="deliverycart.modelSoftwareVersionID"
            >
              <option value>Select</option>
              <template v-if="deliverycart.softwareVersionArray !== 'undefined'">
                <option
                  v-for="sVersion in deliverycart.softwareVersionArray"
                  :key="sVersion.entityID"
                  :value="sVersion.entityID"
                >{{sVersion.entityName}}</option>
              </template>
            </select>
          </td>
          <td>
            <select
              id="inputState"
              class="form-control"
              v-model="deliverycart.defaultDeliveryDeptId"
            >
              <option value>Select</option>
              <option
                v-for="department in departments"
                :key="department.entityID"
                :value="department.entityID"
              >{{department.entityName}}</option>
            </select>
          </td>
          <td>
            <input type="text" class="form-control" v-model="deliverycart.quantity" />
          </td>
          <td>
            <select id="inputState" class="form-control" v-model="selectedBranch">
              <option value>Select</option>
              <option
                v-for="branch in branchList"
                :key="branch.entityID"
                :value="branch.entityID"
              >{{branch.entityName}}</option>
            </select>
          </td>
          <td v-if="!displayDemoLoanerSections">
            <div class="row">
              <div class="col">
                <div class="input-group">
                  <kendo-datepicker
                    :date-input="true"
                    :format="'MM/dd/yyyy'"
                    ref="picker-billing-date"
                    placeholder="Type in your birth date..."
                  ></kendo-datepicker>
                </div>
              </div>
            </div>
          </td>
          <td v-if="displayDemoLoanerSections">
            <div class="row">
              <div class="col">
                <div class="input-group" v-if="displayDemoLoanerSections">
                  <kendo-datepicker
                    :date-input="true"
                    :format="'MM/dd/yyyy'"
                    ref="picker-demo-start-date"
                    placeholder="Type in your birth date..."
                  ></kendo-datepicker>
                </div>
                <div class="input-group" v-if="displayDemoLoanerSections">
                  <kendo-datepicker
                    :date-input="true"
                    :format="'MM/dd/yyyy'"
                    ref="picker-demo-end-date"
                  ></kendo-datepicker>
                </div>
              </div>
            </div>
          </td>
          <td>
            <div class="form-group mt-2">
              <a href="javascript:void(0)">
                <i class="fas fa-trash AddDelBtn" aria-hidden="true"></i>
              </a>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
    <div class="row" v-if="requestCart.length > 0">
      <div class="col-md-12">
        <div class="form-group">
          <label>
            Delivery Notes
            <i class="fa fa-info-circle" aria-hidden="true" title="Delivery Notes"></i>
          </label>
          <textarea class="form-control" rows="5" id="comment"></textarea>
        </div>
      </div>
    </div>
    <div class="row" v-if="requestCart.length === 0">
      <div class="col-md-12 text-center p-4">
        <h5 class="p-2">Your Request Cart is empty</h5>
        <span class="workingBtn" @click="OpenSideBarEvent()">
          <a href="javascript:void(0)">click here to add items</a>
        </span>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import { EventBus } from '../../../EventBus/event-bus';
import { MasterUrls } from '../../../shared/constants/urls';
import CallLogService from '../services/CallLogServices';

export default {
  name: 'RequestSection',
  data() {
    return {
      branchList: [],
      selectedBranch: 1,
      departments: [],
      displayDemoLoanerSections: false
    };
  },
  computed: mapGetters({
    requestCart: 'getDeliveryCart'
    // displayDemoLoanerSections: 'getDemoLoader'
  }),
  watch: {
    // requestCart(requestCartNew, requestCartOld) {
    //   // Our fancy notification (2).
    //   // console.log(`We have ${requestCartNew} ${requestCartOld} fruits now, yaay!`);
    // }
  },
  methods: {
    OpenSideBarEvent() {
      EventBus.$emit('open-calllog-bar', true);
    },
    getDropDownOptions() {
      // eslint-disable-next-line arrow-parens
      CallLogService.getCallLogResult(`${MasterUrls.getMasterMockup}?identifier=Branch`).then(response => {
        if (response.data) {
          this.branchList = response.data.data.Branch;
        }
      });
      // eslint-disable-next-line arrow-parens
      CallLogService.getCallLogResult(`${MasterUrls.getMasterMockup}?identifier=Departments&id=${this.$route.params.id}`).then(response => {
        if (response.data) {
          this.departments = response.data.data.Departments;
        }
      });
    }
  },
  created() {
    this.getDropDownOptions();
    // this.$store.dispatch('setDeliveryCart', preferredModelObject);
    // this.selectedBranch = this.$store.getters.getUserbranch;
    // console.log(this.selectedBranch);
    // this.deliveryCartData = this.$store.getters.getDeliveryCart;

    // eslint-disable-next-line arrow-parens
    EventBus.$on('clear-cart', clearCartValue => {
      if (clearCartValue) {
        this.requestCart.length = 0;
        this.$store.dispatch('resetEditCallLogStateToDefault');
      }
    });

    // eslint-disable-next-line arrow-parens
    EventBus.$on('is-demo-loaner', demoloanervalue => {
      this.displayDemoLoanerSections = demoloanervalue;
      this.$store.dispatch('setIsDemoLoaner', demoloanervalue);
    });
  }
};
</script>