/* eslint-disable no-new */
<template>
  <div>
    <table class="table data-table">
      <thead>
        <tr>
          <th scope="col">Call Log #</th>
          <th scope="col">Call Date</th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <template v-for="(orderhistory,index) in orderHistory">
          <tr class="light-grey-bg" :key="orderhistory.callLogId">
            <td class="idRef text-nowrap">{{orderhistory.callLogId}}</td>
            <td class="text-nowrap">{{orderhistory.callDate}}</td>
            <td class="text-right" @click="CallDetails(orderhistory.callLogId, index)">View Models</td>
            <td class="text-right">
              <span class="FormworkingBtn" @click="AddToCart(orderhistory.callLogId, index)">
                <a href="javascript:void(0)">
                  <i class="fa fa-cart-plus" aria-hidden="true"></i> Add to cart
                </a>
              </span>
            </td>
          </tr>
          <tr class="light-grey-bg" v-if="showOrderDetails==index">
            <td colspan="4">
              <table class="table table-bordered mb-0">
                <thead>
                  <tr>
                    <th scope="col">Model Common Name</th>
                    <th scope="col">Category</th>
                    <th scope="col">Quantity</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="calllog in CallLogDetails" :key="calllog.modeId">
                    <td>{{calllog.modelCommonName}}</td>
                    <td>{{calllog.modelCategory}}</td>
                    <td>{{calllog.quantity}}</td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </template>
      </tbody>
    </table>
  </div>
</template>
 

<script>
/* eslint-disable */
import CallLogService from '../services/CallLogServices';
import { CalllogUrls } from '../../../shared/constants/urls';

export default {
  name: 'OrderHistory',
  data() {
    return {
      userId: 1,
      partnerId: this.$route.params.id,
      partnerContactId: 1,
      showOrderDetails: null,
      orderHistory: [],
      CallLogDetails: [],
      CallLogDetailsAddCart: []
    };
  },
  methods: {
    AddToCart(callLogId, index) {
      new Promise(resolve => {
        setTimeout(resolve => {
          CallLogService.getCallLogResult(`${CalllogUrls.GET_ORDERED_MODEL_DETAILS}?callLogId=${callLogId}`).then(res => {
            const result = res.data.data;
            if (result && result.length > 0) {
              result.forEach(element => {
                this.$store.dispatch('setDeliveryCart', element);
              });
            }
          });
        }, 500);
      });

      console.log(this.CallLogDetails);
    },
    CallGetAPI() {
      // eslint-disable-next-line arrow-parens
      CallLogService.getCallLogResult(`${CalllogUrls.GET_ORDERED_MODEL}?userId=${this.partnerId}&partnerContactId=${this.partnerContactId}`).then(res => {
        const result = res.data.data;
        if (result) {
          this.orderHistory = result;
        }
      });
    },
    /**
     * This method will load Order details based on call log ID
     * @param calllogid (INT)
     */
    CallDetails(calllogid, index) {
      this.CallLogDetails.length = 0;
      // eslint-disable-next-line arrow-parens
      CallLogService.getCallLogResult(`${CalllogUrls.GET_ORDERED_MODEL_DETAILS}?callLogId=${calllogid}`).then(res => {
        const result = res.data.data;
        if (result && result.length > 0) {
          this.CallLogDetails = result;
          // if (index !== false) {
          this.showOrderDetails = index;
          // }
        }
      });
    }
  },
  async created() {
    if (this.$route.params.id) {
      await this.CallGetAPI();
    }
  }
};
</script>