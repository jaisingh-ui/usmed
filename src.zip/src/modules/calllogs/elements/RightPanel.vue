<template>
  <div>
    <div class="openArrow" @click="activateRightMenu()">
      <span></span>
    </div>
    <div class="rightSubmenu rightSubTab" :class="activeClass">
      <div class="overflow-hidden">
        <div class="rightSubTab-heading">Add Items to Request Cart</div>
        <div class="closeRight" @click="deactivateRightMenu()">
          <i class="fa fa-times-circle" aria-hidden="true"></i>
        </div>
      </div>

      <ul class="nav nav-tabs pl-0 slide-tab" id="myTab" role="tablist">
        <li class="nav-item">
          <a
            class="nav-link active"
            id="preferred-models-tab"
            data-toggle="tab"
            href="#preferred-models"
            role="tab"
            aria-controls="preferred-models"
            aria-selected="true"
          >Preferred Models</a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            id="rental-history-tab"
            data-toggle="tab"
            href="#rental-history"
            role="tab"
            aria-controls="rental-history"
            aria-selected="false"
          >Rental History</a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            id="order-history-tab"
            data-toggle="tab"
            href="#order-history"
            role="tab"
            aria-controls="order-history"
            aria-selected="false"
          >Order History</a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            id="current-rentals-tab"
            data-toggle="tab"
            href="#current-rentals"
            role="tab"
            aria-controls="current-rentals"
            aria-selected="false"
          >
            Current Rentals
            <span class="badge badge-danger rounded-circle p-1">11</span>
          </a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            id="stand-by-tab"
            data-toggle="tab"
            href="#stand-by"
            role="tab"
            aria-controls="stand-by"
            aria-selected="false"
          >
            Stand By
            <span class="badge badge-danger rounded-circle p-1">04</span>
          </a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            id="pmdue-tab"
            data-toggle="tab"
            href="#pmdue"
            role="tab"
            aria-controls="pmdue"
            aria-selected="false"
          >
            PM Due
            <span class="badge badge-danger rounded-circle p-1">03</span>
          </a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            id="model-catalog-tab"
            data-toggle="tab"
            href="#model-catalog"
            role="tab"
            aria-controls="model-catalog"
            aria-selected="false"
          >Model Catalog</a>
        </li>
      </ul>

      <div class="tab-content" id="myTabContent">
        <div
          class="tab-pane fade show active p-4"
          id="preferred-models"
          role="tabpanel"
          aria-labelledby="preferred-models-tab"
        >
          <div class="row">
            <div class="col-md-12 tab-subheading pb-2">Add Model for Delivery</div>
          </div>
          <PreferredModels />
        </div>

        <div
          class="tab-pane fade p-4"
          id="rental-history"
          role="tabpanel"
          aria-labelledby="rental-history-tab"
        >
          <div class="row">
            <div class="col-md-12 tab-subheading pb-2">Add Model for Delivery</div>
          </div>
          <RentalHistory />
        </div>

        <div
          class="tab-pane fade p-4"
          id="order-history"
          role="tabpanel"
          aria-labelledby="order-history-tab"
        >
          <div class="row">
            <div class="col-md-12 tab-subheading pb-2">Add Model for Delivery</div>
          </div>
          <OrderHistory />
        </div>

        <div
          class="tab-pane fade p-4"
          id="current-rentals"
          role="tabpanel"
          aria-labelledby="current-rentals-tab"
        >
          <CurrentRental />
        </div>

        <div class="tab-pane fade p-4" id="stand-by" role="tabpanel" aria-labelledby="stand-by-tab">
          <div class="row">
            <div class="col-md-12 tab-subheading pb-2">Add Product for Pickup</div>
          </div>
          <StandBy />
        </div>

        <div class="tab-pane fade p-4" id="pmdue" role="tabpanel" aria-labelledby="pmdue-tab">
          <div class="row">
            <div class="col-md-12 tab-subheading pb-2">Add Product for Pickup</div>
          </div>
          <PMDue />
        </div>

        <div
          class="tab-pane fade p-4"
          id="model-catalog"
          role="tabpanel"
          aria-labelledby="model-catalog-tab"
        >
          <div class="row">
            <div class="col-md-12 tab-subheading pb-2">Add Model for Delivery</div>
          </div>
          <ModelCatalog />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { EventBus } from '../../../EventBus/event-bus';
import PreferredModels from '../elements/PreferredModels';
import RentalHistory from '../elements/RentalHistory';
import OrderHistory from '../elements/OrderHistory';
import CurrentRental from '../elements/CurrentRental';
import StandBy from '../elements/StandBy';
import PMDue from '../elements/PMDue';
import ModelCatalog from '../elements/ModelCatalog';

export default {
  name: 'RightPanel',
  components: {
    PreferredModels,
    RentalHistory,
    OrderHistory,
    CurrentRental,
    StandBy,
    PMDue,
    ModelCatalog
  },
  data() {
    return {
      activeClass: null
    };
  },
  methods: {
    activateRightMenu() {
      this.activeClass = 'rightmenuOpen';
    },
    deactivateRightMenu() {
      this.activeClass = null;
    }
  },
  created() {
    // eslint-disable-next-line arrow-parens
    EventBus.$on('open-calllog-bar', openSideBar => {
      if (openSideBar) {
        this.activeClass = 'rightmenuOpen';
      }
    });
  }
};
</script>