<template>
  <div class="card">
    <div class="card-header" id="headingFive">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseFive"
          aria-expanded="false"
          aria-controls="collapseThree"
          @click="clickPanel"
        >Battery</button>
      </h5>
      <div class="rightInfotext">
        <i
          @click="clickPanel"
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseFive"
        ></i>
      </div>
    </div>
    <div id="collapseFive" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid #efefef;">
          <div class="col-md-12 text-right mb-1 mt-1">
            <div v-if="!editMode">
              <button type="button" class="save-btn mr-1" @click.prevent="handleSubmit">Save</button>
              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </div>
            <div v-else>
              <button type="button" class="edit-btn" @click.prevent="onEditClicked">Edit</button>
            </div>
          </div>
        </div>
        <div class="row pt-3">
          <div class="col-lg-4 col-md-5">
            <div class="form-group">
              <label>Battery Replacement Life (Months)</label>
              <input
                type="text"
                :disabled="editMode"
                oninput="validity.valid||(value='');"
                min="1"
                pattern="\d*"
                maxlength="9"
                v-model.number="batteryObj.durationInMonths"
                class="form-control"
              />
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="form-group">
              <label>Hours</label>
              <input
                type="text"
                :disabled="editMode"
                oninput="validity.valid||(value='');"
                min="1"
                pattern="\d*"
                maxlength="9"
                v-model.number="batteryObj.workingHours"
                class="form-control"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import modelService from '../services/model-service';
import { ServiceInfoUrls } from '../../../shared/constants/urls';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

export default {
  props: {
    itemIndex: {
      type: Number
    }
  },
  name: 'Battery',
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      modelId: null,
      batteryObj: {
        durationInMonths: '',
        workingHours: ''
      },
      submitted: false,
      editMode: true
    };
  },

  created() {
    this.modelId = this.$store.getters.getModelId;
    this.getDataFromAPI(this.modelId);
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    handleSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      const postData = {};
      postData.modelId = this.$store.getters.getModelId;
      postData.userId = 1;
      postData.durationInMonths = this.batteryObj.durationInMonths;
      postData.workingHours = this.batteryObj.workingHours;

      // eslint-disable-next-line arrow-parens
      modelService.postModelsDataAction(`${ServiceInfoUrls.POST_BATTERY}`, postData).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.editMode = true;
          this.getDataFromAPI(this.modelId);
          this.$emit('togglePanel', this.editMode, this.itemIndex);
          showToast('success');
        }
      });
    },
    getDataFromAPI(id) {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ServiceInfoUrls.GET_BATTERY}?modelId=${id}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          const result = res.data.data;
          this.batteryObj.durationInMonths = result.durationInMonths;
          this.batteryObj.workingHours = result.workingHours;
        }
      });
    },
    onEditClicked() {
      this.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.editMode = true;
        // this.batteryObj.durationInMonths = '';
        // this.batteryObj.workingHours = '';
        this.$emit('togglePanel', this.editMode, this.itemIndex);
      }
      return false;
    },
    onChildCancelClicked() {
      this.editMode = true;
      // this.batteryObj.durationInMonths = '';
      // this.batteryObj.workingHours = '';
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    checkboxReturn(e) {
      if (e.target.checked) {
        this.isMobileAppModel = false;
        this.isFeaturedMobileProduct = false;
      }
    }
  }
};
</script>
