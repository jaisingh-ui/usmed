<template>
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button
          class="btn btn-link"
          data-toggle="collapse"
          data-target="#collapseThree"
          aria-expanded="false"
          aria-controls="collapseThree"
          @click="clickPanel"
        >Recall</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseThree"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseThree"
      class="collapse"
      aria-labelledby="headingThree"
      data-parent="#accordion"
    >
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid #efefef;">
          <div class="col-md-12 text-right mb-1 mt-1">
            <div v-if="!editMode">
              <button
                type="button"
                :class="enableSaveBtn()?  'save-btn mr-1' : 'save-btn mr-1 custom-disabled'"
                @click.prevent="handleSubmit"
              >Save</button>
              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </div>
            <div v-else class="workingBtn">
              <button
                v-if="editMode"
                type="button"
                class="edit-btn"
                @click.prevent="onEditClicked"
              >Edit</button>
            </div>
          </div>
        </div>
        <div id="ParentDiv">
          <div
            class="row"
            v-for="(option, index) in recordsObj.modelRecallInfo"
            v-bind:key="index"
            :id="index"
          >
            <div class="col-lg-2">
              <div class="form-group">
                <label v-if="index === 0">Date of Recall</label>
                <div class="input-group">
                  <kendo-datepicker
                    :disabled="editMode"
                    :class="toggleOptions(option, index)"
                    :date-input="true"
                    :format="'MM/dd/yyyy'"
                    v-model="option.reCallDate"
                    ref="picker"
                  ></kendo-datepicker>
                </div>
              </div>
            </div>
            <div class="col-lg-2">
              <div class="form-group">
                <label v-if="index === 0">Reason for Recall</label>
                <input
                  type="text"
                  :disabled="editMode"
                  :class="toggleOptions(option, index)"
                  v-model="option.reCallReason"
                />
                <p
                  class="error-message"
                  v-if="!$v.recordsObj.modelRecallInfo.$each[index].reCallReason.alphaNum"
                >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="row">
                <div class="col">
                  <div class="form-group">
                    <label v-if="index === 0">Serial Number From</label>
                    <input
                      type="text"
                      :disabled="editMode"
                      :class="toggleOptions(option, index)"
                      v-model="option.recallProductSerialFrom"
                    />
                    <p
                      v-if="!$v.recordsObj.modelRecallInfo.$each[index].recallProductSerialFrom.required"
                      class="error-message"
                    >{{validationMessages.REQUIRED}}</p>
                  </div>
                </div>
                <div class="col">
                  <div class="form-group">
                    <label v-if="index === 0">Serial Number To</label>
                    <input
                      type="text"
                      :disabled="editMode"
                      :class="toggleOptions(option, index)"
                      v-model="option.recallProductSerialNoTo"
                    />
                    <p
                      v-if="!$v.recordsObj.modelRecallInfo.$each[index].recallProductSerialNoTo.required"
                      class="error-message"
                    >{{validationMessages.REQUIRED}}</p>
                  </div>
                </div>
              </div>
            </div>
            <!-- <div class="col-md-1 text-center mt-1">
              <div class="form-group">
                <br v-if="0 === index" />
                <label>OR</label>
              </div>
            </div>-->
            <div class="col-lg-3">
              <div class="row">
                <div class="col">
                  <div class="form-group">
                    <label v-if="index === 0">Date of Manufacture From</label>
                    <div class="input-group">
                      <kendo-datepicker
                        :disabled="editMode"
                        :class="toggleOptions(option, index)"
                        :id="'start'+index"
                        v-on:change="startChange(index)"
                        :format="'MM/dd/yyyy'"
                        v-model="option.manufactureDtFrom"
                      ></kendo-datepicker>
                    </div>
                    <p
                      v-if="!$v.recordsObj.modelRecallInfo.$each[index].manufactureDtFrom.required"
                      class="error-message"
                    >{{validationMessages.REQUIRED}}</p>
                  </div>
                </div>
                <div class="col">
                  <div class="form-group">
                    <label v-if="index === 0">Date of Manufacture To</label>
                    <div class="input-group">
                      <kendo-datepicker
                        :disabled="editMode"
                        :class="toggleOptions(option, index)"
                        :id="'end'+index"
                        v-on:change="endChange(index)"
                        :format="'MM/dd/yyyy'"
                        v-model="option.manufactureDtTo"
                      ></kendo-datepicker>
                    </div>
                    <p
                      v-if="!$v.recordsObj.modelRecallInfo.$each[index].manufactureDtTo.required"
                      class="error-message"
                    >{{validationMessages.REQUIRED}}</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-1 text-left">
              <div :class="{'form-group mt-4 pt-2': index===0, 'form-group mt-1': index!==0}">
                <a
                  :disabled="editMode"
                  href="#"
                  v-if="index === recordsObj.modelRecallInfo.length-1"
                  @click.prevent="editMode? '#':addElements(index)"
                >
                  <i class="icon-model-options AddDelBtn" aria-hidden="true"></i>
                </a>
                <a
                  :disabled="editMode"
                  href="#"
                  v-else
                  @click.prevent="editMode? '#':deleteElements(index)"
                >
                  <i
                    aria-hidden="true"
                    :class="option.isActive? 'fas fa-trash AddDelBtn': 'fas fa-trash AddDelBtn custom-delete-btn'"
                  ></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import Vue from 'vue';
import { DateinputsInstaller } from '@progress/kendo-dateinputs-vue-wrapper';
import { required, requiredIf, alphaNum } from 'vuelidate/lib/validators';
import modelService from '../services/model-service';
import { ServiceInfoUrls } from '../../../shared/constants/urls';
import $ from 'jquery';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

Vue.use(DateinputsInstaller);
export default {
  props: {
    itemIndex: {
      type: Number
    }
  },
  name: 'RecallInformation',
  data() {
    return {
      submitted: false,
      modelId: null,
      recordsObj: {
        modelId: null,
        modelRecallInfo: [
          {
            id: 0,
            reCallDate: null,
            reCallReason: '',
            recallProductSerialFrom: '',
            recallProductSerialNoTo: '',
            manufactureDtFrom: null,
            manufactureDtTo: null,
            isActive: true
          }
        ]
      },
      validationMessages: VALIDATION_MESSAGE,
      opertaionMode: 'none',
      disableRow: [],
      persistData: [],
      editMode: true,
      isError: false,
      duplicateIndex: null,
      validOption1: null,
      validOption2: null
    };
  },
  validations: {
    recordsObj: {
      modelRecallInfo: {
        $each: {
          reCallReason: { alphaNum },
          recallProductSerialFrom: {
            required: requiredIf(vm => {
              if (vm.recallProductSerialNoTo !== '') {
                return true;
              }
              return false;
            })
          },
          recallProductSerialNoTo: {
            required: requiredIf(vm => {
              if (vm.recallProductSerialFrom !== '') {
                return true;
              }
              return false;
            })
          },
          manufactureDtFrom: {
            required: requiredIf(vm => {
              if (vm.manufactureDtTo != null) {
                return true;
              }
              return false;
            })
          },
          manufactureDtTo: {
            required: requiredIf(vm => {
              if (vm.manufactureDtFrom != null) {
                return true;
              }
              return false;
            })
          }
        }
      }
    }
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    // Once Edit is clicked we can add/delete new records and also toggle existing redords
    onEditClicked() {
      this.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    // Will allow to add elements if the current input element is non-empty
    addElements(index) {
      // Add elements only in case if first element option property is not empty
      if (
        this.recordsObj.modelRecallInfo[index].reCallDate !== null ||
        this.recordsObj.modelRecallInfo[index].reCallReason !== '' ||
        this.recordsObj.modelRecallInfo[index].recallProductSerialFrom !== '' ||
        this.recordsObj.modelRecallInfo[index].recallProductSerialNoTo !== '' ||
        this.recordsObj.modelRecallInfo[index].manufactureDtFrom !== null ||
        this.recordsObj.modelRecallInfo[index].manufactureDtTo !== null
      ) {
        this.recordsObj.modelRecallInfo.push({
          id: 0,
          reCallDate: null,
          reCallReason: '',
          recallProductSerialFrom: '',
          recallProductSerialNoTo: '',
          manufactureDtFrom: null,
          manufactureDtTo: null,
          isActive: true
        });
      }
    },
    // this will check the duplicate entries
    validateOptionFields(value, index) {
      this.validOption1 = null;
      if (value) {
        // eslint-disable-next-line no-useless-escape
        if (!/^[a-zA-Z0-9\-_,.#\s]{0,200}$/.test(value)) {
          this.validOption1 = index;
        }
      }
    },
    // It disables the elements on clicking delete button
    deleteElements(index) {
      if (this.recordsObj.modelRecallInfo[index] !== undefined) {
        if (this.recordsObj.modelRecallInfo[index].modelOptionsId !== 0) {
          this.recordsObj.modelRecallInfo[index].isActive = !this.recordsObj.modelRecallInfo[index].isActive;
        } else {
          this.recordsObj.modelRecallInfo.splice(index, 1);
        }
      }
    },
    // If there will be no validation error
    enableSaveBtn() {
      if (this.isError) {
        return false;
      } else if (
        this.recordsObj.modelRecallInfo.length === 1 &&
        this.recordsObj.modelRecallInfo[0].duration === '' &&
        this.recordsObj.modelRecallInfo[this.recordsObj.modelRecallInfo.length - 1].hours === null
      ) {
        return false;
      }
      return true;
    },
    // Toggle enable/diable css class
    toggleOptions(option, index) {
      let optionClass = 'form-control';
      if (this.recordsObj.modelRecallInfo.length - 1 === index) {
        optionClass = 'form-control';
      } else {
        optionClass = 'form-control form-control-view';
      }
      return optionClass;
    },
    // Remove last row from the list
    removeLastRow(rowdata) {
      if (
        rowdata.reCallDate === null &&
        rowdata.reCallReason === '' &&
        rowdata.recallProductSerialFrom === '' &&
        rowdata.recallProductSerialNoTo === '' &&
        rowdata.manufactureDtFrom === null &&
        rowdata.manufactureDtTo === null
      ) {
        console.log('condition true');
        this.recordsObj.modelRecallInfo.splice(this.recordsObj.modelRecallInfo.length - 1, 1);
      }
    },
    // Save and update all records
    handleSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      this.$v.$touch();
      console.log('validation', this.$v.$invalid);
      if (this.$v.$invalid) {
        return;
      }

      // Remove empty last row
      this.removeLastRow(this.recordsObj.modelRecallInfo[this.recordsObj.modelRecallInfo.length - 1]);

      // call API to save data to DB
      if (this.validOption1 === null) {
        // eslint-disable-next-line no-console
        console.log(this.recordsObj);
        this.recordsObj.userId = 1;
        // eslint-disable-next-line arrow-parens
        modelService.postModelRequest(ServiceInfoUrls.POST_RECAll, this.recordsObj).then(res => {
          if (res.data.apiResponseStatus !== 'Failed') {
            this.editMode = true;
            this.$emit('togglePanel', this.editMode, this.itemIndex);
            // again re-render the UI from the response fom the API
            this.getRecordsfromAPI(this.modelId);
            showToast('success');
          } else {
            // eslint-disable-next-line no-console
            console.log('Internal server error');
          }
        });
      }
    },
    // Get all records from API call
    getRecordsfromAPI(id) {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ServiceInfoUrls.GET_RECAll}?modelId=${id}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.recordsObj = res.data.data;
          this.editMode = true;
          if (this.recordsObj && this.recordsObj.modelRecallInfo) {
            this.recordsObj.modelRecallInfo.push({
              id: 0,
              reCallDate: null,
              reCallReason: '',
              recallProductSerialFrom: '',
              recallProductSerialNoTo: '',
              manufactureDtFrom: null,
              manufactureDtTo: null,
              isActive: true
            });
          }
        }
      });
    },
    // Start date from calander
    startChange(index) {
      console.log(index);
      const start = $('#start' + index).data('kendoDatePicker');
      const end = $('#end' + index).data('kendoDatePicker');
      let startDate = start.value(),
        endDate = end.value();
      if (startDate) {
        startDate = new Date(startDate);
        startDate.setDate(startDate.getDate());
        end.min(startDate);
      } else if (endDate) {
        start.max(new Date(endDate));
      } else {
        endDate = new Date();
        start.max(endDate);
        end.min(endDate);
      }
    },
    // End date to calander
    endChange(index) {
      const start = $('#start' + index).data('kendoDatePicker');
      const end = $('#end' + index).data('kendoDatePicker');
      let endDate = end.value(),
        startDate = start.value();
      if (endDate) {
        endDate = new Date(endDate);
        endDate.setDate(endDate.getDate());
        start.max(endDate);
      } else if (startDate) {
        end.min(new Date(startDate));
      } else {
        endDate = new Date();
        start.max(endDate);
        end.min(endDate);
      }
    },
    // cancel will revert whole edited data to previous state
    async onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.editMode = true;
        this.validOption1 = null;
        this.validOption2 = null;
        this.isError = false;
        this.$emit('togglePanel', this.editMode, this.itemIndex);
        await this.getRecordsfromAPI(this.modelId);
      }
      return false;
    },
    async onChildCancelClicked() {
      this.editMode = true;
      this.validOption1 = null;
      this.validOption2 = null;
      this.isError = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
      await this.getRecordsfromAPI(this.modelId);
    }
  },
  // Call API to fetch option data if OperationMode is 'edit' it will disable the form
  created() {
    this.modelId = this.$store.getters.getModelId;
    this.getRecordsfromAPI(this.modelId);
  },
  mounted() {
    // const picker = this.$refs.picker.kendoWidget();
    // picker._dateInput.setOptions({
    //   messages: {
    //     year: 'YYYY',
    //     month: 'MM',
    //     day: 'DD'
    //   }
    // });
  }
};
</script>

<style scoped >
</style>