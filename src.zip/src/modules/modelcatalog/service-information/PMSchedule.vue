<template>
  <div class="card">
    <div class="card-header" id="headingFirst">
      <h5 class="mb-0">
        <button
          class="btn btn-link"
          data-toggle="collapse"
          data-target="#collapseFirst"
          aria-expanded="true"
          aria-controls="collapseFirst"
          @click="clickPanel"
        >PM Schedule</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseFirst"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseFirst"
      class="collapse show"
      aria-labelledby="headingFirst"
      data-parent="#accordion"
    >
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid #efefef;">
          <div class="col-md-12 text-right mb-1 mt-1">
            <div v-if="!editMode">
              <button type="button" class="save-btn mr-1" @click.prevent="handleSubmit">Save</button>

              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </div>

            <button v-else type="button" class="edit-btn" @click.prevent="onEditClicked">Edit</button>
          </div>
        </div>
        <div id="ParentDiv">
          <div
            class="row"
            v-for="(option, index) in recordsObj.modelPMServiceInfo"
            v-bind:key="index"
          >
            <div class="col-md-5" :id="index">
              <div class="form-group">
                <label v-if="index === 0">
                  Duration
                  <i class="fa fa-info-circle" aria-hidden="true" title="Options"></i>
                </label>
                <select
                  :disabled="editMode"
                  :class="toggleOptions(option, index)"
                  v-model="option.duration"
                >
                  <option value>Select</option>
                  <option
                    v-bind:value="opt.entityID"
                    v-for="opt in durationOpt.Duration"
                  >{{ opt.entityName }}</option>
                </select>
                <p
                  v-if="(option.duration === null && option.hours === '')"
                  class="error-message"
                >{{validationsMessages.REQUIRED}}</p>
              </div>
            </div>
            <!-- <div class="col-md-1 text-center mt-1">
              <div class="form-group">
                <br v-if="0 === index" />
                <label>OR</label>
              </div>
            </div>-->
            <div class="col-md-5 text-left">
              <div class="form-group">
                <label v-if="index === 0">
                  Hours
                  <i class="fa fa-info-circle" aria-hidden="true" title="Option Description"></i>
                </label>
                <!-- <input
                  :disabled="editMode"
                  type="text"
                  oninput="validity.valid||(value='');"
                  min="1"
                  :class="toggleOptions(option, index)"
                  v-model.number="option.hours"
                />-->
                <div class="custom-numerictextbox">
                  <numerictextbox
                    :disabled="editMode"
                    :class="toggleOptions(option, index)"
                    v-model="option.hours"
                    :format="'#'"
                    :decimals="0"
                    :min="0"
                  ></numerictextbox>
                </div>
                <p
                  v-if="(option.duration === null && option.hours === '')"
                  class="error-message"
                >{{validationsMessages.REQUIRED}}</p>
              </div>
            </div>
            <div class="col-md-1 text-left">
              <div :class="{'form-group mt-4 pt-2': index===0, 'form-group mt-1': index!==0}">
                <a
                  :disabled="editMode"
                  href="#"
                  v-if="index === recordsObj.modelPMServiceInfo.length-1"
                  @click.prevent="editMode? '#':addElements(index)"
                >
                  <i :class="addElementClass(option)" aria-hidden="true"></i>
                </a>
                <a
                  :disabled="editMode"
                  href="#"
                  v-else
                  @click.prevent="editMode? '#':deleteElements(index)"
                >
                  <i
                    aria-hidden="true"
                    :class="option.isActive? 'fas fa-trash AddDelBtn': 'fas fa-trash AddDelBtn custom-delete-btn'"
                  ></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import modelService from '../services/model-service';
import { ServiceInfoUrls, MasterUrls } from '../../../shared/constants/urls';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

import VALIDATION_MESSAGES from '../../../shared/constants/messages';

export default {
  props: {
    itemIndex: {
      type: Number
    }
  },
  name: 'PMShedule',
  data() {
    return {
      modelId: null,
      recordsObj: {
        modelId: null,
        modelPMServiceInfo: [
          {
            id: 0,
            duration: null,
            hours: null,
            isActive: true
          }
        ]
      },
      validationsMessages: VALIDATION_MESSAGES,
      opertaionMode: 'none',
      disableRow: [],
      persistData: [],
      editMode: true,
      isError: false,
      duplicateIndex: null,
      validOption1: null,
      validOption2: null,
      durationOpt: [],
      oldModelOVPSchedule: {}
    };
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    // Once Edit is clicked we can add/delete new records and also toggle existing redords
    onEditClicked() {
      this.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    // Will allow to add elements if the current input element is non-empty
    addElements(index) {
      // Add elements only in case if first element option property is not empty
      if (this.recordsObj.modelPMServiceInfo[index].duration || this.recordsObj.modelPMServiceInfo[index].hours) {
        this.recordsObj.modelPMServiceInfo.push({
          id: 0,
          duration: null,
          hours: null,
          isActive: true
        });
      }
    },
    // this will check the duplicate entries
    validateOptionFields(value, index) {
      this.validOption1 = null;
      if (value) {
        // eslint-disable-next-line no-useless-escape
        if (!/^[a-zA-Z0-9\-_,.#\s]{0,200}$/.test(value)) {
          this.validOption1 = index;
        }
      }
    },
    // It disables the elements on clicking delete button
    deleteElements(index) {
      if (this.recordsObj.modelPMServiceInfo[index] !== undefined) {
        if (this.recordsObj.modelPMServiceInfo[index].id !== 0) {
          this.recordsObj.modelPMServiceInfo[index].isActive = !this.recordsObj.modelPMServiceInfo[index].isActive;
        } else {
          this.recordsObj.modelPMServiceInfo.splice(index, 1);
        }
      }
    },
    // dynamic class options
    toggleOptions(option, index) {
      let optionClass = 'form-control';
      if (this.recordsObj.modelPMServiceInfo.length - 1 === index && this.recordsObj.modelPMServiceInfo[index].id === 0) {
        optionClass = 'form-control';
      } else {
        optionClass = 'form-control form-control-view';
      }
      return optionClass;
    },
    addElementClass(option) {
      let delClass = 'icon-model-options AddDelBtn';
      if (option.duration === null && (option.hours === null || option.hours === '')) {
        delClass = 'icon-model-options AddDelBtn disable-btn';
      }
      return delClass;
      // editMode?:'icon-model-options AddDelBtn disable-btn':option.isActive? 'icon-model-options AddDelBtn':''
    },
    // Save and update all records
    handleSubmit() {
      if (
        this.recordsObj.modelPMServiceInfo.length === 1 &&
        this.recordsObj.modelPMServiceInfo[0].duration === null &&
        this.recordsObj.modelPMServiceInfo[0].hours === null
      ) {
        return;
      }
      this.recordsObj.modelPMServiceInfo = this.recordsObj.modelPMServiceInfo.filter(item => item.duration !== null || item.hours !== null);

      // call API to save data to DB
      if (this.validOption1 === null) {
        this.recordsObj.userId = 1;
        const delData = this.recordsObj.modelPMServiceInfo.filter(item => item.isActive === false);

        this.deletedRecord = delData.length;
        if (this.deletedRecord !== 0) {
          // eslint-disable-next-line no-alert
          const answer = window.confirm(`${this.deletedRecord} ${this.validationsMessages.INPUTDELETERECORD}`);
          if (answer) {
            this.callAPIToSaveData();
          } else {
            this.recordsObj.modelPMServiceInfo.push({
              id: 0,
              duration: null,
              hours: null,
              isActive: true
            });
          }
        } else {
          this.callAPIToSaveData();
        }
      }
    },
    checkEditedModelOption() {
      this.noDatatoSave = false;
      // this.oldModelOptions = JSON.parse(JSON.stringify(this.modelOptions));
      const editedArray = [];
      // add newly added data
      const newlyAddedData = this.recordsObj.modelPMServiceInfo.filter(item => item.id === 0);
      if (newlyAddedData) {
        editedArray.push(...newlyAddedData);
      }
      // add deleted data
      const delData = this.recordsObj.modelPMServiceInfo.filter(item => item.isActive === false);
      if (delData) {
        editedArray.push(...delData);
      }
      // add edited data
      const editedData = this.recordsObj.modelPMServiceInfo.filter((item, index) => this.checkEdits(item, index));
      if (editedData) {
        editedArray.push(...editedData);
      }
      if (editedArray.length > 0 && (editedArray[0].hour !== null || editedArray[0].duration !== null)) {
        this.recordsObj.modelPMServiceInfo = editedArray;
        this.noDatatoSave = false;
        console.log(this.recordsObj.modelPMServiceInfo, 'this.recordsObj.modelPMServiceInfo');
        this.callAPIToSaveData();
      } else {
        this.noDatatoSave = true;
      }
    },
    checkEdits(item, index) {
      if (item.hours !== '' && item.isActive && this.oldModelOVPSchedule.modelPMServiceInfo.length > index) {
        if (
          this.oldModelOVPSchedule.modelPMServiceInfo[index].duration !== item.duration ||
          this.oldModelOVPSchedule.modelPMServiceInfo[index].hours !== item.hours
        ) {
          return true;
        }
      }
      return false;
    },
    callAPIToSaveData() {
      // eslint-disable-next-line arrow-parens
      modelService.postModelsDataAction(ServiceInfoUrls.POST_PM_SHEDULE, this.recordsObj).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.editMode = true;
          this.$emit('togglePanel', this.editMode, this.itemIndex);
          // again re-render the UI from the response fom the API
          this.getRecordsfromAPI(this.modelId);
          showToast('success');
        } else {
          // eslint-disable-next-line no-console
          console.log('Internal server error');
        }
      });
    },
    // Get all records from API call
    getRecordsfromAPI(id) {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ServiceInfoUrls.GET_PM_SHEDULE}?modelId=${id}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.recordsObj = res.data.data;
          if (this.recordsObj && this.recordsObj.modelPMServiceInfo) {
            this.oldModelOVPSchedule = JSON.parse(JSON.stringify(this.recordsObj));
            this.recordsObj.modelPMServiceInfo.push({
              id: 0,
              duration: null,
              hours: null,
              isActive: true
            });
          }
        }
      });
    },
    // cancel will revert whole edited data to previous state
    async onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.editMode = true;
        await this.getRecordsfromAPI(this.modelId);
        this.validOption1 = null;
        this.validOption2 = null;
        this.isError = false;
        this.$emit('togglePanel', this.editMode, this.itemIndex);
      }
      return false;
    },
    async onChildCancelClicked() {
      this.editMode = true;
      await this.getRecordsfromAPI(this.modelId);
      this.validOption1 = null;
      this.validOption2 = null;
      this.isError = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    }
  },
  // Call API to fetch option data if OperationMode is 'edit' it will disable the form
  async created() {
    this.modelId = await this.$store.getters.getModelId;
    this.editMode = true;
    await this.getRecordsfromAPI(this.modelId);
    // eslint-disable-next-line arrow-parens
    await modelService.getModelRequest(`${MasterUrls.getMasterMockup}?identifier=Duration`).then(res => {
      if (res) {
        this.durationOpt = res.data.data;
      }
    });
  }
};
</script>

<style scoped >
</style>