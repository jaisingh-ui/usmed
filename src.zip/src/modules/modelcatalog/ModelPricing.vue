<template>
  <div id="content">
    <div class="container-fluid">
      <ModuleHeader :headerData="result"></ModuleHeader>
      <ModelPrice></ModelPrice>
    </div>
  </div>
</template>
<script>
import ModuleHeader from '../../components/ModuleHeader';
import ModelPrice from './model-price/ModelPrice';
import modelService from './services/model-service';
import { ModelUrls } from './../../shared/constants/urls';

export default {
  data() {
    return {
      headerData: {
        head: 'Model Pricing',
        id: 0,
        name: '',
        status: ''
      }
    };
  },
  components: {
    ModelPrice,
    ModuleHeader
  },
  methods: {
    getGeneralDetailData(id) {
      if (id) {
        // eslint-disable-next-line arrow-parens
        modelService.getModelRequest(`${ModelUrls.modelGeneralData}?modelId=${id}`).then(res => {
          if (res.data.apiResponseStatus !== 'Failed') {
            const result = res.data.data;
            this.headerData.id = id;
            this.headerData.name = result.modelName;
            this.headerData.status = result.isActive ? 'Active' : 'Inactive';
          }
        });
      }
    }
  },
  computed: {
    result() {
      return this.headerData;
    }
  },
  created() {
    this.getGeneralDetailData(this.$store.getters.getModelId);
  }
};
</script>