<template>
  <!-- right pannel section -->
  <div id="content">
    <div class="container-fluid">
      <ModuleHeader :headerData="result"></ModuleHeader>
      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <div id="accordion" v-if="componentToRender.subMenuModules.length > 0">
              <template v-for="(subModule, index) in componentToRender.subMenuModules">
                <component
                  v-if="subModule.subMenuModuleVisible"
                  :is="subModule.subMenuModuleName"
                  :subModuleInfo="subModule"
                  :key="subModule.subMenuModuleId"
                  :ref="'model'+index"
                  :itemIndex="index"
                  @togglePanel="panelToggle"
                  @panelClicked="onClicked"
                ></component>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ModuleHeader from '../../components/ModuleHeader';
import Documentation from './model-documentation/Documentation';
import VideoLink from './model-documentation/VideoLink';

import modelService from './services/model-service';
import { ModelUrls } from './../../shared/constants/urls';
import VALIDATION_MESSAGES from '../../shared/constants/messages';

export default {
  components: {
    ModuleHeader,
    Documentation,
    VideoLink
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      componentToRender: [],
      showPanels: true,
      refId: null,
      headerData: {
        head: 'Documentation',
        id: 0,
        name: '',
        status: ''
      }
    };
  },
  methods: {
    panelToggle(editMode, itemIndex) {
      this.refId = `model${itemIndex}`;
      if (editMode) {
        this.showPanels = true;
      } else {
        this.showPanels = false;
      }
    },
    onClicked(event) {
      if (!this.showPanels) {
        // eslint-disable-next-line no-alert
        const answer = window.confirm(this.validationsMessages.WARNINGPARTIALFILLEDPANEL);
        if (!answer) {
          event.preventDefault();
          event.stopPropagation();
          // eslint-disable-next-line no-param-reassign
          event.returnValue = '';
        } else {
          this.$refs[this.refId][0].onParentCancelClicked();
          this.showPanels = true;
        }
      }
    },

    getGeneralDetailData(id) {
      if (id) {
        // eslint-disable-next-line arrow-parens
        modelService.getModelRequest(`${ModelUrls.modelGeneralData}?modelId=${id}`).then(res => {
          const result = res.data.data;
          this.headerData.id = id;
          this.headerData.name = result.modelName;
          this.headerData.status = result.isActive ? 'Active' : 'Inactive';
          // localStorage.setItem('header', JSON.stringify(this.headerData));
          // console.log(res, 'fffffffffffffffffffff');
        });
      }
    }
  },
  computed: {
    result() {
      return this.headerData;
    }
  },
  created() {
    this.componentToRender = this.$store.getters.getSubMenuModulesFromLeftMenuConfigs(2, 8);
    if (!isNaN(this.$store.getters.getModelId)) {
      this.showPanels = true;
    }
    this.getGeneralDetailData(this.$store.getters.getModelId);
  }
};
</script>
<style>
.error {
  border: 1px solid red;
}
.error-message {
  color: red;
  font-size: 14px;
}
.disabledbutton {
  pointer-events: none;
  opacity: 0.4;
}
</style>
