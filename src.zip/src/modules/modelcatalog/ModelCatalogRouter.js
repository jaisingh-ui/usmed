import ModelCatalog from './ModelCatalog';
import ModelDetail from './ModelDetail';
// import ModelAdd from './model-details/ModelAdd';
import ModelPricing from './ModelPricing';
import ModelOption from './ModelOption';
import AssociateModelAndParts from './AssociateModelAndParts';
import ServiceInformation from './ServiceInformation';
import ModelDocumentation from './ModelDocumentation';
import ImportModelPricing from './model-price/ImportModelPricing';

export default [
  {
    path: '/model-catalog/model-details',
    name: 'ModelDetail',
    component: ModelDetail,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/model-catalog/model-details/:id',
    name: 'ModelViewDetail',
    component: ModelDetail,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/model-catalog/model-options/',
    name: 'ModelOption',
    component: ModelOption,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/model-catalog/model-options/:id',
    name: 'ModelOption',
    component: ModelOption,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/model-catalog/model-pricing',
    name: 'ModelPricing',
    component: ModelPricing,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/model-catalog/search-view-model-list',
    name: 'ModelCatalog',
    component: ModelCatalog,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/model-catalog/associated-models',
    name: 'AssociateModelAndParts',
    component: AssociateModelAndParts,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/model-catalog/model-service-info',
    name: 'ServiceInformation',
    component: ServiceInformation,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/model-catalog/model-documentation',
    name: 'Documentation',
    component: ModelDocumentation,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/model-catalog/import-model-pricing',
    name: 'ImportModelPricing',
    component: ImportModelPricing,
    meta: {
      requiresAuth: true
    }
  }
];
