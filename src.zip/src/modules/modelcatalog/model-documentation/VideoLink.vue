<template>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseThree"
          aria-expanded="false"
          aria-controls="collapseThree"
          @click="clickPanel"
        >Video Link</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseThree"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseThree"
      class="collapse"
      aria-labelledby="headingThree"
      data-parent="#accordion"
    >
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid #efefef;">
          <div class="col-md-12 text-right mb-1 mt-1">
            <div class="workingBtn" v-if="editMode">
              <button type="button" class="edit-btn" @click.prevent="onEditClicked">Edit</button>
            </div>
            <div v-if="!editMode">
              <template v-if="enableSaveBtn()">
                <button
                  type="button"
                  :class="enableSaveBtn()?  'save-btn mr-1' : 'save-btn mr-1 custom-disabled'"
                  @click.prevent="onSaveClicked"
                >Save</button>
              </template>
              <template v-else>
                <button
                  type="button"
                  :class="enableSaveBtn()?  'save-btn mr-1' : 'save-btn mr-1 custom-disabled'"
                >Save</button>
              </template>
              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </div>
          </div>
        </div>

        <div v-for="(video, index) in videoList.videoLink" :key="index">
          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <label>
                  Video Title
                  <i class="fa fa-info-circle" aria-hidden="true" title="Video Title"></i>
                </label>
                <input
                  :disabled="editMode"
                  class="form-control"
                  placeholder="Video Title"
                  v-model="video.videoTitle"
                />
              </div>
              <p
                class="error-message"
                v-if="!$v.videoList.videoLink.$each[index].videoTitle.required && submitted"
              >{{validationsMessages.REQUIRED}}</p>
              <p
                class="error-message"
                v-if="!$v.videoList.videoLink.$each[index].videoTitle.alphaNumSpecialValidationRuleTitle && submitted"
              >{{validationsMessages.ALPHA_SPECIAL_CHARACTER_RULE_TITLE}}</p>
            </div>
            <div class="col-md-2">
              <div class="form-group">
                <label>
                  Video Category
                  <i
                    class="fa fa-info-circle"
                    aria-hidden="true"
                    title="Video Category"
                  ></i>
                </label>
                <select class="form-control" :disabled="editMode" v-model="video.videoCategoryID">
                  <option value>Select</option>
                  <option
                    v-for="category in videoCategoryOptions"
                    :value="category.entityID"
                  >{{category.entityName}}</option>
                </select>
                <p
                  class="error-message"
                  v-if="!$v.videoList.videoLink.$each[index].videoCategoryID.required && submitted"
                >{{validationsMessages.REQUIRED}}</p>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label>
                  URL
                  <i class="fa fa-info-circle" aria-hidden="true" title="URL"></i>
                </label>
                <input
                  :disabled="editMode"
                  type="text"
                  class="form-control"
                  placeholder="Video URL"
                  v-model="video.videoURL"
                />
              </div>
              <p
                class="error-message"
                v-if="!$v.videoList.videoLink.$each[index].videoURL.required && submitted"
              >{{validationsMessages.REQUIRED}}</p>
              <p
                class="error-message"
                v-if="!$v.videoList.videoLink.$each[index].videoURL.url && submitted"
              >{{validationsMessages.URL}}</p>
            </div>

            <div class="col-md-1 text-left">
              <div class="form-group mt-4 pt-1">
                <div v-if="index === videoList.videoLink.length-1">
                  <a
                    :disabled="editMode"
                    href="#"
                    @click.prevent="editMode? '#':addElements(index)"
                  >
                    <i :class="addElementClass(video)" aria-hidden="true"></i>
                  </a>
                </div>
                <div v-else>
                  <a
                    :disabled="editMode"
                    href="#"
                    @click.prevent="editMode? '#':deleteElements(index)"
                  >
                    <i
                      aria-hidden="true"
                      :class="{'fas fa-trash AddDelBtn':true, 'custom-delete-btn': !video.isActive}"
                    ></i>
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-11">
              <div class="form-group">
                <label>
                  Description
                  <i class="fa fa-info-circle" aria-hidden="true" title="Description"></i>
                </label>
                <textarea
                  :disabled="editMode"
                  class="form-control"
                  id="exampleFormControlTextarea1"
                  rows="3"
                  v-model="video.description"
                ></textarea>
                <p
                  class="error-message"
                  v-if="!$v.videoList.videoLink.$each[index].description.alphaNumSpecialValidation && submitted"
                >{{validationsMessages.ALPHA_SPECIAL_CHARACTER}}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import modelService from '../services/model-service';

import { ModelUrls, MasterUrls } from '../../../shared/constants/urls';
import { required, url, helpers, alphaNum, requiredIf } from 'vuelidate/lib/validators';
import { PatternValidation } from '../../../shared/constants/pattern-validation';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { showToast } from '../../../shared/services/toast-service';

const alphaNumSpecialValidationRuleTitle = helpers.regex('alphaNumSpecialValidationRuleTitle', PatternValidation.alphaNumSpecialValidationRuleTitle);
const alphaNumSpecialValidation = helpers.regex('alphaNumSpecialValidation', PatternValidation.alphaNumSpecialValidation);

export default {
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      menuId: 2,
      opertaionMode: 'none',
      videoList: {
        modelId: null,
        videoLink: [
          {
            id: 0,
            videoTitle: '',
            videoCategoryID: null,
            videoURL: '',
            description: '',
            isActive: true
          }
        ]
      },
      submitted: false,
      videoCategoryOptions: [],
      oldVideoList: {},
      modelId: null,
      editMode: true, // this should be false in case of Add mode
      isError: false,
      duplicateIndex: [],
      emptyIndex: [],
      validvideo: null,
      regexValidation: [],
      noDatatoSave: false
    };
  },
  validations: {
    videoList: {
      videoLink: {
        $each: {
          videoTitle: {
            alphaNumSpecialValidationRuleTitle,
            required: requiredIf(() => {
              if (
                this.videoList &&
                this.videoList.videoLink.length > 0 &&
                this.videoList.videoLink[this.videoList.videoLink.length - 1].videoTitle.trim() === ''
              ) {
                return false;
              }
              return true;
            })
          },
          videoCategoryID: {
            required: requiredIf(() => {
              if (
                this.videoList &&
                this.videoList.videoLink.length > 0 &&
                this.videoList.videoLink[this.videoList.videoLink.length - 1].videoCategoryID === '' &&
                this.videoList.videoLink[this.videoList.videoLink.length - 1].videoCategoryID === null
              ) {
                return false;
              }
              return true;
            })
          },
          videoURL: {
            url,
            required: requiredIf(() => {
              if (
                this.videoList &&
                this.videoList.videoLink.length > 0 &&
                this.videoList.videoLink[this.videoList.videoLink.length - 1].videoURL.trim() === ''
              ) {
                return false;
              }
              return true;
            })
          },
          description: {
            alphaNumSpecialValidation
          }
        }
      }
    }
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    addElements(index) {
      // Add elements only in case if first element is added
      if (this.videoList.videoLink[index].videoTitle !== '' && !this.isError && this.validvideo === null) {
        this.videoList.videoLink.push({
          id: 0,
          videoTitle: '',
          videoCategoryID: null,
          videoURL: '',
          description: '',
          isActive: true
        });
      }
    },
    async deleteElements(index) {
      if (this.videoList.videoLink[index] !== undefined) {
        if (this.videoList.videoLink[index].id !== 0) {
          this.videoList.videoLink[index].isActive = !this.videoList.videoLink[index].isActive;
        } else {
          this.videoList.videoLink.splice(index, 1);
          if (this.videoList.videoLink.length === 0) {
            this.videoList.videoLink.push({
              id: 0,
              videoTitle: '',
              videoCategoryID: '',
              videoURL: '',
              description: '',
              isActive: true
            });
          }
        }
      }
    },
    // Save button will only be available to click once there is no error in form
    // and first input element is non empty
    enableSaveBtn() {
      if (this.isError) {
        return false;
      } else if (this.videoList.videoLink.length === 1 && this.videoList.videoLink[0].videoTitle.trim() === '') {
        return false;
      } else {
        return true;
      }
    },
    // Remove last row from the list
    removeLastRow(videodata) {
      if (videodata.videoTitle === '' && videodata.videoCategoryID === null && videodata.videoURL === '' && videodata.description === '') {
        this.videoList.videoLink.splice(this.videoList.videoLink.length - 1, 1);
      }
    },
    onSaveClicked() {
      // Remove empty last row before checking validation
      this.removeLastRow(this.videoList.videoLink[this.videoList.videoLink.length - 1]);
      const delRecords = this.videoList.videoLink.filter(item => item.isActive === false);
      if (delRecords.length > 0) {
        // eslint-disable-next-line no-alert
        const answer = window.confirm(`${delRecords.length} ${this.validationsMessages.INPUTDELETERECORD}`);
        if (answer) {
        } else {
          this.videoList.videoLink.push({
            id: 0,
            videoTitle: '',
            videoCategoryID: '',
            videoURL: '',
            description: '',
            isActive: true
          });
          return;
        }
      }
      this.submitted = true;
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      }

      this.videoList.userId = 1;
      // eslint-disable-next-line arrow-parens
      modelService.postModelRequest(ModelUrls.postVideoListModelData, this.videoList).then(res => {
        if (res) {
          this.editMode = true;
          this.$emit('togglePanel', this.editMode, this.itemIndex);
          // again re-render the UI from the response fom the API
          this.callAPIToGetvideos(this.menuId, this.modelId);
          this.submitted = false;
          showToast('success');
        } else {
          // eslint-disable-next-line no-console
          this.submitted = false;
        }
      });
    },
    onEditClicked() {
      this.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.editMode = true;
        this.isError = false;
        this.submitted = false;
        this.callAPIToGetvideos(this.menuId, this.modelId);
        this.validvideo = null;
        this.$emit('togglePanel', this.editMode, this.itemIndex);
      }
      return false;
    },
    onParentCancelClicked() {
      this.editMode = true;
      this.isError = false;
      this.submitted = false;
      this.callAPIToGetvideos(this.menuId, this.modelId);
      this.validvideo = null;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    callAPIToGetvideos(MenuId, RefID) {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.getVideoListModelData}?menuId=${MenuId}&refId=${RefID}`).then(res => {
        this.videoList = res.data.data;
        console.log(this.videoList);
        if (this.videoList && this.videoList.videoLink) {
          this.videoList.videoLink.push({
            id: 0,
            videoTitle: '',
            videoCategoryID: null,
            videoURL: '',
            description: '',
            isActive: true
          });
        }
        this.editMode = true;
      });
    },
    handleEditSaveMode() {
      if (this.$store.getters.getOperationMode === 'edit') {
        this.editMode = true;
      } else {
        this.editMode = false;
      }
    },
    addElementClass(video) {
      let delClass = 'icon-model-options AddDelBtn';
      if (video.videoTitle.trim() === '' || this.isError) {
        delClass = 'icon-model-options AddDelBtn disable-btn';
      }
      return delClass;
    },
    getMasterVideoCategoryoptions() {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${MasterUrls.getMasterMockup}?identifier=VideoCategory&id=${this.menuId}`).then(res => {
        this.videoCategoryOptions = res.data.data.VideoCategory;
      });
    }
  },
  async created() {
    this.modelId = this.$store.getters.getModelId;
    await this.getMasterVideoCategoryoptions();
    await this.callAPIToGetvideos(this.menuId, this.modelId);
  }
};
</script>
<style scoped>
.first-div {
  margin-top: 30px;
}
.custom-disabled-check {
  pointer-events: none;
  background-color: #e9ecef;
}
.disabled {
  pointer-events: none;
  opacity: 1;
  cursor: not-allowed;
  background-color: #e9ecef;
}
</style>