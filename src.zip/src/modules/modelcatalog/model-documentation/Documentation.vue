<template>
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button
          class="btn btn-link"
          data-toggle="collapse"
          data-target="#collapseOne"
          aria-expanded="true"
          aria-controls="collapseOne"
          @click="clickPanel"
        >Documentation</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseOne"
          aria-expanded="true"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseOne"
      class="collapse show"
      aria-labelledby="headingOne"
      data-parent="#accordion"
      style
    >
      <div class="card-body">
        <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
          <span class="k-loading-text">Loading...</span>
          <div class="k-loading-image">
            <div class="k-loading-color"></div>
          </div>
        </div>
        <div class="row" style="border-bottom: 1px solid #efefef;">
          <div class="col-md-12 text-right mb-1 mt-1">
            <div v-if="editMode">
              <button type="button" class="edit-btn" @click.prevent="onEditClicked">Edit</button>
            </div>
            <div v-else>
              <button type="button" class="save-btn mr-1" @click.prevent="handleSubmit">Save</button>

              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </div>
          </div>
        </div>
        <div class="row mt-4">
          <div class="col-lg-4 col-md-12 text-left contractslist">
            <DocumentsTable ref="doc"></DocumentsTable>
          </div>
          <div class="col-lg-8 col-md-12">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label>
                    Documentation Title
                    <i
                      class="fa fa-info-circle"
                      aria-hidden="true"
                      title="Documentation Title"
                    ></i>
                  </label>
                  <input
                    :disabled="editMode"
                    type="text"
                    class="form-control"
                    v-model="Modeldata.documentTitle"
                  />
                  <p
                    v-if="submitted && !$v.Modeldata.documentTitle.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
              <div class="col-md-6 text-left">
                <div class="form-group">
                  <label>
                    Documentation Category
                    <i
                      class="fa fa-info-circle"
                      aria-hidden="true"
                      title="Documentation Category"
                    ></i>
                  </label>
                  <select
                    v-model="Modeldata.documentationCategoryId"
                    class="form-control"
                    :disabled="editMode"
                  >
                    <option value>Select Category</option>
                    <option
                      v-bind:value="mvalue.entityID"
                      v-for="mvalue in CategoryOpt"
                    >{{ mvalue.entityName }}</option>
                  </select>
                  <p
                    v-if="submitted && !$v.Modeldata.documentationCategoryId.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label>
                    Description
                    <i class="fa fa-info-circle" aria-hidden="true" title="Desription"></i>
                  </label>
                  <textarea
                    class="form-control"
                    rows="3"
                    v-model="Modeldata.description"
                    maxlength="500"
                    :disabled="editMode"
                  ></textarea>
                  <p
                    v-if="!$v.Modeldata.description.alphaWithSpecialChar"
                    class="error-message"
                  >{{validationMessages.INVALIDMODELOPTION}}</p>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-lg-6 col-md-6 text-left">
                <div class="form-group">
                  <div class="radioSection">
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        id="customRadioInline1"
                        v-model="uploadType"
                        class="custom-control-input"
                        value="uploaddoc"
                        checked
                        :disabled="editMode"
                      />
                      <label class="custom-control-label" for="customRadioInline1">Upload</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input
                        type="radio"
                        id="customRadioInline2"
                        v-model="uploadType"
                        class="custom-control-input"
                        value="scandoc"
                        :disabled="editMode"
                      />
                      <label class="custom-control-label" for="customRadioInline2">Scan &amp; Upload</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div v-if="uploadType === 'scandoc'" class="row mt-1 mb-1">
              <div class="col-lg-4 col-md-8 text-left">
                <div class="form-group">
                  <label>
                    Scanner
                    <i class="fa fa-info-circle" aria-hidden="true" title="Scanner"></i>
                  </label>
                  <select id="inputState" class="form-control" :disabled="editMode">
                    <option>Select</option>
                    <option>Scanner 1</option>
                    <option>Scanner 2</option>
                    <option>Scanner 3</option>
                    <option>Scanner 4</option>
                  </select>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 text-left mt-2">
                <br />
                <span class="FormworkingBtn">
                  <a href="javascript:void(0)">Scan</a>
                </span>
              </div>
            </div>
            <div class="row mt-1 mb-1">
              <div class="col-lg-4 col-md-8 text-left">
                <div class="form-group">
                  <label>Upload Document</label>&nbsp;
                  <input
                    type="file"
                    class="form-control"
                    id="file"
                    ref="file"
                    @change="onFileChange"
                    :disabled="editMode"
                  />
                  <p
                    v-if="submitted && !$v.Modeldata.file.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
            </div>
            <div v-if="uploadType === 'scandoc'" class="row">
              <div class="col-md-12 text-left">
                <div class="imageArea" style="margin-bottom:5px; height:500px;">
                  <i class="icon-delete"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
import Vue from 'vue';
import DocumentsTable from '../../../components/DocumentsTable';
import { required, requiredIf, helpers } from 'vuelidate/lib/validators';
import MESSAGES from '../../../shared/constants/messages';
import baseService from '../../../shared/services/base-service';
import modelService from '../services/model-service';
import { DocumentUrls, MasterUrls } from '../../../shared/constants/urls';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import filesMixin from '../../../shared/MixinLib/files-functions';
import { showToast } from '../../../shared/services/toast-service';
const alphaWithSpecialChar = helpers.regex('alphaWithSpecialChar', /^[a-zA-Z0-9' , . _ # -]*$/);
export default {
  name: 'ModelDocumentation',
  props: {
    itemIndex: {
      type: Number
    }
  },
  components: {
    DocumentsTable
  },
  mixins: [filesMixin],
  data() {
    return {
      modelId: null,
      submitted: false,
      isDisable: false,
      showLoader: false,
      uploadType: 'uploaddoc',
      Modeldata: {
        documentTitle: '',
        documentationCategoryId: '',
        description: '',
        file: ''
      },
      validationMessages: MESSAGES,
      CategoryOpt: [],
      editMode: true,
      menuId: 2
    };
  },
  validations: {
    Modeldata: {
      documentTitle: { required },
      documentationCategoryId: { required },
      file: {
        required: requiredIf(vm => {
          if (vm.file.name === undefined) {
            return true;
          }
          return false;
        })
      },
      description: { alphaWithSpecialChar }
    }
  },
  created() {
    this.modelId = this.$store.getters.getModelId;
    this.getDocumentData();
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    /* Handles a change on the file upload */
    onFileChange(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) {
        return;
      }
      /* Maximun file size mixin function */
      const isValidSize = this.sizeFileValidation(files);
      if (!isValidSize) {
        this.$refs.file.value = '';
        return;
      }

      this.Modeldata.file = files[0];
    },
    handleSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      this.$v.$touch();
      console.log(this.$v.$invalid);
      if (this.$v.$invalid) {
        return;
      }

      this.saveDocumentAPI();
    },
    getDocumentData() {
      modelService.getModelRequest(`${MasterUrls.getMasterMockup}?identifier=DocumentationCategory&id=${this.menuId}`).then(res => {
        if (res) {
          this.CategoryOpt = res.data.data.DocumentationCategory;
          this.editMode = true;
          this.$emit('togglePanel', this.editMode, this.itemIndex);
        }
      });
    },
    saveDocumentAPI() {
      this.showLoader = true;
      this.isDisable = true;
      const formData = new FormData();
      formData.append('file', this.Modeldata.file);
      formData.append('id', this.menuId); // menuId
      formData.append('refID', this.modelId);
      formData.append('documentTitle', this.Modeldata.documentTitle);
      formData.append('documentationCategoryId', this.Modeldata.documentationCategoryId);
      formData.append('description', this.Modeldata.description);

      formData.append('userId', 1);

      baseService
        .fileUploadRequest(`${DocumentUrls.POST_DOCUMENT}`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
        .then(res => {
          this.showLoader = false;
          this.submitted = false;
          this.editMode = true;
          this.$refs.doc.editMode = true;
          if (res.data.apiResponseStatus !== 'Failed') {
            showToast('success');
            this.Modeldata.documentTitle = '';
            this.Modeldata.documentationCategoryId = '';
            this.Modeldata.description = '';
            this.Modeldata.file = '';
            this.$refs.file.value = '';
            this.$v.$reset();
            this.$refs.doc.getDocumentList(this.menuId, this.modelId);
            this.$emit('togglePanel', this.editMode, this.itemIndex);
          }
        })
        .catch(error => {
          this.showLoader = false;
        });
    },
    onEditClicked() {
      this.editMode = false;
      this.$refs.doc.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.editMode = true;
        this.submitted = false;
        this.$refs.doc.editMode = true;
        this.Modeldata.documentTitle = '';
        this.Modeldata.documentationCategoryId = '';
        this.Modeldata.description = '';
        this.Modeldata.file = '';
        this.$refs.file.value = '';
        this.$v.$reset();
      }
      return false;
    },
    onParentCancelClicked() {
      this.editMode = true;
      this.submitted = false;
      this.$refs.doc.editMode = true;
      this.$v.$reset();
      this.Modeldata.documentTitle = '';
      this.Modeldata.documentationCategoryId = '';
      this.Modeldata.description = '';
      this.Modeldata.file = '';
      this.$refs.file.value = '';
      this.$v.$reset();
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    }
  }
};
</script>