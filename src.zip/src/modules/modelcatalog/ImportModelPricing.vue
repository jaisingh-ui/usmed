<template>
  <div id="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <h1 class="pageName">Import Pricing for Models</h1>
        </div>
      </div>

      <div class="row mt-">
        <!-- <form @submit="onSubmit"> -->
        <div class="col-lg-5 col-md-5 text-left">
          <div class="form-group">
            <label class="LabelForm">Browse file to upload</label>&nbsp;
            <input
              type="file"
              ref="file"
              class="form-control"
              accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
            />
          </div>
        </div>
        <div class="col-lg-1 col-md-1 text-left mt-4">
          <span class="FormworkingBtn mt-3">
            <button @click="onSubmit">Upload</button>
            <!-- <a href="javascript:void(0)">Upload</a> -->
          </span>
        </div>
        <!-- </form> -->
        <div class="col-lg-6 col-md-6 text-right mt-5">
          <button type="button" class="btn save-btn mr-2">Save</button>
          <button type="button" class="btn cancel-btn">Cancel</button>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="col-lg-12 col-md-12 text-center contractslist" style="min-height:100px;">
            <DataTable
          :myColumns="myColumns"
          :myData="myData"
        ></DataTable>
            <!-- <br />No data to display -->
          </div>
        </div>  
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <div id="accordion">
              <div class="card">
                <div class="card-header" id="headingThree">
                  <h5 class="mb-0">
                    <button
                      class="btn btn-link"
                      data-toggle="collapse"
                      data-target="#collapseThree"
                      aria-expanded="true"
                      aria-controls="collapseThree"
                    >Errors</button>
                  </h5>
                  <div class="rightInfotext">
                    <i
                      class="fa fa-angle-down"
                      data-toggle="collapse"
                      data-target="#collapseThree"
                      aria-expanded="true"
                    ></i>
                  </div>
                </div>
                <div
                  id="collapseThree"
                  class="collapse"
                  aria-labelledby="headingThree"
                  data-parent="#accordion"
                  style
                >
                  <div class="card-body">
                    <div class="card-body">
                      <div class="row">
                        <div class="col-md-12">
                          <div class="fullPagetable">
                            <div class="row">
                              <div class="col-md-12">
                                <DataTable
                                  :myColumns="errorColumns"
                                  :myData="errordata"
                                ></DataTable>
                                <!-- <div class="table-responsive">
                                  <table class="table softwareTable">
                                    <thead>
                                      <tr>
                                        <th>
                                          <div class="headText text-nowrap">
                                            <span>Row</span>
                                            <i class="icon-filter-filled-tool-symbol"></i>
                                          </div>
                                          <div class="form-group">
                                            <input type="text" class="form-control" id placeholder />
                                          </div>
                                        </th>
                                        <th>
                                          <div class="headText text-nowrap">
                                            <span>ID</span>
                                            <i class="icon-filter-filled-tool-symbol"></i>
                                          </div>
                                          <div class="form-group">
                                            <input type="text" class="form-control" id placeholder />
                                          </div>
                                        </th>
                                        <th>
                                          <div class="headText text-nowrap">
                                            <span>Error Details</span>
                                            <i class="icon-filter-filled-tool-symbol"></i>
                                          </div>
                                          <div class="form-group">
                                            <input type="text" class="form-control" id placeholder />
                                          </div>
                                        </th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td class="tcolor2">0</td>
                                        <td>112225</td>
                                        <td>Some Error details Here</td>
                                      </tr>
                                      <tr>
                                        <td class="tcolor2">2</td>
                                        <td>354357</td>
                                        <td>Some Error details Here</td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </div> -->
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
import DataTable from '../../components/DataTable';
export default {
  components: {
    DataTable
  },

  data() {
    return {
      dataItemsSource: [],
      myData: [
        {modelID:1, modelCommonName:'Philips v60 Bipap', monthlyCost:100, list:3000, web:200, dealer:300},
        {modelID:2, modelCommonName:'Philips v70 Bipap', monthlyCost:200, list:4000, web:300, dealer:400},
        {modelID:3, modelCommonName:'Philips v80 Bipap', monthlyCost:300, list:5000, web:400, dealer:500},
        {modelID:4, modelCommonName:'Philips v90 Bipap', monthlyCost:400, list:6000, web:500, dealer:600},
        {modelID:5, modelCommonName:'Philips v10 Bipap', monthlyCost:500, list:7000, web:600, dealer:700},
        {modelID:6, modelCommonName:'Philips v20 Bipap', monthlyCost:600, list:8000, web:700, dealer:800},
        {modelID:7, modelCommonName:'Philips v30 Bipap', monthlyCost:700, list:9000, web:800, dealer:900}
      ],
      errordata: [
        {errorID:1, row:1, id:1001, errorDetails:'data not find'},
        {errorID:2, row:2, id:1002, errorDetails:'data not find'},
        {errorID:3, row:3, id:1003, errorDetails:'data not find'},
        {errorID:4, row:4, id:1004, errorDetails:'data not find'},
        {errorID:5, row:5, id:1005, errorDetails:'data not find'},
        {errorID:6, row:6, id:1006, errorDetails:'data not find'},
        {errorID:7, row:7, id:1007, errorDetails:'data not find'},
        {errorID:8, row:8, id:1008, errorDetails:'data not find'}
      ],  
      // myColumns getting used as column for grid
      myColumns: [
        { field: 'modelID', hidden: true },
        { field: 'modelCommonName', title: 'Model Common Name' },
        { field: 'monthlyCost', title: 'Monthly	Cost' },
        { field: 'list', title: 'List' },
        { field: 'web', title: 'Web' },
        { field: 'dealer', title: 'Dealer' },
      ],
      errorColumns: [
        { field: 'errorID', hidden: true },
        { field: 'row', title: 'Row' },
        { field: 'id', title: 'ID' },
        { field: 'errorDetails', title: 'Error Details' },
      ]
        }
      },
   methods: {
    onSubmit(e) {
      const file = this.$refs.file.files[0];
      
      if (!file) {
        e.preventDefault();
        alert('No file chosen');
        return;
      }
      
      if (file.size > 1024 * 1024*20) {
        e.preventDefault();
        alert('File too big (> 20MB)');
        return;
      }
      if(file.type !== 'text/csv'){
        alert( "Please select csv/xls/xlsx file type", "error");
        return;
      } ;

      // if(!['csv', 'xls', 'xlsx'].includes(file.name.split(".").pop())) {       //check if file extension is csv
      //   alert( "Please select csv/xls/xlsx file type", "error");
      //    return;
      // }

      e.preventDefault();
      alert('file is okk');
    }
   }
}

</script>

<style scoped>
.LabelForm {
  color: #0055a3;
  margin-bottom: 4px;
  font-size: 0.875rem;
}
.FormworkingBtn,
.formTabSection .card-body span.workingBtn,
.formTabSection span.workingBtn {
  text-transform: uppercase;
  display: inline-block;
  background-color: #ececec;
  border: solid 1px #c5c5c5;
  border-radius: 3px;
  font-size: 12px;
  padding: 3px 7px;
  cursor: pointer;
  margin-right: 2px;
}
</style>
