<template>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseThree"
          aria-expanded="false"
          aria-controls="collapseThree"
          @click="clickPanel"
        >Usable Parts</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down collapsed"
          data-toggle="collapse"
          data-target="#collapseThree"
          aria-expanded="false"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseThree"
      class="collapse"
      aria-labelledby="headingThree"
      data-parent="#accordion"
      style
    >
      <div class="card-body">
        <div class="row border-bottom">
          <div class="col-md-12 pt-2 pb-2 text-right">
            <div v-if="editMode">
              <button type="button" class="edit-btn" @click.prevent="onEditClicked">Edit</button>
            </div>
            <div v-if="!editMode">
              <button type="button" class="save-btn mr-1" @click.prevent="onSaveClicked">Save</button>

              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-8 mt-2" v-if="editMode">
            <label>
              Model Common Name
              <i
                class="fa fa-info-circle"
                aria-hidden="true"
                title="Model Common Name"
              ></i>
            </label>
            <input
              type="text"
              class="form-control"
              disabled
              placeholder="Enter Model Common Name..."
            />
          </div>
          <div class="col-md-8 mt-2" v-if="!editMode">
            <label>
              Model Common Name
              <i
                class="fa fa-info-circle"
                aria-hidden="true"
                title="Model Common Name"
              ></i>
            </label>
            <div :class="editMode?'custom-disabled form-group': 'form-group'">
              <AutoComplete
                :searchedItem="searchedModel"
                :itemIndex="0"
                :distroyThis="distroyItem "
                :initialPlaceHolder="'Enter Model Common Name...'"
                @autoFilterData="searchModelResult"
                @setSeletecDataToInputs="setDataInputs"
                @emptySelectedFields="removeSelectedFields"
                :paramToBind="'modelCommonName'"
                :bindToInput="'modelCommonName'"
              ></AutoComplete>
              <div
                v-if="alreadyExist"
                class="invalid-text"
              >Item {{suggestedField}} already exist in list</div>
            </div>
          </div>
        </div>
        <div class="row" v-for="(model, index) in modelData.usablePart">
          <div :class="index===0? 'col-md-8 pt-2': 'col-md-8'">
            <div class="form-group">
              <label v-if="index===0">
                Part
                <i class="fa fa-info-circle" aria-hidden="true" title="Usable Parts Name"></i>
              </label>
              <input type="text" class="form-control" disabled v-model="model.modelCommonName" />
            </div>
          </div>
          <div class="col-md-1 text-left">
            <div :class="index===0? 'form-group mt-4 pt-3': 'form-group'">
              <a href="#" @click.prevent="editMode? '#':deleteElements(index)">
                <i
                  aria-hidden="true"
                  :class="model.isActive? 'fas fa-trash AddDelBtn': 'fas fa-trash AddDelBtn custom-delete-btn'"
                ></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import modelService from '../services/model-service';
import { ModelUrls } from '../../../shared/constants/urls';
import AutoComplete from '../../../components/AutoComplete';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { showToast } from '../../../shared/services/toast-service';

export default {
  components: {
    AutoComplete
  },
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      modelId: null,
      validationsMessages: VALIDATION_MESSAGES,
      alreadyExist: false,
      suggestedField: '',
      searchedModel: [],
      oldDataLength: 0,
      modelData: {
        modelId: null,
        userId: '',
        usablePart: []
      },
      editMode: true,
      distroyItem: null
    };
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    // cancel will revert whole edited data to previous state
    async onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.alreadyExist = false;
        this.editMode = true;
        this.$emit('togglePanel', this.editMode, this.itemIndex);
        this.callAPItoFetchData();
      }
      return false;
    },
    async onChildCancelClicked() {
      this.alreadyExist = false;
      this.editMode = true;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
      this.callAPItoFetchData();
    },
    // Save functionality will go here
    onSaveClicked() {
      if (this.modelData && this.modelData.usablePart && this.modelData.usablePart.length > 0) {
        this.alreadyExist = false;
        const delData = this.modelData.usablePart.filter(item => item.isActive === false);
        this.deletedRecord = delData.length;
        if (this.deletedRecord !== 0) {
          // eslint-disable-next-line no-alert
          const answer = window.confirm(`${this.deletedRecord} ${this.validationsMessages.INPUTDELETERECORD}`);
          if (answer) {
            this.callAPIToSaveModelData();
          }
        } else {
          this.callAPIToSaveModelData();
        }
      }
    },
    callAPIToSaveModelData() {
      // eslint-disable-next-line arrow-parens
      modelService.postModelsDataAction(ModelUrls.postUsablePartModelData, this.modelData).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.callAPItoFetchData();
          this.editMode = true;
          this.$emit('togglePanel', this.editMode, this.itemIndex);
          showToast('success');
        }
      });
    },
    onEditClicked() {
      this.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
      this.alreadyExist = false;
    },
    // eslint-disable-next-line no-unused-vars
    setDataInputs(selectedData, itemIndex) {
      this.alreadyExist = false;
      const standObj = this.modelData.usablePart.find(item => item.modelCommonName.trim().toLowerCase() === selectedData.modelCommonName.trim().toLowerCase());
      if (!standObj) {
        const modelObject = {
          modelId: selectedData.modelId,
          modelPartsListId: 0,
          isActive: true,
          modelCommonName: selectedData.modelCommonName
        };
        this.modelData.usablePart.push(modelObject);
      } else {
        this.alreadyExist = true;
      }
    },
    // eslint-disable-next-line no-unused-vars
    searchModelResult(searchValue) {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.searchModelLookUpData}?searchText=${searchValue}&category=usableparts`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.searchedModel = res.data.data;
        }
      });
    },
    deleteElements(index) {
      if (this.modelData.usablePart[index].usablePartId === 0) {
        this.modelData.usablePart.splice(index, 1);
      } else {
        this.modelData.usablePart[index].isActive = !this.modelData.usablePart[index].isActive;
      }
    },
    // eslint-disable-next-line no-unused-vars
    removeSelectedFields(textValue, index) {
      this.alreadyExist = false;
      this.suggestedField = textValue;
    },
    callAPItoFetchData() {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.getUsablePartModelData}?modelId=${this.modelId}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.modelData = res.data.data;
        } else {
          this.modelData = {
            modelId: this.modelId,
            userId: 0,
            usablePart: []
          };
        }
      });
    }
  },
  created() {
    this.modelId = this.$store.getters.getModelId;
    this.callAPItoFetchData();
    this.editMode = true;
  }
};
</script>