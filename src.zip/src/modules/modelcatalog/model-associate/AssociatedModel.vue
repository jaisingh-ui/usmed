<template>
  <div class="card">
    <div class="card-header" id="colheadingZero">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseZero"
          aria-expanded="false"
          aria-controls="collapseZero"
          @click="clickPanel"
        >Associated Models</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down collapsed"
          data-toggle="collapse"
          data-target="#collapseZero"
          aria-expanded="false"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseZero"
      class="collapse"
      aria-labelledby="colheadingZero"
      data-parent="#accordion"
      style
    >
      <div class="card-body">
        <div class="row border-bottom">
          <div class="col-md-12 pt-2 pb-2 text-right">
            <div v-if="editMode">
              <button type="button" class="edit-btn" @click.prevent="onEditClicked">Edit</button>
            </div>
            <div v-if="!editMode">
              <button type="button" class="save-btn mr-1" @click.prevent="onSaveClicked">Save</button>
              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-8 mt-2" v-if="editMode">
            <label>
              Model Common Name
              <i
                class="fa fa-info-circle"
                aria-hidden="true"
                title="Model Common Name"
              ></i>
            </label>
            <input
              type="text"
              class="form-control"
              disabled
              placeholder="Enter Model Common Name..."
            />
          </div>
          <div class="col-md-8 mt-2" v-if="!editMode">
            <label>
              Model Common Name
              <i
                class="fa fa-info-circle"
                aria-hidden="true"
                title="Model Common Name"
              ></i>
            </label>
            <div :class="editMode?'custom-disabled form-group': 'form-group'">
              <AutoComplete
                :searchedItem="searchedModel"
                :itemIndex="0"
                :distroyThis="distroyItem "
                :initialPlaceHolder="'Enter Model Common Name...'"
                @autoFilterData="searchModelResult"
                @setSeletecDataToInputs="setDataInputs"
                @emptySelectedFields="removeSelectedFields"
                :paramToBind="'modelCommonName'"
                :bindToInput="'modelCommonName'"
              ></AutoComplete>
              <div
                v-if="alreadyExist"
                class="invalid-text"
              >Item {{suggestedField}} already exist in list</div>
            </div>
          </div>
        </div>
        <div class="row" v-for="(model, index) in modelData.associatedModel">
          <div :class="index===0? 'col-md-8 pt-2': 'col-md-8'">
            <div class="form-group">
              <label v-if="index===0">
                Associated Model
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Associated Models  Name"
                ></i>
              </label>
              <input type="text" class="form-control" disabled v-model="model.modelCommonName" />
            </div>
          </div>
          <div class="col-md-1 text-left">
            <div :class="index===0? 'form-group mt-4 pt-3': 'form-group'">
              <a href="#" @click.prevent="editMode? '#':deleteElements(index)">
                <i
                  aria-hidden="true"
                  :class="model.isActive? 'fas fa-trash AddDelBtn': 'fas fa-trash AddDelBtn custom-delete-btn'"
                ></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import modelService from '../services/model-service';
import { ModelUrls } from '../../../shared/constants/urls';
import AutoComplete from '../../../components/AutoComplete';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { showToast } from '../../../shared/services/toast-service';

export default {
  components: {
    AutoComplete
  },
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      modelId: null,
      validationsMessages: VALIDATION_MESSAGES,
      suggestedField: '',
      alreadyExist: false,
      searchedModel: [],
      modelData: {},
      editMode: true,
      distroyItem: null
    };
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    // cancel will revert whole edited data to previous state
    async onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.alreadyExist = false;
        this.editMode = true;
        this.$emit('togglePanel', this.editMode, this.itemIndex);
        await this.callAPItoFetchData();
      }
      return false;
    },
    async onChildCancelClicked() {
      this.alreadyExist = false;
      this.editMode = true;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
      await this.callAPItoFetchData();
    },
    // Save functionality will go here
    onSaveClicked() {
      this.alreadyExist = false;
      if (this.modelData && this.modelData.associatedModel && this.modelData.associatedModel.length > 0) {
        const delData = this.modelData.associatedModel.filter(item => item.isActive === false);
        this.deletedRecord = delData.length;
        if (this.deletedRecord !== 0) {
          // eslint-disable-next-line no-alert
          const answer = window.confirm(`${this.deletedRecord} ${this.validationsMessages.INPUTDELETERECORD}`);
          if (answer) {
            this.callAPIToSaveModelData();
          }
        } else {
          this.callAPIToSaveModelData();
        }
      }
    },
    callAPIToSaveModelData() {
      // eslint-disable-next-line arrow-parens
      modelService.postModelsDataAction(ModelUrls.postAssociateModelData, this.modelData).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.callAPItoFetchData();
          this.editMode = true;
          this.$emit('togglePanel', this.editMode, this.itemIndex);
          showToast('success');
        }
      });
    },
    checkEmptyModelNameInArray() {
      // eslint-disable-next-line array-callback-return
      const items = this.modelData.associatedModel.filter((item, index) => {
        // eslint-disable-next-line no-unused-expressions
        item.modelCommonName === '' && index !== this.modelData.associatedModel.length - 1;
      });
      if (items) {
        return true;
      }
      return false;
    },
    onEditClicked() {
      this.alreadyExist = false;
      this.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    // eslint-disable-next-line no-unused-vars
    setDataInputs(selectedData, itemIndex) {
      this.alreadyExist = false;
      if (this.modelData.associatedModel.length === 0) {
        const modelObject = {
          modelAssociatedModelId: 0,
          modelId: selectedData.modelId,
          modelCommonName: selectedData.modelCommonName,
          isActive: true
        };
        this.modelData.associatedModel.push(modelObject);
      } else {
        this.suggestedField = selectedData.modelCommonName;
        const standObj = this.modelData.associatedModel.find(
          item => item.modelCommonName.trim().toLowerCase() === selectedData.modelCommonName.trim().toLowerCase()
        );
        if (!standObj) {
          const modelObject = {
            modelAssociatedModelId: 0,
            modelId: selectedData.modelId,
            modelCommonName: selectedData.modelCommonName,
            isActive: true
          };
          this.modelData.associatedModel.push(modelObject);
        } else {
          this.alreadyExist = true;
        }
      }
    },
    // eslint-disable-next-line no-unused-vars
    searchModelResult(searchValue) {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.searchModelLookUpData}?searchText=${searchValue}&category=associatedModel`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.searchedModel = res.data.data;
        }
      });
    },
    deleteElements(index) {
      if (this.modelData.associatedModel[index].modelAssociatedModelId === 0) {
        this.modelData.associatedModel.splice(index, 1);
      } else {
        this.modelData.associatedModel[index].isActive = !this.modelData.associatedModel[index].isActive;
      }
    },
    // eslint-disable-next-line no-unused-vars
    removeSelectedFields(textValue, index) {
      this.alreadyExist = false;
      this.suggestedField = textValue;
    },
    callAPItoFetchData() {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.getAssociateModelData}?modelId=${this.modelId}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.modelData = res.data.data;
        } else {
          this.modelData = {
            modelId: this.modelId,
            userId: 0,
            associatedModel: []
          };
        }
      });
    },
    preventNav(event) {
      if (this.editMode) return;
      event.preventDefault();
      // Chrome requires returnValue to be set.
      // eslint-disable-next-line no-param-reassign
      event.returnValue = '';
    }
  },
  created() {
    this.modelId = this.$store.getters.getModelId;
    this.callAPItoFetchData();
    this.editMode = true;
  }
};
</script>
<style>
</style>