<template>
  <div class="card">
    <div class="card-header" id="colheadingTwo">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseTwo"
          aria-expanded="false"
          aria-controls="collapseTwo"
          @click="clickPanel"
        >Standard Parts</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down collapsed"
          data-toggle="collapse"
          data-target="#collapseTwo"
          aria-expanded="false"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseTwo"
      class="collapse"
      aria-labelledby="colheadingTwo"
      data-parent="#accordion"
      style
    >
      <div class="card-body">
        <div class="row border-bottom">
          <div class="col-md-12 pt-2 pb-2 text-right">
            <div v-if="editMode">
              <button type="button" class="edit-btn" @click.prevent="onEditClicked">Edit</button>
            </div>
            <div v-if="!editMode">
              <button type="button" class="save-btn mr-1" @click.prevent="onSaveClicked">Save</button>

              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-8 mt-2 mb-2" v-if="editMode">
            <label>
              Model Common Name
              <i
                class="fa fa-info-circle"
                aria-hidden="true"
                title="Model Common Name"
              ></i>
            </label>
            <input
              type="text"
              class="form-control"
              disabled
              placeholder="Enter Model Common Name..."
            />
          </div>
          <div class="col-md-8 mt-2" v-if="!editMode">
            <label>
              Model Common Name
              <i
                class="fa fa-info-circle"
                aria-hidden="true"
                title="Model Common Name"
              ></i>
            </label>
            <div :class="editMode?'custom-disabled form-group': 'form-group'">
              <AutoComplete
                :searchedItem="searchedModel"
                :itemIndex="0"
                :distroyThis="distroyItem "
                :initialPlaceHolder="'Enter Model Common Name...'"
                @autoFilterData="searchModelResult"
                @setSeletecDataToInputs="setDataInputs"
                @emptySelectedFields="removeSelectedFields"
                :paramToBind="'modelCommonName'"
                :bindToInput="'modelCommonName'"
              ></AutoComplete>
              <div
                v-if="alreadyExist"
                class="invalid-text"
              >Item {{suggestedField}} already exist in list</div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div
              class="custom-kendo-part-grid"
              :class="editMode?'custom-disabled':''"
              :disabled="!editMode"
            >
              <ConfiguredColumnGrid
                :disabled="editMode"
                :gridObjects="modelData.standardPart"
                :gridColumns="standardPartsColumn"
                @editRow="deleteElements"
              ></ConfiguredColumnGrid>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Vue from 'vue';
import ConfiguredColumnGrid from '../../../components/ConfiguredColumnGrid';
import AutoComplete from '../../../components/AutoComplete';
import modelService from '../../modelcatalog/services/model-service';
import { ModelUrls } from '../../../shared/constants/urls';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { showToast } from '../../../shared/services/toast-service';

const CommandCell = Vue.component('template-component', {
  props: {
    field: String,
    dataItem: Object,
    format: String,
    className: String,
    columnIndex: Number,
    columnsCount: Number,
    rowType: String,
    level: Number,
    expanded: Boolean,
    editor: String
  },
  template: ` <td >
                <button>
                    <a href="#" @click.prevent="deleteElements(this.dataItem)" >
                        <i
                        aria-hidden="true"
                        :class="this.dataItem.isActive? 'fas fa-trash AddDelBtn': 'fas fa-trash AddDelBtn custom-delete-btn'"
                        ></i>
                    </a>
                    </button>
                   </td>`,
  methods: {
    deleteElements() {
      this.$emit('edit', { dataItem: this.dataItem });
    },
    removeHandler() {
      this.$emit('remove', { dataItem: this.dataItem });
    },
    addUpdateHandler() {
      this.$emit('save', { dataItem: this.dataItem });
    },
    cancelDiscardHandler() {
      this.$emit('cancel', { dataItem: this.dataItem });
    }
  }
});
export default {
  components: {
    ConfiguredColumnGrid,
    AutoComplete
  },
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      modelId: null,
      suggestedField: '',
      alreadyExist: false,
      editMode: true,
      distroyItem: null,
      validationsMessages: VALIDATION_MESSAGES,
      searchedModel: [],
      skip: 0,
      take: 10,
      modelData: {},
      standardPartsColumn: [
        { field: 'modelServicePartsListId', editable: false, title: 'ID', hidden: true, filterable: false },
        { field: 'modelCommonName', width: '1100px', editable: false, title: 'Part' },
        { cell: CommandCell, width: '180px', filterable: false }
      ],
      changedUsableParts: []
    };
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    // eslint-disable-next-line no-unused-vars
    searchModelResult(searchValue) {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.searchModelLookUpData}?searchText=${searchValue}&category=standardparts`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.searchedModel = res.data.data;
        }
      });
    },
    // eslint-disable-next-line no-unused-vars
    setDataInputs(selectedData, itemIndex) {
      this.alreadyExist = false;
      this.suggestedField = '';
      const standObj = this.modelData.standardPart.find(
        item => item.modelCommonName.trim().toLowerCase() === selectedData.modelCommonName.trim().toLowerCase()
      );
      if (!standObj) {
        const standardPartObject = {
          modelServicePartsListId: 0,
          modelId: selectedData.modelId,
          modelCommonName: selectedData.modelCommonName,
          isActive: true
        };
        this.modelData.standardPart.unshift(standardPartObject);
      } else {
        this.alreadyExist = true;
        this.suggestedField = selectedData.modelCommonName;
      }
    },
    // eslint-disable-next-line no-unused-vars
    removeSelectedFields(textValue, index) {
      this.alreadyExist = false;
      this.suggestedField = textValue;
    },
    deleteElements(editedData) {
      if (editedData.dataItem.standardPartId === 0) {
        const indexToRemove = this.modelData.standardPart.findIndex(
          item => item.modelCommonName.trim().toLowerCase() === editedData.dataItem.modelCommonName.trim().toLowerCase()
        );
        this.modelData.standardPart.splice(indexToRemove, 1);
      } else {
        // eslint-disable-next-line no-param-reassign
        editedData.dataItem.isActive = !editedData.dataItem.isActive;
      }
    },
    onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.alreadyExist = false;
        this.callAPItoFetchData();
        this.editMode = true;
        this.$emit('togglePanel', this.editMode, this.itemIndex);
      }
      return false;
    },
    onChildCancelClicked() {
      this.alreadyExist = false;
      this.callAPItoFetchData();
      this.editMode = true;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    onEditClicked() {
      this.alreadyExist = false;
      this.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    // Save functionality will go here
    onSaveClicked() {
      this.alreadyExist = false;
      if (this.modelData && this.modelData.standardPart && this.modelData.standardPart.length > 0) {
        const delData = this.modelData.standardPart.filter(item => item.isActive === false);
        this.deletedRecord = delData.length;
        if (this.deletedRecord !== 0) {
          // eslint-disable-next-line no-alert
          const answer = window.confirm(`${this.deletedRecord} ${this.validationsMessages.INPUTDELETERECORD}`);
          if (answer) {
            this.callAPIToSaveModelData();
          }
        } else {
          this.callAPIToSaveModelData();
        }
      }
    },
    callAPIToSaveModelData() {
      // eslint-disable-next-line arrow-parens
      modelService.postModelsDataAction(ModelUrls.postStandardPartModelData, this.modelData).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.callAPItoFetchData();
          this.editMode = true;
          this.$emit('togglePanel', this.editMode, this.itemIndex);
          showToast('success');
        }
      });
    },
    callAPItoFetchData() {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.getStandardPartModelData}?modelId=${this.modelId}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.modelData = res.data.data;
        } else {
          this.modelData = {
            modelId: this.modelId,
            userId: 0,
            standardPart: []
          };
        }
      });
    }
  },
  created() {
    this.modelId = this.$store.getters.getModelId;
    this.callAPItoFetchData();
    this.editMode = true;
  }
};
</script>
<style>
/* custom classes for kendo grid start here */
.custom-kendo-part-grid .k-grid-header-wrap > table,
.custom-kendo-part-grid table.k-grid-table {
  width: 100% !important;
}

.custom-kendo-part-grid table.k-grid-table tr.k-master-row button {
  border: 0;
  background: none;
}

.custom-kendo-grid .k-grid-content-expander {
  width: auto !important;
}

.custom-kendo-part-grid table thead th.k-header {
  font-size: 15px;
  font-weight: 500;
}

.custom-kendo-grid th.k-header .k-link {
  text-align: left;
  font-size: 15px;
  font-weight: 500;
}

.k-pager-numbers .k-state-selected {
  background-color: #0053a0;
}
.k-pager-numbers .k-link {
  color: #787878;
}
.k-pager-numbers .k-link:hover {
  color: #0053a0;
}
.k-pager-nav:hover {
  color: #0053a0;
}
.k-list .k-item.k-state-selected {
  background-color: #0053a0;
}
.k-list .k-item.k-state-selected:hover {
  background-color: #0053a0;
}
/* custom classes for kendo grid end here */

.custom-kendo-part-grid .k-textbox {
  width: auto !important;
}
</style>
