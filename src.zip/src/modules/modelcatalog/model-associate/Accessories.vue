<template>
  <div class="card">
    <div class="card-header" id="headingFour">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseFour"
          aria-expanded="false"
          aria-controls="collapseFour"
          @click="clickPanel"
        >Accessories</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down collapsed"
          data-toggle="collapse"
          data-target="#collapseFour"
          aria-expanded="false"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseFour"
      class="collapse"
      aria-labelledby="headingFour"
      data-parent="#accordion"
      style
    >
      <div class="card-body">
        <div class="row border-bottom">
          <div class="col-md-12 pt-2 pb-2 text-right">
            <div v-if="editMode">
              <button type="button" class="edit-btn" @click.prevent="onEditClicked">Edit</button>
            </div>
            <div v-if="!editMode">
              <button type="button" class="save-btn mr-1" @click.prevent="onSaveClicked">Save</button>

              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-9 mt-2" v-if="editMode">
            <label>
              Model Common Name
              <i
                class="fa fa-info-circle"
                aria-hidden="true"
                title="Model Common Name"
              ></i>
            </label>
            <input
              type="text"
              class="form-control"
              disabled
              placeholder="Enter Model Common Name..."
            />
          </div>
          <div class="col-md-9 mt-2" v-if="!editMode">
            <label>
              Model Common Name
              <i
                class="fa fa-info-circle"
                aria-hidden="true"
                title="Model Common Name"
              ></i>
            </label>
            <div :class="editMode?'custom-disabled form-group': 'form-group'">
              <AutoComplete
                :searchedItem="searchedModel"
                :itemIndex="0"
                :distroyThis="distroyItem "
                :initialPlaceHolder="'Enter Model Common Name...'"
                @autoFilterData="searchModelResult"
                @setSeletecDataToInputs="setDataInputs"
                @emptySelectedFields="removeSelectedFields"
                :paramToBind="'modelCommonName'"
                :bindToInput="'modelCommonName'"
              ></AutoComplete>
              <div
                v-if="alreadyExist"
                class="invalid-text"
              >Item {{suggestedField}} already exist in list</div>
            </div>
          </div>
        </div>
        <div v-for="(accessories, index) in modelData.accessory" class="row">
          <div class="col-md-9">
            <div class="form-group">
              <label v-if="index===0">
                Accessories
                <i class="fa fa-info-circle" aria-hidden="true" title="Model  Name"></i>
              </label>
              <input
                type="text"
                class="form-control"
                placeholder="Type Model Name"
                disabled
                v-model="accessories.modelCommonName"
              />
            </div>
          </div>
          <div class="col-md-1">
            <div class="form-group">
              <label v-if="index===0">Billable</label>
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="editMode"
                    type="checkbox"
                    class="custom-control-input"
                    :id="'customCheck' + index"
                    :checked="accessories.isBillable"
                    @click="isBillableClicked(index)"
                  />
                  <label class="custom-control-label" :for="'customCheck' + index"></label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-1">
            <div class="form-group">
              <label v-if="index===0">
                Required
                <i
                  class="icon-help-round-button"
                  data-container="body"
                  data-toggle="popover"
                  data-placement="right"
                  data-content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
                  data-original-title
                  title
                ></i>
              </label>
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    :disabled="editMode"
                    type="checkbox"
                    class="custom-control-input"
                    :checked="accessories.isRequired"
                    :id="'customCheckRequired' + index"
                    @click="isRequireClicked(index)"
                  />
                  <label class="custom-control-label" :for="'customCheckRequired' + index"></label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-1 text-left">
            <div :style="index===0? 'margin-top:35px;':''" class="form-group">
              <a href="#" @click.prevent="deleteElements(index)">
                <i
                  aria-hidden="true"
                  :class="accessories.isActive? 'fas fa-trash AddDelBtn': 'fas fa-trash AddDelBtn custom-delete-btn'"
                ></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import modelService from '../services/model-service';
import { ModelUrls } from '../../../shared/constants/urls';
import AutoComplete from '../../../components/AutoComplete';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { showToast } from '../../../shared/services/toast-service';

export default {
  components: {
    AutoComplete
  },
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      alreadyExist: false,
      searchedModel: [],
      suggestedField: '',
      errorIndexes: [],
      oldDataLength: 0,
      modelData: {},
      editMode: true,
      distroyItem: null
    };
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    isBillableClicked(index) {
      this.modelData.accessory[index].isBillable = !this.modelData.accessory[index].isBillable;
    },
    isRequireClicked(index) {
      this.modelData.accessory[index].isRequired = !this.modelData.accessory[index].isRequired;
    },
    // cancel will revert whole edited data to previous state
    async onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.alreadyExist = false;
        this.isError = false;
        this.errorIndexes = [];
        this.editMode = true;
        this.$emit('togglePanel', this.editMode, this.itemIndex);
      }
      return false;
    },
    async onChildCancelClicked() {
      this.alreadyExist = false;
      this.isError = false;
      this.errorIndexes = [];
      this.editMode = true;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    // Save functionality will go here
    onSaveClicked() {
      this.alreadyExist = false;
      if (this.modelData && this.modelData.accessory && this.modelData.accessory.length > 0) {
        const delData = this.modelData.accessory.filter(item => item.isActive === false);
        this.deletedRecord = delData.length;
        if (this.deletedRecord !== 0) {
          // eslint-disable-next-line no-alert
          const answer = window.confirm(`${this.deletedRecord} ${this.validationsMessages.INPUTDELETERECORD}`);
          if (answer) {
            this.callAPIToSaveModelData();
          }
        } else {
          this.callAPIToSaveModelData();
        }
      }
    },
    callAPIToSaveModelData() {
      // eslint-disable-next-line arrow-parens
      modelService.postModelsDataAction(ModelUrls.postAccessoriesModelData, this.modelData).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.callAPItoFetchData();
          this.editMode = true;
          this.$emit('togglePanel', this.editMode, this.itemIndex);
          showToast('success');
        }
      });
    },
    onEditClicked() {
      this.alreadyExist = false;
      this.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    // eslint-disable-next-line no-unused-vars
    setDataInputs(selectedData, itemIndex) {
      this.alreadyExist = false;
      const standObj = this.modelData.accessory.find(item => item.modelCommonName.trim().toLowerCase() === selectedData.modelCommonName.trim().toLowerCase());
      if (!standObj) {
        const modelObject = {
          modelAccessoryId: 0,
          modelCommonName: selectedData.modelCommonName,
          modelId: selectedData.modelId,
          isActive: true,
          isBillable: false,
          isRequired: false
        };
        this.modelData.accessory.push(modelObject);
      } else {
        this.alreadyExist = true;
      }
    },
    // eslint-disable-next-line no-unused-vars
    searchModelResult(searchValue) {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.searchModelLookUpData}?searchText=${searchValue}&category=Accessories`).then(res => {
        if (res) {
          this.searchedModel = res.data.data;
        }
      });
    },
    deleteElements(index) {
      if (this.modelData.accessory[index].modelAccessoryId === 0) {
        this.modelData.accessory.splice(index, 1);
      } else {
        this.modelData.accessory[index].isActive = !this.modelData.accessory[index].isActive;
      }
    },
    // eslint-disable-next-line no-unused-vars
    removeSelectedFields(textValue, index) {
      this.alreadyExist = false;
      this.suggestedField = textValue;
    },
    callAPItoFetchData() {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.getAccessoriesModelData}?modelId=${this.modelId}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.modelData = res.data.data;
        } else {
          this.modelData = {
            modelId: this.modelId,
            userId: 0,
            accessory: []
          };
        }
      });
    }
  },
  created() {
    this.modelId = this.$store.getters.getModelId;
    this.callAPItoFetchData();
    this.editMode = true;
  }
};
</script>