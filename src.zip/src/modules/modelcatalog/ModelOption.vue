<template>
  <!-- right pannel section -->
  <div id="content">
    <div class="container-fluid">
      <ModuleHeader moduleName="Model Details" :headerData="result"></ModuleHeader>

      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <div id="accordion" v-if="componentToRender.subMenuModules.length > 0">
              <template v-for="(subModule, index) in componentToRender.subMenuModules">
                <component
                  v-if="subModule.subMenuModuleVisible"
                  :is="subModule.subMenuModuleName"
                  :subModuleInfo="subModule"
                  :key="subModule.subMenuModuleId"
                  :ref="'model'+index"
                  :itemIndex="index"
                  @togglePanel="panelToggle"
                  @panelClicked="onClicked"
                ></component>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script>
import ModuleHeader from '../../components/ModuleHeader';
import Options from './model-options/Options';
import SoftwareVersions from './model-options/SoftwareVersions';
import VALIDATION_MESSAGES from '../../shared/constants/messages';
import modelService from './services/model-service';
import { ModelUrls } from './../../shared/constants/urls';

export default {
  name: 'ModelOption',
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      componentToRender: {},
      showPanels: true,
      refId: null,
      headerData: {
        head: 'Model Options',
        id: 0,
        name: '',
        status: ''
      }
    };
  },
  computed: {
    result() {
      return this.headerData;
    }
  },
  components: {
    Options,
    SoftwareVersions,
    ModuleHeader
  },
  methods: {
    panelToggle(editMode, itemIndex) {
      this.refId = `model${itemIndex}`;
      if (editMode) {
        this.showPanels = true;
      } else {
        this.showPanels = false;
      }
    },
    onClicked(event) {
      if (!this.showPanels) {
        // eslint-disable-next-line no-alert
        const answer = window.confirm(this.validationsMessages.WARNINGPARTIALFILLEDPANEL);
        if (!answer) {
          event.preventDefault();
          event.stopPropagation();
          // eslint-disable-next-line no-param-reassign
          event.returnValue = '';
        } else {
          this.$refs[this.refId][0].onChildCancelClicked();
          this.showPanels = true;
        }
      }
    },

    getGeneralDetailData(id) {
      if (id) {
        // eslint-disable-next-line arrow-parens
        modelService.getModelRequest(`${ModelUrls.modelGeneralData}?modelId=${id}`).then(res => {
          if (res.data.apiResponseStatus !== 'Failed') {
            const result = res.data.data;
            this.headerData.id = id;
            this.headerData.name = result.modelName;
            this.headerData.status = result.isActive ? 'Active' : 'Inactive';
          }
        });
      }
    }
  },
  created() {
    this.componentToRender = this.$store.getters.getSubMenuModulesFromLeftMenuConfigs(2, 3);
    this.getGeneralDetailData(this.$store.getters.getModelId);
  }
};
</script>