<template>
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button
          class="btn btn-link"
          data-toggle="collapse"
          data-target="#collapseOne"
          aria-expanded="true"
          aria-controls="collapseOne"
          @click="clickPanel"
        >General Details</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseOne"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseOne"
      class="collapse show"
      aria-labelledby="headingOne"
      data-parent="#accordion"
    >
      <div class="card-body">
        <form id="GeneralDetails">
          <div class="row" style="border-bottom: 1px solid #efefef;">
            <div class="col-md-12 text-right mb-1 mt-1">
              <!-- <span v-if="isEdit && !editMode" class="workingBtn">
                <a href="javascript:void(0)" @click.prevent="onEditClicked">
                  <i class="icon-edit-button-icon" aria-hidden="true"></i>
                  Edit
                </a>
              </span>-->
              <button
                v-if="isEdit && !editMode"
                type="button"
                class="edit-btn"
                @click.prevent="onEditClicked"
              >Edit</button>
              <div v-if="editMode">
                <button
                  v-if="isSaveData"
                  type="button"
                  class="save-btn mr-1"
                  @click.prevent="handleSubmit"
                >Save</button>
                <button
                  v-else
                  type="button"
                  class="save-btn mr-1"
                  @click.prevent="handleUpdate"
                >Save</button>

                <button
                  v-if="isSaveData"
                  type="button"
                  class="cancel-btn"
                  @click.prevent="resetFormData"
                >Cancel</button>
                <button v-else type="button" class="cancel-btn" @click.prevent="handleCancel">Cancel</button>
              </div>
            </div>
          </div>
          <!-- Api response errors -->
          <div
            class="alert alert-warning alert-dismissible fade show text-center"
            role="alert"
            v-if="apiErrors.length > 0"
          >
            <div v-for="message in apiErrors">{{message.userMessage}}</div>
          </div>
          <div>
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Model Group
                    <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                  </label>
                  <div class="input-group">
                    <select
                      :disabled="isDisable"
                      class="form-control"
                      v-model="GeneralModel.modelGroupId"
                    >
                      <option value>Select</option>
                      <option
                        v-bind:value="mvalue.entityID"
                        v-for="mvalue in modelGroupOpt"
                      >{{ mvalue.entityName }}</option>
                    </select>
                    <p
                      v-if="submitted && !$v.GeneralModel.modelGroupId.required"
                      class="error-message"
                    >{{validationMessages.REQUIRED}}</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Model Name
                    <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                  </label>
                  <input
                    type="text"
                    v-model.trim="GeneralModel.modelName"
                    class="form-control"
                    :disabled="isDisable"
                    maxlength="100"
                  />
                  <p
                    v-if="submitted && !$v.GeneralModel.modelName.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Model Category
                    <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                  </label>
                  <select
                    :disabled="isDisable"
                    class="form-control"
                    v-model="GeneralModel.modelCategoryId"
                  >
                    <option value>Select</option>
                    <option
                      v-for="mvalue in modelCatageoryOpt"
                      :value="mvalue.entityID"
                    >{{ mvalue.entityName }}</option>
                  </select>
                  <p
                    v-if="submitted && !$v.GeneralModel.modelCategoryId.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Model Type
                    <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                  </label>
                  <select
                    @change="subModelType()"
                    :disabled="isDisable"
                    class="form-control"
                    v-model="GeneralModel.modelTypeId"
                  >
                    <option value>Select</option>
                    <option
                      v-bind:value="mvalue.entityID"
                      v-for="mvalue in modelTypeOpt"
                    >{{ mvalue.entityName }}</option>
                  </select>
                  <p
                    v-if="submitted && !$v.GeneralModel.modelTypeId.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Model Sub Type
                    <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                  </label>
                  <select
                    :disabled="isDisable || !GeneralModel.modelTypeId"
                    class="form-control"
                    v-model="GeneralModel.modelSubTypeId"
                  >
                    <option
                      v-bind:value="mvalue.entityID"
                      v-for="mvalue in modelSubTypeOpt"
                    >{{ mvalue.entityName }}</option>
                  </select>
                  <p
                    v-if="submitted && !$v.GeneralModel.modelSubTypeId.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Class
                    <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                  </label>
                  <select
                    :disabled="isDisable"
                    class="form-control"
                    v-model="GeneralModel.modelClassId"
                  >
                    <option value>Select</option>
                    <option
                      v-bind:value="mvalue.entityID"
                      v-for="mvalue in modelClassOpt"
                    >{{ mvalue.entityName }}</option>
                  </select>
                  <p
                    v-if="submitted && !$v.GeneralModel.modelClassId.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Reference Number
                    <i
                      class="fas fa-info-circle"
                      title="Lorem Ipsum is simply dummy"
                    ></i>
                  </label>
                  <input
                    :disabled="isDisable"
                    type="text"
                    v-model="GeneralModel.manufacturerModelReferenceId"
                    class="form-control"
                    maxlength="100"
                  />
                  <p
                    v-if="submitted && !$v.GeneralModel.manufacturerModelReferenceId.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                  <!-- <p
                    v-if="!$v.GeneralModel.manufacturerModelReferenceId.alphawithspace"
                    class="error-message"
                  >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>-->
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Manufacturer
                    <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                  </label>
                  <select
                    :disabled="isDisable"
                    id="inputMenu"
                    class="form-control"
                    v-model="GeneralModel.manufacturerId"
                  >
                    <option value>Select</option>
                    <option
                      v-bind:value="mvalue.entityID"
                      v-for="mvalue in manufacturerOpt"
                    >{{ mvalue.entityName }}</option>
                  </select>
                  <p
                    v-if="submitted && !$v.GeneralModel.manufacturerId.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Manufacturer Model
                    <i
                      class="fas fa-info-circle"
                      title="Lorem Ipsum is simply dummy"
                    ></i>
                  </label>
                  <input
                    :disabled="isDisable"
                    type="text"
                    v-model="GeneralModel.manufacturerModel"
                    class="form-control"
                    maxlength="100"
                  />
                  <!-- <p
                    v-if="!$v.GeneralModel.manufacturerModel.alphawithspace"
                    class="error-message"
                  >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>-->
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Model Available For
                    <i
                      class="fas fa-info-circle"
                      title="Lorem Ipsum is simply dummy"
                    ></i>
                  </label>
                  <div class="custom-multiselect">
                    <kendo-dropdowntree
                      :disabled="isDisable"
                      :class="{'disabled-class':isDisable, 'form-control':true}"
                      v-model="GeneralModel.modelAvailableFor"
                      :data-source="modelAvailableForOpt"
                      :checkboxes="true"
                      :check-all="false"
                      :placeholder="'Select'"
                    ></kendo-dropdowntree>
                  </div>
                  <p
                    v-if="submitted && !$v.GeneralModel.modelAvailableFor.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Quantity Type
                    <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                  </label>
                  <select
                    :disabled="isDisable"
                    class="form-control"
                    v-model="GeneralModel.quantityTypeId"
                  >
                    <option value>Select</option>
                    <option
                      v-bind:value="mvalue.id"
                      v-for="mvalue in quantityTypeOpt"
                    >{{ mvalue.text }}</option>
                  </select>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Unit of Measure
                    <i
                      class="fas fa-info-circle"
                      title="Lorem Ipsum is simply dummy"
                    ></i>
                  </label>
                  <select
                    :disabled="isDisable"
                    class="form-control"
                    v-model="GeneralModel.unitOfMeasureId"
                  >
                    <option value>Select</option>
                    <option
                      v-bind:value="mvalue.entityID"
                      v-for="mvalue in unitofMeasureOpt"
                    >{{ mvalue.entityName }}</option>
                  </select>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Status
                    <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                  </label>
                  <div class="checkBoxinFrom">
                    <div class="custom-control custom-checkbox">
                      <input
                        :disabled="isDisable"
                        type="checkbox"
                        v-model="GeneralModel.isActive"
                        class="custom-control-input"
                        id="customCheck12"
                      />
                      <label class="custom-control-label" for="customCheck12">Active</label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Stand By
                    <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                  </label>
                  <div class="checkBoxinFrom">
                    <div class="custom-control custom-checkbox">
                      <input
                        :disabled="isDisable"
                        type="checkbox"
                        v-model="GeneralModel.isStandByValid"
                        class="custom-control-input"
                        id="customCheck27"
                      />
                      <label class="custom-control-label" for="customCheck27">&nbsp;</label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Alert Message
                    <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                  </label>
                  <input
                    :disabled="isDisable"
                    type="text"
                    v-model="GeneralModel.alertMessage"
                    class="form-control"
                    maxlength="500"
                  />
                  <p
                    v-if="!$v.GeneralModel.alertMessage.alphaWithSpecialChar"
                    class="error-message"
                  >{{validationMessages.INVALIDMODELOPTION}}</p>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Short Description
                    <i
                      class="fas fa-info-circle"
                      title="Lorem Ipsum is simply dummy"
                    ></i>
                  </label>
                  <textarea
                    :disabled="isDisable"
                    v-model="GeneralModel.shortDesc"
                    class="form-control"
                    rows="5"
                    maxlength="1000"
                  ></textarea>
                  <p
                    v-if="!$v.GeneralModel.shortDesc.alphaWithSpecialChar"
                    class="error-message"
                  >{{validationMessages.INVALIDMODELOPTION}}</p>
                </div>
              </div>
              <div class="col-md-8">
                <div class="form-group">
                  <label>
                    Long Description
                    <i
                      class="fas fa-info-circle"
                      title="Lorem Ipsum is simply dummy"
                    ></i>
                  </label>
                  <textarea
                    :disabled="isDisable"
                    v-model="GeneralModel.longDesc"
                    class="form-control"
                    rows="5"
                    maxlength="1000"
                  ></textarea>
                  <p
                    v-if="!$v.GeneralModel.longDesc.alphaWithSpecialChar"
                    class="error-message"
                  >{{validationMessages.INVALIDMODELOPTION}}</p>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>
                    Model Common Name
                    <i
                      class="fas fa-info-circle"
                      title="Lorem Ipsum is simply dummy"
                    ></i>
                  </label>
                  <input
                    :disabled="isDisable"
                    type="text"
                    v-model="GeneralModel.modelCommonName"
                    class="form-control"
                    maxlength="200"
                  />
                  <p
                    v-if="submitted && !$v.GeneralModel.modelCommonName.required"
                    class="error-message"
                  >{{validationMessages.REQUIRED}}</p>
                  <!-- <p
                    v-if="!$v.GeneralModel.modelCommonName.alphawithspace"
                    class="error-message"
                  >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>-->
                </div>
              </div>
            </div>

            <div class="row" v-for="(product, index) in GeneralModel.productNames">
              <div class="col-md-11">
                <div class="form-group">
                  <label v-if="index == 0">
                    Product Name
                    <i class="fas fa-info-circle" title="Product Name"></i>
                  </label>

                  <span class="error-message" v-if="ifAllProductDeleted && index===0">
                    <br />
                    {{validationMessages.ONERECORDNEEDED}}
                  </span>

                  <input
                    :disabled="!editMode"
                    type="text"
                    :class="toggleProducts(product)"
                    v-model.trim="product.name"
                    @blur="blurProduct"
                    maxlength="200"
                  />
                  <p
                    class="error-message"
                    v-if="!$v.GeneralModel.productNames.$each[index].name.isDuplicate"
                  >{{validationMessages.DUPLICATE_VALUES}}</p>
                  <p
                    class="error-message"
                    v-if="submitted && !$v.GeneralModel.productNames.$each[index].name.required"
                  >{{validationMessages.REQUIRED}}</p>
                </div>
              </div>
              <div class="col-md-1 text-left">
                <div :style="index == 0 ? 'margin-top:35px' : '' " class="form-group">
                  <a
                    :class="isDisable? 'disabled-anchor' : ''"
                    href="javascript:void(0)"
                    @click="isDisable? '':removeProduct(index)"
                    v-if="index !== GeneralModel.productNames.length-1"
                  >
                    <i
                      :class="product.isActive? 'far fa-trash-alt AddDelBtn': 'far fa-trash-alt AddDelBtn custom-delete-btn'"
                      aria-hidden="true"
                    ></i>
                  </a>
                  <a
                    :class="isDisable? 'disabled-anchor' : ''"
                    href="javascript:void(0)"
                    @click="addProduct()"
                    v-if="index == GeneralModel.productNames.length-1"
                  >
                    <i :class="addElementClass(product)" aria-hidden="true"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import Vue from 'vue';
import Vuelidate from 'vuelidate';
import { DropDownTreeInstaller } from '@progress/kendo-dropdowntree-vue-wrapper';
import { required, helpers } from 'vuelidate/lib/validators';
import { PatternValidation } from '../../../shared/constants/pattern-validation';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import modelService from '../services/model-service';
import { ModelUrls, MasterUrls } from '../../../shared/constants/urls';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

Vue.use(DropDownTreeInstaller);
Vue.use(Vuelidate);
const alphaWithSpecialChar = helpers.regex('alphaWithSpecialChar', /^[a-zA-Z0-9' , . _ # -]*$/);
export default {
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      ifAllProductDeleted: false,
      GeneralModel: {
        modelId: '',
        modelName: '',
        modelGroupId: '',
        modelCategoryId: '',
        modelTypeId: '',
        modelSubTypeId: '',
        modelClassId: '',
        manufacturerModelReferenceId: '',
        manufacturerId: '',
        manufacturerModel: '',
        modelAvailableFor: '',
        isRental: false,
        isSaleOnly: false,
        quantityTypeId: 2,
        unitOfMeasureId: 3,
        isActive: true,
        isStandByValid: false,
        alertMessage: '',
        shortDesc: '',
        longDesc: '',
        modelCommonName: '',
        productNames: [{ name: '', id: 0, isActive: true }],
        userId: 1
      },
      submitted: false,
      isDisable: false,
      isEdit: false,
      editMode: true,
      isSaveData: true,
      duplicateIndex: null,
      validationMessages: VALIDATION_MESSAGES,
      ModelSubTypeOptions: [],
      headerData: {
        head: 'Model Details',
        id: 0,
        name: '',
        status: ''
      },
      retainGeneralModel: {},

      modelGroupOpt: [],
      modelCatageoryOpt: [],
      modelTypeOpt: [],
      modelSubTypeOpt: [],
      modelClassOpt: [],
      manufacturerOpt: [],
      unitofMeasureOpt: [],
      modelAvailableForOpt: [
        { text: 'Rental', value: 1 },
        { text: 'Sale', value: 2 }
      ],
      quantityTypeOpt: [
        { text: 'Single', id: 2 },
        { text: 'Multiple', id: 3 }
      ],
      requireProduct: false,
      apiErrors: []
    };
  },
  validations: {
    GeneralModel: {
      modelGroupId: { required },
      modelName: { required },
      modelCategoryId: { required },
      modelTypeId: { required },
      modelSubTypeId: { required },
      modelClassId: { required },
      manufacturerModelReferenceId: { required },
      manufacturerId: { required },
      modelAvailableFor: { required },
      isActive: { required },
      alertMessage: { alphaWithSpecialChar },
      modelCommonName: { required },
      productNames: {
        $each: {
          name: {
            required: function getItem(item, product) {
              let reqProduct = true;
              if (item === '' && product.id !== 0) {
                reqProduct = false;
              } else if (
                this.GeneralModel &&
                product.id === 0 &&
                this.GeneralModel.productNames.length === 1 &&
                this.GeneralModel.productNames[0].name.trim() === ''
              ) {
                reqProduct = false;
              }
              return reqProduct;
            },
            isDuplicate(name, productItem) {
              const productIndex = this.GeneralModel.productNames.findIndex(prod => prod.name === name);
              let isProductDuplicate = true;
              this.GeneralModel.productNames.forEach((productObject, index) => {
                if (index !== productIndex) {
                  if (productObject.name.trim() === productItem.name.trim() && productItem.name.trim() !== '') {
                    isProductDuplicate = false;
                  }
                }
              });
              return isProductDuplicate;
            }
          }
        }
      },
      shortDesc: { alphaWithSpecialChar },
      longDesc: { alphaWithSpecialChar }
    }
  },
  created() {
    this.modelId = this.$store.getters.getModelId;

    this.subModelType();
    this.getMockData();
    // If model id exist - view/edit mode
    if (!isNaN(this.modelId)) {
      this.isDisable = true;
      this.isEdit = true;
      this.editMode = false;
      this.isSaveData = false;
      this.getGeneralDetailData(this.modelId);
    } else {
      this.retainGeneralModel = JSON.parse(JSON.stringify(this.GeneralModel));
    }
  },
  watch: {
    ModelSubTypeOptions() {
      this.modelSubTypeOpt = this.ModelSubTypeOptions;
    }
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    toggleProducts(product) {
      let optionClass = 'form-control form-control-view';
      if (product.id === 0 && product.name === '' && !this.editMode) {
        optionClass = 'form-control form-control-disable';
      } else if (product.isActive && !this.editMode) {
        optionClass = 'form-control form-control-view';
      } else if (product.id === 0 && product.name !== '' && this.editMode) {
        optionClass = 'form-control form-control form-control-view';
      }
      return optionClass;
    },
    getMockData() {
      // eslint-disable-next-line arrow-parens
      modelService
        .getModelListResult(
          `${MasterUrls.getMasterMockup}?identifier=ModelGroup%7CModelCategory%7CModelType%7CModelSubType%7CModelClass%7CManufacturer%7CUnitOfMeasure`
        )
        // eslint-disable-next-line arrow-parens
        .then(res => {
          this.modelTypeOpt = res.data.data.ModelType;
          this.ModelSubTypeOptions = res.data.data.ModelSubType;
          this.modelCatageoryOpt = res.data.data.ModelCategory;
          this.modelClassOpt = res.data.data.ModelClass;
          this.manufacturerOpt = res.data.data.Manufacturer;
          this.modelGroupOpt = res.data.data.ModelGroup;
          this.unitofMeasureOpt = res.data.data.UnitOfMeasure;
        });
    },
    subModelType() {
      const modelParentType = this.GeneralModel.modelTypeId;
      this.modelSubTypeOpt = this.ModelSubTypeOptions.filter(item => modelParentType === item.parentModelTypeId);
    },
    getGeneralDetailData(id) {
      if (id) {
        // eslint-disable-next-line arrow-parens
        modelService.getModelRequest(`${ModelUrls.modelGeneralData}?modelId=${id}`).then(res => {
          if (res.data.apiResponseStatus !== 'Failed') {
            const result = res.data.data;
            // const that = this;
            this.GeneralModel.modelName = result.modelName;
            this.GeneralModel.modelCategoryId = result.modelCategoryId;
            this.$store.dispatch('setModelCategoryId', this.GeneralModel.modelCategoryId);
            this.GeneralModel.modelTypeId = result.modelTypeId;
            // that.subModelType(result.modelTypeId);
            this.GeneralModel.modelSubTypeId = result.modelSubTypeId;
            this.GeneralModel.modelClassId = result.modelClassId;
            this.GeneralModel.shortDesc = result.shortDesc;
            this.GeneralModel.longDesc = result.longDesc;
            this.GeneralModel.isActive = result.isActive;
            this.GeneralModel.isStandByValid = result.isStandByValid;
            this.GeneralModel.alertMessage = result.alertMessage;
            this.GeneralModel.unitOfMeasureId = result.unitOfMeasureId;
            this.GeneralModel.quantityTypeId = result.quantityTypeId;
            this.GeneralModel.manufacturerModel = result.manufacturerModel;
            this.GeneralModel.manufacturerId = result.manufacturerId;
            this.GeneralModel.modelCommonName = result.modelCommonName;
            this.GeneralModel.modelGroupId = result.modelGroupId;
            this.GeneralModel.manufacturerModelReferenceId = result.manufacturerModelReferenceId;
            // Bind model available for options data
            this.GeneralModel.modelAvailableFor = [result.isRental ? 1 : '', result.isSaleOnly ? 2 : ''];
            this.GeneralModel.productNames = [];
            // eslint-disable-next-line arrow-parens
            result.modelProductNames.forEach(element => {
              const product = { id: element.modelProductNameID, name: element.modelProductName, isActive: true };
              this.GeneralModel.productNames.push(product);
            });

            this.GeneralModel.productNames.push({ name: '', id: 0, isActive: true });

            this.setModelDetailHeader(id);
          } else {
            console.log(res.data.errors);
          }
        });
      }
    },
    setModelDetailHeader(id) {
      this.headerData.id = id;
      this.headerData.name = this.GeneralModel.modelName;
      this.headerData.status = this.GeneralModel.isActive ? 'Active' : 'Inactive';
      this.$emit('setModelDetailHeaders', this.headerData);
    },
    blurProduct(event) {
      if (event.target.value !== '') {
        this.requireProduct = false;
      } else {
        this.requireProduct = true;
      }
    },
    handleSubmit() {
      this.submitted = true;
      this.apiErrors = [];
      // stop here if form is invalid
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      }
      // eslint-disable-next-line no-plusplus
      for (let i = 0; i <= this.GeneralModel.modelAvailableFor.length - 1; i++) {
        if (this.GeneralModel.modelAvailableFor[i] === 1) {
          this.GeneralModel.isRental = true;
        }
        if (this.GeneralModel.modelAvailableFor[i] === 2) {
          this.GeneralModel.isSaleOnly = true;
        }
      }

      this.GeneralModel.modelId = 0;
      if (this.GeneralModel.productNames.length > 1) {
        if (this.GeneralModel.productNames[this.GeneralModel.productNames.length - 1].name === '') {
          this.GeneralModel.productNames.splice(this.GeneralModel.productNames.length - 1, 1);
        }
      }

      // eslint-disable-next-line arrow-parens
      modelService.postModelRequest(`${ModelUrls.addModelGeneralData}`, this.GeneralModel).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          // Need to set the Model info here from response object after saving the Model Data
          const result = res.data.data;
          this.$store.dispatch('setModelId', result);
          this.modelId = result;
          this.isDisable = true;
          this.editMode = false;
          this.isEdit = true;
          this.isSaveData = false;
          this.requireProduct = false;

          this.getGeneralDetailData(result);
          this.$emit('togglePanel', !this.editMode, this.itemIndex);
          this.$emit('onModelAdded');
          showToast('success');
        } else {
          this.apiErrors = res.data.errors;
        }
      });
    },
    handleUpdate() {
      this.ifAllProductDeleted = false;
      this.submitted = true;
      this.apiErrors = [];
      if (this.GeneralModel.productNames.length > 1) {
        if (this.GeneralModel.productNames[this.GeneralModel.productNames.length - 1].name === '') {
          this.GeneralModel.productNames.splice(this.GeneralModel.productNames.length - 1, 1);
        }
      }
      const delData = this.GeneralModel.productNames.filter(item => item.isActive === false);
      if (delData.length === this.GeneralModel.productNames.length) {
        this.ifAllProductDeleted = true;
        this.GeneralModel.productNames.push({ name: '', id: 0, isActive: true });
        return;
      }
      if (delData.length > 0 && !this.checkAllDeltedProducts(delData.length)) {
        return;
      }
      // stop here if form is invalid
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      }
      // eslint-disable-next-line no-plusplus
      for (let i = 0; i <= this.GeneralModel.modelAvailableFor.length - 1; i++) {
        if (this.GeneralModel.modelAvailableFor[i] === 1) {
          this.GeneralModel.isRental = true;
        }
        if (this.GeneralModel.modelAvailableFor[i] === 2) {
          this.GeneralModel.isSaleOnly = true;
        }
      }

      this.GeneralModel.modelId = this.modelId;
      // eslint-disable-next-line arrow-parens
      modelService.postModelRequest(`${ModelUrls.addModelGeneralData}`, this.GeneralModel).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.isDisable = true;
          this.editMode = false;
          this.isEdit = true;
          this.requireProduct = false;

          this.getGeneralDetailData(this.modelId);
          this.$emit('togglePanel', !this.editMode, this.itemIndex);
          showToast('success');
        } else {
          this.apiErrors = res.data.errors;
        }
      });
    },
    hasDuplicates(array) {
      return new Set(array).size !== array.length;
    },
    checkAllDeltedProducts(deletedRecord) {
      let checkdeleted = false;
      if (deletedRecord !== 0) {
        // eslint-disable-next-line no-alert
        const answer = window.confirm(`${deletedRecord} ${this.validationMessages.INPUTDELETERECORD}`);
        if (answer) {
          checkdeleted = true;
        } else {
          checkdeleted = false;
        }
      }
      return checkdeleted;
    },
    addProduct() {
      if (this.GeneralModel.productNames[this.GeneralModel.productNames.length - 1].name !== '') {
        const newProduct = { name: '', id: 0, isActive: true };
        this.GeneralModel.productNames.push(newProduct);
      }
    },
    addElementClass(product) {
      let delClass = 'icon-model-options AddDelBtn';
      if (product.name.trim() === '') {
        delClass = 'icon-model-options AddDelBtn disable-btn';
      }
      return delClass;
    },
    removeProduct(index) {
      this.ifAllProductDeleted = false;
      if (this.GeneralModel.productNames[index] !== undefined) {
        if (this.GeneralModel.productNames[index].id !== 0) {
          this.GeneralModel.productNames[index].isActive = !this.GeneralModel.productNames[index].isActive;
        } else {
          this.GeneralModel.productNames = this.GeneralModel.productNames.filter((hob, i) => i !== index);
        }
      }
    },
    handleCancel() {
      const cancel = showWindowConfrim();
      if (cancel) {
        if (!isNaN(this.modelId)) {
          this.isDisable = true;
          this.editMode = false;
          this.requireProduct = false;
          this.ifAllProductDeleted = false;
          this.apiErrors = [];
          this.$emit('togglePanel', !this.editMode, this.itemIndex);
          this.getGeneralDetailData(this.modelId);
        } else {
          this.ifAllProductDeleted = false;
          this.GeneralModel = JSON.parse(JSON.stringify(this.retainGeneralModel));
        }
      }
    },
    onChildCancelClicked() {
      if (!isNaN(this.modelId)) {
        this.isDisable = true;
        this.editMode = false;
        this.requireProduct = false;
        this.ifAllProductDeleted = false;
        this.apiErrors = [];
        this.$emit('togglePanel', !this.editMode, this.itemIndex);
        this.getGeneralDetailData(this.modelId);
      } else {
        this.ifAllProductDeleted = false;
        this.GeneralModel = JSON.parse(JSON.stringify(this.retainGeneralModel));
      }
    },
    onEditClicked() {
      this.editMode = true;
      this.isDisable = false;
      this.$emit('togglePanel', !this.editMode, this.itemIndex);
    },
    resetFormData() {
      if (isNaN(this.modelId)) {
        this.GeneralModel = JSON.parse(JSON.stringify(this.retainGeneralModel));
      }
      this.ifAllProductDeleted = false;
      this.submitted = false;
      this.apiErrors = [];
      this.$v.$reset();
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#GeneralDetails .input-group {
  display: block;
}
.disabled-anchor {
  cursor: not-allowed;
  color: gray;
}

.k-checkbox:checked {
  border-color: #0053a0;
  background-color: #0053a0;
}

.custom-multiselect li.k-button {
  border-color: rgba(0, 0, 0, 0.15);
  color: #4e4d4d;
  background-color: #eeeeee;
  background-image: linear-gradient(#eeeeee, #e5e5e5);
}
</style>


