<template>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseThree"
          aria-expanded="false"
          aria-controls="collapseThree"
          @click="clickPanel"
        >Accounting</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseThree"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseThree"
      class="collapse"
      aria-labelledby="headingThree"
      data-parent="#accordion"
    >
      <div class="card-body">
        <form id="Accounting">
          <div class="row" style="border-bottom: 1px solid #efefef;">
            <div class="col-md-12 text-right mb-1 mt-1">
              <div v-if="!editMode">
                <button type="button" class="edit-btn" @click.prevent="onEditClicked">Edit</button>
              </div>
              <div v-else>
                <button
                  type="button"
                  class="save-btn mr-1"
                  :disabled="isDisable"
                  @click.prevent="handleSubmit"
                >Save</button>

                <button type="button" class="cancel-btn" @click.prevent="handleCancel">Cancel</button>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-4 col-md-6">
              <div class="form-group">
                <label>
                  GTIN
                  <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                </label>
                <input
                  type="text"
                  v-model.trim="Accounting.gtin"
                  class="form-control"
                  :disabled="isDisable"
                />
                <p
                  v-if="submitted && !$v.Accounting.gtin.alphawithspace"
                  class="error-message"
                >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
              </div>
            </div>
            <div class="col-lg-4 col-md-6">
              <div class="form-group">
                <label>
                  Default Delivery Department
                  <i
                    class="fas fa-info-circle"
                    title="Lorem Ipsum is simply dummy"
                  ></i>
                </label>
                <select
                  v-model="Accounting.defaultDeliveryDepartment"
                  class="form-control"
                  :disabled="isDisable"
                >
                  <option value>Select</option>
                  <option
                    v-bind:value="mvalue.entityID"
                    v-for="mvalue in defaultDeliveryDepartmentOpt"
                  >{{ mvalue.entityName }}</option>
                </select>
                <p
                  v-if="submitted && !$v.Accounting.defaultDeliveryDepartment.required"
                  class="error-message"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
            <div class="col-lg-4 col-md-6">
              <div class="form-group">
                <label>
                  Sales Tax Code
                  <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                </label>
                <select
                  v-model="Accounting.salesTaxCode"
                  class="form-control"
                  :disabled="isDisable"
                >
                  <option value>Select</option>
                  <option
                    v-bind:value="mvalue.entityID"
                    v-for="mvalue in salesTaxCodeOpt"
                  >{{ mvalue.entityName }}</option>
                </select>
                <p
                  v-if="submitted && !$v.Accounting.salesTaxCode.required"
                  class="error-message"
                >{{validationMessages.REQUIRED}}</p>
              </div>
            </div>
            <div class="col-lg-4 col-md-6">
              <div class="form-group">
                <label>
                  Accounting Code for New Products
                  <i
                    class="fas fa-info-circle"
                    title="Lorem Ipsum is simply dummy"
                  ></i>
                </label>
                <input
                  type="text"
                  v-model="Accounting.CodeNewProduct"
                  class="form-control"
                  :disabled="isDisable"
                />
                <p
                  v-if="submitted && !$v.Accounting.CodeNewProduct.alphawithspace"
                  class="error-message"
                >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
              </div>
            </div>
            <div class="col-lg-4 col-md-6">
              <div class="form-group">
                <label>
                  Accounting Code for Used Products
                  <i
                    class="fas fa-info-circle"
                    title="Lorem Ipsum is simply dummy"
                  ></i>
                </label>
                <input
                  type="text"
                  v-model="Accounting.CodeforUsedProduct"
                  class="form-control"
                  :disabled="isDisable"
                />
                <p
                  v-if="submitted && !$v.Accounting.CodeforUsedProduct.alphawithspace"
                  class="error-message"
                >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import Vue from 'vue';
import Vuelidate from 'vuelidate';
import { required, helpers } from 'vuelidate/lib/validators';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import modelService from '../services/model-service';
import { ModelUrls, MasterUrls } from '../../../shared/constants/urls';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { showToast } from '../../../shared/services/toast-service';

Vue.use(Vuelidate);
const alphawithspace = helpers.regex('alpha', /^[0-9a-zA-Z ]+$/);
export default {
  name: 'Accounting',
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      submitted: false,
      isDisable: true,
      editMode: false,
      validationMessages: VALIDATION_MESSAGES,
      Accounting: {
        gtin: '',
        defaultDeliveryDepartment: '',
        salesTaxCode: '',
        CodeNewProduct: '',
        CodeforUsedProduct: ''
      },
      defaultDeliveryDepartmentOpt: [],
      salesTaxCodeOpt: [],
      modelId: null,
      apiErrors: []
    };
  },
  validations: {
    Accounting: {
      gtin: { alphawithspace },
      defaultDeliveryDepartment: { required },
      salesTaxCode: { required },
      CodeNewProduct: { alphawithspace },
      CodeforUsedProduct: { alphawithspace }
    }
  },
  created() {
    this.getMockData();
    this.modelId = this.$store.getters.getModelId;
    // If model id exist - view/edit mode
    if (this.modelId) {
      this.getAccountings(this.modelId);
    }
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    handleSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      this.$v.$touch();
      console.log(this.$v.$invalid);
      if (this.$v.$invalid) {
        return;
      }
      this.modelId = this.$store.getters.getModelId;
      const postData = {
        modelId: this.$store.getters.getModelId,
        gtin: this.Accounting.gtin,
        defaultDeliveryDeptId: this.Accounting.defaultDeliveryDepartment,
        salesTaxCodeId: this.Accounting.salesTaxCode,
        accountingCdNewProduct: this.Accounting.CodeNewProduct,
        accountingCdUsedProduct: this.Accounting.CodeforUsedProduct,
        userId: 1
      };

      // eslint-disable-next-line arrow-parens
      modelService.postModelRequest(`${ModelUrls.saveModelAccountingData}`, postData).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.isDisable = true;
          this.editMode = false;
          this.$emit('togglePanel', !this.editMode, this.itemIndex);
          this.getAccountings(this.modelId);
          showToast('success');
        } else {
          this.apiErrors = res.data.errors;
        }
      });
    },
    getAccountings(id) {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.getModelAccountingData}?modelId=${id}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          const result = res.data.data;
          this.Accounting.gtin = result.gtin;
          this.Accounting.defaultDeliveryDepartment = result.defaultDeliveryDeptId;
          this.Accounting.salesTaxCode = result.salesTaxCodeId;
          this.Accounting.CodeNewProduct = result.accountingCdNewProduct;
          this.Accounting.CodeforUsedProduct = result.accountingCdUsedProduct;
        } else {
          console.log(res.data.errors);
        }
      });
    },
    getMockData() {
      // eslint-disable-next-line arrow-parens
      modelService
        .getModelListResult(`${MasterUrls.getMasterMockup}?identifier=SalesTaxCode%7CDefaultDeliveryDepartment`)
        // eslint-disable-next-line arrow-parens
        .then(res => {
          this.defaultDeliveryDepartmentOpt = res.data.data.DefaultDeliveryDepartment;
          this.salesTaxCodeOpt = res.data.data.SalesTaxCode;
        });
    },
    handleCancel() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.getAccountings(this.modelId);
        this.isDisable = true;
        this.editMode = false;
        this.submitted = false;
        this.$v.$reset();
        this.$emit('togglePanel', !this.editMode, this.itemIndex);
      }
    },
    onChildCancelClicked() {
      this.getAccountings(this.modelId);
      this.isDisable = true;
      this.editMode = false;
      this.submitted = false;
      this.$v.$reset();
      this.$emit('togglePanel', !this.editMode, this.itemIndex);
    },
    onEditClicked() {
      this.editMode = true;
      this.isDisable = false;
      this.$emit('togglePanel', !this.editMode, this.itemIndex);
    }
  }
};
</script>
<style scoped>
</style>