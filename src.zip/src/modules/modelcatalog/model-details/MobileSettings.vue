<template>
  <div class="card">
    <div class="card-header" id="headingFive">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseFive"
          aria-expanded="false"
          aria-controls="collapseThree"
          @click="clickPanel"
        >Mobile Settings</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseFive"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div id="collapseFive" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid #efefef;">
          <div class="col-md-12 text-right mb-1 mt-1">
            <button
              v-if="!editMode"
              type="button"
              class="edit-btn"
              @click.prevent="onEditClicked"
            >Edit</button>
            <div v-else>
              <button
                type="button"
                class="save-btn mr-1"
                :disabled="isDisable"
                @click.prevent="handleSubmit"
              >Save</button>
              <button type="button" class="cancel-btn" @click.prevent="handleCancel">Cancel</button>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="mobilePro">
              <div class="custom-control custom-checkbox">
                <input
                  :disabled="isDisable"
                  type="checkbox"
                  v-model="MobSettingModel.isMobileAppModel"
                  class="custom-control-input"
                  id="customCheck5"
                />
                <label class="custom-control-label" for="customCheck5">Display in Mobile App</label>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="mobilePro">
              <div class="custom-control custom-checkbox">
                <input
                  :disabled="isDisable"
                  type="checkbox"
                  v-model="MobSettingModel.isFeaturedMobileProduct"
                  class="custom-control-input"
                  id="customCheck6"
                />
                <label class="custom-control-label" for="customCheck6">Featured Mobile Product</label>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 mt-2">
            <div class="form-group">
              <label>
                Featured Product Description
                <i
                  class="fas fa-info-circle"
                  title="Lorem Ipsum is simply dummy"
                ></i>
              </label>
              <textarea
                :disabled="isDisable"
                v-model="MobSettingModel.featuredProductDescription"
                class="form-control"
                rows="5"
                id="prodDescription"
              ></textarea>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import modelService from '../services/model-service';
import { ModelUrls } from '../../../shared/constants/urls';
import { showToast } from '../../../shared/services/toast-service';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

export default {
  name: 'MobileSettings',
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      submitted: false,
      isDisable: true,
      editMode: false,
      MobSettingModel: {
        isMobileAppModel: false,
        isFeaturedMobileProduct: false,
        featuredProductDescription: ''
      },
      modelId: null,
      apiErrors: []
    };
  },

  created() {
    this.modelId = this.$store.getters.getModelId;
    // If model id exist - view/edit mode
    if (this.modelId) {
      this.getMobileSettings(this.modelId);
    }
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    handleSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      this.MobSettingModel.modelId = this.$store.getters.getModelId;
      this.MobSettingModel.userId = 1;
      // this.MobSettingModel.isMobileAppModel = this.MobSettingModel.isMobileAppModel;
      // this.MobSettingModel.isFeaturedMobileProduct = this.MobSettingModel.isFeaturedMobileProduct;

      // this.modelId = this.$store.getters.getModelId;
      // eslint-disable-next-line arrow-parens
      modelService.postModelRequest(`${ModelUrls.saveMobileSettings}`, this.MobSettingModel).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.isDisable = true;
          this.editMode = false;
          this.getMobileSettings(this.modelId);
          this.$emit('togglePanel', !this.editMode, this.itemIndex);
          showToast('success');
        } else {
          this.apiErrors = res.data.errors;
        }
      });
    },
    getMobileSettings(id) {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.getModelMobileSettings}?modelId=${id}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          const result = res.data.data;
          this.MobSettingModel.isMobileAppModel = result.isMobileAppModel;
          this.MobSettingModel.isFeaturedMobileProduct = result.isFeaturedMobileProduct;
          this.MobSettingModel.featuredProductDescription = result.featuredProductDescription;
        } else {
          console.log(res.data.errors);
        }
      });
    },
    onEditClicked() {
      this.editMode = true;
      this.isDisable = false;
      this.$emit('togglePanel', !this.editMode, this.itemIndex);
    },
    handleCancel() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.getMobileSettings(this.modelId);
        this.isDisable = true;
        this.editMode = false;
        this.$emit('togglePanel', !this.editMode, this.itemIndex);
      }
    },
    onChildCancelClicked() {
      this.getMobileSettings(this.modelId);
      this.isDisable = true;
      this.editMode = false;
      this.$emit('togglePanel', !this.editMode, this.itemIndex);
    },
    checkboxMobile() {
      this.MobSettingModel.isMobileAppModel = !this.MobSettingModel.isMobileAppModel;
    },
    // eslint-disable-next-line no-unused-vars
    checkboxFeature() {
      // eslint-disable-next-line no-param-reassign
      this.MobSettingModel.isFeaturedMobileProduct = !this.MobSettingModel.isFeaturedMobileProduct;
      // if (e.target.checked) {
      //   this.isMobileAppModel = false;
      //   this.isFeaturedMobileProduct = false;
      // }
    }
  }
};
</script>
