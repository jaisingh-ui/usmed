<template>
  <div class="card">
    <div class="card-header" id="headingFour">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseFour"
          aria-expanded="false"
          aria-controls="collapseFour"
          @click="clickPanel"
        >Additional Information</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseFour"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid #efefef;">
          <div class="col-md-12 text-right mb-1 mt-1">
            <button
              v-if="!editMode"
              type="button"
              class="edit-btn"
              @click.prevent="onEditClicked"
            >Edit</button>
            <div v-else>
              <button
                type="button"
                class="save-btn mr-1"
                :disabled="isDisable"
                @click.prevent="handleSubmit"
              >Save</button>
              <button type="button" class="cancel-btn" @click.prevent="handleCancel">Cancel</button>
            </div>
          </div>
        </div>
        <div>
          <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
            <span class="k-loading-text">Loading...</span>
            <div class="k-loading-image">
              <div class="k-loading-color"></div>
            </div>
          </div>
          <!-- Api response errors -->
          <div
            class="alert alert-warning alert-dismissible fade show text-center"
            role="alert"
            v-if="apiErrors.length > 0"
          >
            <div v-for="message in apiErrors">{{message.userMessage}}</div>
          </div>
          <div class="row pt-3">
            <div class="col-lg-3 col-md-12">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Tag Placement</label>
                  </div>
                  <div v-if="image" class="imageArea">
                    <div class="img-warea">
                      <img :src="image" />
                    </div>
                    <button @click="removeImage" class="img-delete-btn">
                      <span class="fa fa-trash"></span>
                    </button>
                  </div>

                  <div v-else-if="AdditionalModel.imageFileName" class="imageArea">
                    <div class="img-warea">
                      <img :src="AdditionalModel.imageFileName" />
                    </div>
                    <button
                      :disabled="isDisable"
                      @click="removeServerImage()"
                      class="img-delete-btn"
                    >
                      <span class="fa fa-trash"></span>
                    </button>
                  </div>

                  <div v-else class="imageArea">
                    <div class="input-group mb-3 position-absolute">
                      <div class="custom-file">
                        <input
                          :disabled="isDisable"
                          type="file"
                          class="custom-file-input"
                          id="image"
                          ref="image"
                          placeholder="Upload Image"
                          accept="image/jpeg, image/png"
                          @change="onFileChange"
                        />
                      </div>
                      <div class="input-group-append">
                        <i class="fa fa-plus" aria-hidden="true"></i>
                      </div>
                    </div>
                  </div>

                  <!-- <div v-if="image" class="form-group">
                    <label>Image Name</label>
                    <input disabled="true" type="text" v-model="FileName" class="form-control" />
                    <p v-if="FileName == ''" class="error-message">{{validationMessages.REQUIRED}}</p>
                  </div>-->
                  <div class="form-group">
                    <label>Image Name</label>
                    <input
                      :disabled="isDisable"
                      type="text"
                      v-model="AdditionalModel.imageName"
                      class="form-control"
                    />
                    <p
                      v-if="submitted && !$v.AdditionalModel.imageName.required"
                      class="error-message"
                    >{{validationMessages.REQUIRED}}</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-9 col-md-12">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>
                      Handling Instructions
                      <i
                        class="fas fa-info-circle"
                        title="Lorem Ipsum is simply dummy"
                      ></i>
                    </label>
                    <textarea
                      :disabled="isDisable"
                      v-model="AdditionalModel.handlingInstructions"
                      class="form-control"
                      rows="3"
                      id="comment"
                      maxlength="500"
                    ></textarea>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>
                      Reorder Level
                      <i
                        class="fas fa-info-circle"
                        title="Only for Parts and Disposables"
                      ></i>
                    </label>
                    <input
                      :disabled="isDisable"
                      type="text"
                      oninput="validity.valid||(value='');"
                      min="1"
                      pattern="\d*"
                      maxlength="20"
                      v-model="AdditionalModel.parLevel"
                      class="form-control"
                    />
                    <small>Only for Parts and Disposables</small>
                    <p
                      v-if="!$v.AdditionalModel.parLevel.integer"
                      class="error-message"
                    >{{validationMessages.INTEGER}}</p>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>
                      Reorder Quantity
                      <i
                        class="fas fa-info-circle"
                        title="Lorem Ipsum is simply dummy"
                      ></i>
                    </label>
                    <input
                      :disabled="isDisable"
                      type="text"
                      oninput="validity.valid||(value='');"
                      min="1"
                      pattern="\d*"
                      maxlength="20"
                      v-model="AdditionalModel.reorderQuantity"
                      class="form-control"
                    />
                    <small>Only for Parts and Disposables</small>
                    <p
                      v-if="!$v.AdditionalModel.reorderQuantity.integer"
                      class="error-message"
                    >{{validationMessages.INTEGER}}</p>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>
                      Standard Warranty
                      <i
                        class="fas fa-info-circle"
                        title="Lorem Ipsum is simply dummy"
                      ></i>
                    </label>
                    <select
                      :disabled="isDisable"
                      v-model="AdditionalModel.warrantyId"
                      class="form-control"
                    >
                      <option value>Select</option>
                      <option
                        v-bind:value="mvalue.entityID"
                        v-for="mvalue in standardWarrantyOpt"
                      >{{ mvalue.entityName }}</option>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>
                      Warranty URL
                      <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                    </label>
                    <input
                      :disabled="isDisable"
                      type="text"
                      v-model="AdditionalModel.warrantyURL"
                      class="form-control"
                    />
                    <p
                      class="error-message"
                      v-if="!$v.AdditionalModel.warrantyURL.url"
                    >{{validationMessages.URL}}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label>
                  Metatags
                  <i class="fas fa-info-circle" title="Lorem Ipsum is simply dummy"></i>
                </label>
                <input
                  :disabled="isDisable"
                  type="text"
                  v-model="AdditionalModel.metaTags"
                  class="form-control"
                />
                <p
                  v-if="!$v.AdditionalModel.metaTags.alphawithcomma"
                  class="error-message"
                >{{validationMessages.ALPHA_NUMERIC_ONLY}}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import Vue from 'vue';
import Vuelidate from 'vuelidate';
import { required, requiredIf, url, integer, helpers } from 'vuelidate/lib/validators';
import { StandardWarranty } from '../services/model-mockup';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import baseService from '../../../shared/services/base-service';
import modelService from '../services/model-service';
import { ModelUrls, MasterUrls } from '../../../shared/constants/urls';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { showToast } from '../../../shared/services/toast-service';

Vue.use(Vuelidate);
const alphawithspace = helpers.regex('alpha', /^[0-9a-zA-Z ]+$/);
// eslint-disable-next-line no-useless-escape
const alphawithcomma = helpers.regex('alpha', /^[a-zA-Z0-9\,\s]{0,200}$/);
export default {
  name: 'AdditionalInformation',
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      isDisable: true,
      submitted: false,
      editMode: false,
      showLoader: false,
      newFile: '',
      image: '',
      validationMessages: VALIDATION_MESSAGES,
      AdditionalModel: {
        modelId: 0,
        handlingInstructions: '',
        parLevel: '',
        reorderQuantity: '',
        standardWarranty: '',
        warrantyId: '',
        warrantyURL: '',
        metaTags: '',
        imageId: 0,
        imageName: '',
        FileName: '',
        imageFileName: ''
      },
      standardWarrantyOpt: '',
      modelId: null,
      apiErrors: []
    };
  },
  validations: {
    AdditionalModel: {
      imageName: {
        required: requiredIf(function(vm) {
          if (this.newFile.name || vm.imageFileName) {
            return true;
          }
          return false;
        })
      },
      parLevel: { integer },
      reorderQuantity: { integer },
      warrantyURL: { url },
      metaTags: { alphawithcomma }
    }
  },
  created() {
    this.getMockData();
    this.modelId = this.$store.getters.getModelId;
    // If model id exist - view/edit mode
    if (this.modelId) {
      this.getAddionalInformations(this.modelId);
    }
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    getMockData() {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${MasterUrls.getMasterMockup}?identifier=StandardWarranty`).then(res => {
        if (res) {
          this.standardWarrantyOpt = res.data.data.StandardWarranty;
        }
      });
    },
    handleSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      this.$v.$touch();
      console.log('validation', this.$v.$invalid);
      if (this.$v.$invalid) {
        return;
      }

      this.saveAdditionalInfoAPI();
    },
    saveAdditionalInfoAPI() {
      console.log(this.AdditionalModel);
      this.showLoader = true;
      this.isDisable = true;
      const formData = new FormData();

      this.modelId = this.$store.getters.getModelId;
      //if (this.AdditionalModel.warrantyId !== null) {
      formData.append('warrantyId', this.AdditionalModel.warrantyId);
      //}

      if (this.AdditionalModel.imageId > 0) {
        formData.append('imageId', this.AdditionalModel.imageId);
        formData.append('ImageName', this.AdditionalModel.imageName);
        formData.append('imageFileName', this.AdditionalModel.imageFileName);
      } else if (this.newFile) {
        formData.append('imageId', 0);
        formData.append('ImageName', this.AdditionalModel.imageName);
        formData.append('newFile', this.newFile);
      }

      formData.append('handlingInstructions', this.AdditionalModel.handlingInstructions ? this.AdditionalModel.handlingInstructions : '');
      formData.append('parLevel', this.AdditionalModel.parLevel ? this.AdditionalModel.parLevel : 0);
      formData.append('reorderQuantity', this.AdditionalModel.reorderQuantity ? this.AdditionalModel.reorderQuantity : 0);
      formData.append('warrantyURL', this.AdditionalModel.warrantyURL ? this.AdditionalModel.warrantyURL : '');
      formData.append('metaTags', this.AdditionalModel.metaTags ? this.AdditionalModel.metaTags : '');
      formData.append('modelId', this.$store.getters.getModelId);
      formData.append('userId', 1);

      baseService
        .fileUploadRequest(`${ModelUrls.saveModelAdditionalInfo}`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
        // eslint-disable-next-line arrow-parens
        .then(res => {
          this.showLoader = false;
          this.isDisable = true;
          this.editMode = false;
          this.getAddionalInformations(this.modelId);
          this.$emit('togglePanel', !this.editMode, this.itemIndex);
          if (res.data.apiResponseStatus !== 'Failed') {
            showToast('success');
          } else {
            this.apiErrors = res.data.errors;
          }
        })
        .catch(error => {
          this.showLoader = false;
        });
    },
    getAddionalInformations(id) {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.getModelAdditionalInfo}?modelId=${id}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          const result = res.data.data;
          // eslint-disable-next-line no-console
          console.log(result, 'getdata');
          // this.standardWarrantyOpt = StandardWarranty;
          // this.AdditionalModel = result;
          this.AdditionalModel.modelId = result.modelId;
          this.AdditionalModel.handlingInstructions = result.handlingInstructions;
          this.AdditionalModel.parLevel = result.parLevel === 0 ? '' : result.parLevel;
          this.AdditionalModel.reorderQuantity = result.reorderQuantity === 0 ? '' : result.reorderQuantity;
          this.AdditionalModel.standardWarranty = result.standardWarranty;
          this.AdditionalModel.warrantyURL = result.warrantyURL;
          this.AdditionalModel.warrantyId = result.warrantyId !== null ? result.warrantyId : '';
          this.AdditionalModel.metaTags = result.metaTags;
          this.AdditionalModel.imageId = result.imageId;
          this.AdditionalModel.imageName = result.imageName;
          this.AdditionalModel.imageFileName = result.imageFileName;
          this.AdditionalModel.userId = result.userId;
        } else {
          console.log(res.data.errors);
        }
      });
    },

    onEditClicked() {
      this.editMode = true;
      this.isDisable = false;
      this.$emit('togglePanel', !this.editMode, this.itemIndex);
    },
    handleCancel() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.isDisable = true;
        this.editMode = false;
        this.submitted = false;
        this.$v.$reset();
        this.getAddionalInformations(this.modelId);
        this.$emit('togglePanel', !this.editMode, this.itemIndex);
      }
    },
    onChildCancelClicked() {
      this.isDisable = true;
      this.editMode = false;
      this.submitted = false;
      this.$v.$reset();
      this.getAddionalInformations(this.modelId);
      this.$emit('togglePanel', !this.editMode, this.itemIndex);
    },
    // Handles a change on the file upload
    onFileChange(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) {
        return;
      }

      let ext = files[0].name.split('.')[1].toLowerCase();
      if (ext !== 'jpeg' && ext !== 'jpg' && ext !== 'png') {
        alert('Please upload only jpeg/png format iamges');
        return;
      }

      let filesize = files[0].size;
      if (filesize > 5242880) {
        // 5 MB LIMIT
        alert('Maximum image size is 5 MB');
        return;
      }

      this.createImage(files[0]);
      this.AdditionalModel.imageName = files[0].name;
      this.newFile = files[0];
    },
    createImage(file) {
      // const image = new Image();
      const reader = new FileReader();
      const vm = this;
      vm.FileName = file.name;
      // eslint-disable-next-line arrow-parens
      reader.onload = e => {
        vm.image = e.target.result;
      };
      reader.readAsDataURL(file);
    },
    removeImage() {
      this.image = '';
    },
    removeServerImage() {
      if (confirm('Do you really want to delete this image?')) {
        this.showLoader = true;
        const postData = {};
        postData.imageId = this.AdditionalModel.imageId;
        postData.imageUrl = this.AdditionalModel.imageFileName;
        postData.userId = 1;

        /* Make the request to the POST /Azure API URL */
        // eslint-disable-next-line arrow-parens
        modelService.deleteModelRequest(`${ModelUrls.removeImage}`, postData).then(res => {
          const result = res.data;
          this.showLoader = false;
          // eslint-disable-next-line no-console
          console.log(result, 'DeleteImage');
          this.AdditionalModel.imageFileName = '';
          this.AdditionalModel.imageName = '';
        });
      }
    }
  }
};
</script>
<style scoped>
</style>