<template>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseTwo"
          aria-expanded="false"
          aria-controls="collapseTwo"
          @click="clickPanel"
        >Model Image</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseTwo"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body">
        <div class="row">
          <div class="col-md-12 text-right mb-2 mt-2">
            <button
              v-if="!editMode"
              type="button"
              class="edit-btn"
              @click.prevent="onEditClicked"
            >Edit</button>
            <div v-else>
              <button
                type="button"
                class="save-btn mr-1"
                :disabled="isDisable"
                @click.prevent="handleSubmit"
              >Save</button>
              <button type="button" class="cancel-btn" @click.prevent="handleCancel">Cancel</button>
            </div>
          </div>
        </div>
        <!-- Loder appear here -->
        <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
          <span class="k-loading-text">Loading...</span>
          <div class="k-loading-image">
            <div class="k-loading-color"></div>
          </div>
        </div>
        <!-- Api response errors -->
        <div
          class="alert alert-warning alert-dismissible fade show text-center"
          role="alert"
          v-if="apiErrors.length > 0"
        >
          <div v-for="message in apiErrors">{{message.userMessage}}</div>
        </div>
        <!-- image appear here-->
        <div class="row">
          <div
            v-if="serverFiles.length > 0"
            class="col-lg-3 col-md-6"
            v-for="(image, index) in serverFiles"
            :key="index"
          >
            <div class="imageArea model-imageArea">
              <div class="img-warea">
                <img v-if="image.imageID > 0" :src="image.imageFileName" :ref="'image'" />
                <img v-else :ref="'image'" />
              </div>
              <button
                v-if="editMode"
                @click="image.imageID > 0 ? removeServerImage(image, index) : removeImage(index)"
                class="img-delete-btn"
              >
                <span class="fas fa-trash"></span>
              </button>
            </div>
            <div class="form-group">
              <div class="custom-control custom-radio">
                <input
                  :disabled="isDisable"
                  type="radio"
                  :id="index"
                  name="customRadio"
                  class="custom-control-input"
                  :value="index"
                  v-model="isPrimary"
                />
                <label class="custom-control-label" :for="index">Primary</label>
              </div>
              <label>Image Name</label>
              <input
                :disabled="isDisable"
                type="text"
                v-model="image.imageName"
                class="form-control"
              />
              <p
                v-if="!$v.serverFiles.$each[index].imageName.required"
                class="error-message"
              >{{validationMessages.REQUIRED}}</p>
              <p
                v-if="!$v.serverFiles.$each[index].imageName.alphaWithSpecialChar"
                class="error-message"
              >{{validationMessages.INVALIDMODELOPTION}}</p>
            </div>
          </div>

          <div v-if="totalFilesLength < 4" class="col-lg-3 col-md-6">
            <div class="imageArea model-imageArea">
              <div class="input-group mb-3 position-absolute">
                <div class="custom-file">
                  <input
                    :disabled="isDisable"
                    type="file"
                    multiple
                    class="custom-file-input"
                    id="files"
                    placeholder="Upload Image"
                    accept="image/jpeg, image/png"
                    @change="onFileChange"
                  />
                </div>
                <div class="input-group-append">
                  <i class="fa fa-plus" aria-hidden="true"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import Vue from 'vue';
import axios from 'axios';
import { required, helpers } from 'vuelidate/lib/validators';
import baseService from '../../../shared/services/base-service';
import filesMixin from '../../../shared/MixinLib/files-functions';
import modelService from '../services/model-service';
import { ModelUrls } from '../../../shared/constants/urls';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { showToast } from '../../../shared/services/toast-service';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
const alphaWithSpecialChar = helpers.regex('alphaWithSpecialChar', /^[a-zA-Z0-9' , . _ # -]*$/);
export default {
  name: 'ModelImage',
  mixins: [filesMixin],
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      validationMessages: VALIDATION_MESSAGE,
      modelId: null,
      submitted: false,
      isDisable: true,
      editMode: false,
      isServer: false,
      showPanel: true,
      showLoader: false,
      totalFilesLength: 0,
      serverFiles: [],
      images: [],
      imageName: [],
      isPrimary: 0,
      imgCounter: 0,
      apiErrors: []
    };
  },
  validations: {
    serverFiles: {
      $each: {
        imageName: { required, alphaWithSpecialChar }
      }
    }
  },
  created() {
    this.modelId = this.$store.getters.getModelId;
    // If model id exist - view/edit mode
    if (!isNaN(this.modelId)) {
      this.getModelImages(this.modelId);
    }
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    getModelImages(id) {
      this.showLoader = true;
      this.serverFiles = [];
      baseService.getRequest(`${ModelUrls.ModelImages}?modelId=${id}`).then(res => {
        this.showLoader = false;
        if (res.data.apiResponseStatus !== 'Failed') {
          const result = res.data.data;
          this.serverFiles = result.modelDisplayImages;
          this.isPrimary = result.primaryImageIndex === -1 ? '0' : result.primaryImageIndex;
          this.totalFilesLength = this.serverFiles.length;
        } else {
          console.log(res.data.errors);
        }
      });
    },
    readAndshowImages(files) {
      console.log(files);
      for (let i = 0; i < files.length; i++) {
        let imgFile = files[i];
        if (typeof imgFile.file !== 'undefined') {
          let reader = new FileReader();
          // reader.onload = e => {
          //   this.$refs.image[i].src = reader.result;
          // };
          reader.addEventListener(
            'load',
            function() {
              this.$refs.image[i].src = reader.result;
            }.bind(this),
            false
          );
          //this.imageName[i] = imgFile.name;
          reader.readAsDataURL(imgFile.file);
        }
      }
    },
    // Handles a change on the file upload
    onFileChange(e) {
      //let vm = this;
      let selectedFiles = e.target.files;

      /* Check total image count in box. */
      this.totalFilesLength = parseInt(selectedFiles.length + this.serverFiles.length);
      console.log(this.totalFilesLength);
      if (this.totalFilesLength > 4) {
        alert('Maximum 4 images can be uploaded');
        this.totalFilesLength = 0;
        return;
      }

      /* check valid image extentions */
      const isValidExt = this.extImageValidationinLoop(selectedFiles);
      if (!isValidExt) {
        this.totalFilesLength = 0;
        return;
      }
      const isValidSize = this.sizeImageValidationinLoop(selectedFiles);
      if (!isValidSize) {
        this.totalFilesLength = 0;
        return;
      }

      for (let imgFile of selectedFiles) {
        this.serverFiles.push({ file: imgFile, imageName: imgFile.name });
      }

      this.readAndshowImages(this.serverFiles);
    },

    promiseSuccess() {
      this.showLoader = false;
      this.isDisable = true;
      this.editMode = false;
      this.getModelImages(this.modelId);
      showToast('success');
      // moved to saved state
      this.$emit('togglePanel', !this.editMode, this.itemIndex);
    },
    promiseError() {
      this.showLoader = false;
      this.isDisable = true;
      this.editMode = false;
      this.getModelImages(this.modelId);
    },
    handleSubmit() {
      if (this.isPrimary < 0) {
        alert('Please select primary image');
        return;
      }
      // stop here if form is invalid
      this.$v.$touch();
      console.log('validation', this.$v.$invalid);
      if (this.$v.$invalid) {
        return;
      }
      this.asyncFileUpload();
    },
    // Submits the file to the server
    asyncFileUpload() {
      this.showLoader = true;
      this.modelId = this.$store.getters.getModelId;
      console.log(this.serverFiles);
      const totalFiles = this.serverFiles;
      let promises = [];
      // eslint-disable-next-line no-plusplus
      for (let index = 0; index < totalFiles.length; index++) {
        const file = totalFiles[index];
        let formData = new FormData();
        if (typeof file.file !== 'undefined') {
          formData.append('imageId', 0);
          formData.append('imageFile', file.file);
          //formData.append('imageName', typeof this.imageName[index] === 'undefined' ? file.name : this.imageName[index]);
          formData.append('imageName', file.imageName);
          formData.append('imageFileName', file.imageName);
          formData.append('isPrimaryImage', this.isPrimary === index ? true : false);
          formData.append('isTagIdentifier', false);
          formData.append('isThumbNail', false);
          formData.append('isActive', true);
          formData.append('modelID', this.modelId);
          formData.append('userId', 1);
        } else {
          formData.append('imageId', file.imageID);
          formData.append('imageFile', null);
          formData.append('imageName', file.imageName);
          formData.append('imageFileName', file.imageFileName);
          formData.append('isPrimaryImage', this.isPrimary === index ? true : false);
          formData.append('isTagIdentifier', false);
          formData.append('isThumbNail', false);
          formData.append('isActive', true);
          formData.append('modelID', this.modelId);
          formData.append('userId', 1);
        }
        promises.push(
          baseService
            .fileUploadRequest(`${ModelUrls.ModelImages}`, formData, {
              headers: {
                'Content-Type': 'multipart/form-data'
              }
            })
            .then(res => {
              if (res.data.apiResponseStatus !== 'Failed') this.imgCounter++;
              else this.apiErrors = res.data.errors;
            })
        );
      }
      Promise.all(promises)
        .then(res => {
          this.promiseSuccess();
        })
        .catch(error => {
          this.promiseError();
        });
    },
    handleCancel() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.totalFilesLength = 0;
        this.isDisable = true;
        this.editMode = false;
        this.getModelImages(this.modelId);
        this.$emit('togglePanel', !this.editMode, this.itemIndex);
      }
    },
    onChildCancelClicked() {
      this.totalFilesLength = 0;
      this.isDisable = true;
      this.editMode = false;
      this.getModelImages(this.modelId);
      this.$emit('togglePanel', !this.editMode, this.itemIndex);
    },
    onEditClicked() {
      this.editMode = true;
      this.isDisable = false;
      this.$emit('togglePanel', !this.editMode, this.itemIndex);
    },
    removeImage(i) {
      console.log(i);
      this.serverFiles.splice(i, 1);
      this.readAndshowImages(this.serverFiles);
      this.totalFilesLength = 0;
    },
    async removeServerImage(image, index) {
      if (confirm('Do you really want to delete this image?')) {
        this.showLoader = true;
        const postData = {};
        postData.imageId = image.imageID;
        postData.imageUrl = image.imageFileName;
        postData.userId = 1;

        /* Make the request to the POST /Azure API URL */
        await modelService.deleteModelRequest(`${ModelUrls.removeImage}`, postData).then(res => {
          if (res) {
            this.serverFiles.splice(index, 1);
            this.totalFilesLength = 0;
            this.getModelImages(this.modelId);
          } else {
            console.log(res);
          }
          this.showLoader = false;
        });
      }
    }
  }
};
</script>
<style scoped>
.model-imageArea {
  height: 200px;
}

.model-imageArea .img-warea {
  height: 200px;
}
</style>