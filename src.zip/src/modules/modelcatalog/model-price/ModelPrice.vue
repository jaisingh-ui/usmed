<template>
  <div class="row">
    <div class="col-md-12">
      <div class="formTabSection">
        <div id="accordion">
          <div class="card">
            <div class="card-header" id="headingOne">
              <h5 class="mb-0">
                <button
                  class="btn btn-link"
                  data-toggle="collapse"
                  data-target="#collapseOne"
                  aria-expanded="true"
                  aria-controls="collapseOne"
                >Pricing</button>
              </h5>
              <div class="rightInfotext">
                <i class="fa fa-angle-down" data-toggle="collapse" data-target="#collapseOne"></i>
              </div>
            </div>

            <div
              id="collapseOne"
              class="collapse show"
              aria-labelledby="headingOne"
              data-parent="#accordion"
            >
              <div class="card-body">
                <div class="row" style="border-bottom: 1px solid #efefef;">
                  <div class="col-md-12 text-right mb-1 pt-1">
                    <div class="workingBtn" v-if="editMode">
                      <button type="button" class="edit-btn" @click.prevent="onEditClicked">Edit</button>
                    </div>
                    <div v-if="!editMode">
                      <button
                        type="button"
                        class="save-btn mr-1"
                        @click.prevent="onSaveClicked"
                      >Save</button>
                      <button
                        type="button"
                        class="cancel-btn"
                        @click.prevent="onCancelClicked"
                      >Cancel</button>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-4 col-md-6">
                    <div class="form-group">
                      <label>
                        Standard Monthly Price for Rental
                        <i
                          class="fa fa-info-circle"
                          aria-hidden="true"
                          title="Standard Monthly Price for Rental in $"
                        ></i>
                      </label>
                      <input
                        :disabled="editMode"
                        type="number"
                        :class="{'form-control':true, 'invalid-input':$v.modelPricing.standardMonthlyPrice.$error && modelPricing.standardMonthlyPrice!==null}"
                        v-model="modelPricing.standardMonthlyPrice"
                        @input="$v.modelPricing.standardMonthlyPrice.$touch()"
                        @keypress="isNumber($event)"
                        step="0.01"
                        min="0.00"
                      />
                      <p
                        v-if="modelPricing.standardMonthlyPrice!==null && $v.modelPricing.standardMonthlyPrice.$error"
                        class="invalid-text"
                      >{{validationsMessages.DECIMALUPTO2PLACE}}</p>
                      <p
                        v-if="submitted && !$v.modelPricing.standardMonthlyPrice.required"
                        class="invalid-text"
                      >{{validationsMessages.REQUIRED}}</p>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6">
                    <div class="form-group">
                      <label>
                        Model Cost
                        <i
                          class="fa fa-info-circle"
                          aria-hidden="true"
                          title="Model Cost in $"
                        ></i>
                      </label>
                      <input
                        :disabled="disableModelCost? true:editMode"
                        type="number"
                        :class="{'form-control':true, 'invalid-input':$v.modelPricing.modelCostPrice.$error}"
                        v-model="modelPricing.modelCostPrice"
                        @input="$v.modelPricing.modelCostPrice.$touch()"
                        @keypress="isNumber($event)"
                        step="0.01"
                        min="0.00"
                      />
                      <span
                        v-if="modelPricing.modelCostPrice!==null && $v.modelPricing.modelCostPrice.$error"
                        class="invalid-text"
                      >{{validationsMessages.DECIMALUPTO2PLACE}}</span>
                      <p class="general-text">Based on last purchase price and average cost</p>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        List Sales Price
                        <i
                          class="fa fa-info-circle"
                          aria-hidden="true"
                          title="Model List Price in $"
                        ></i>
                      </label>
                      <div class="checkBoxinFrom">
                        <div class="checkbox-combine">
                          <div class="custom-control custom-checkbox">
                            <input
                              :disabled="editMode"
                              type="checkbox"
                              :class="(modelPricing.modelListPrice.value!=='' || modelPricing.modelListPrice.value!==null)?'custom-control-input': 'custom-control-input disabled'"
                              @change="onCheckChange(modelPricing.modelListPrice,modelPricing.modelListPrice.value, $event)"
                              id="customCheck10"
                              :checked="modelPricing.modelListPrice.isSelected"
                            />
                            <label
                              :class="modelPricing.modelListPrice.value!=='' ?'custom-control-label': 'custom-control-label disabled'"
                              for="customCheck10"
                            ></label>
                          </div>
                        </div>
                        <div class="input-combine">
                          <input
                            :disabled="editMode"
                            type="number"
                            :class="{'form-control':true, 'invalid-input':$v.modelPricing.modelListPrice.value.$error && modelPricing.modelListPrice.value!==null}"
                            v-model="modelPricing.modelListPrice.value"
                            @blur="modelPricingInputChanged()"
                            @keypress="isNumber($event)"
                            @input="$v.modelPricing.modelListPrice.value.$touch()"
                            step="0.01"
                            min="0.00"
                          />
                        </div>
                        <p
                          v-if="modelPricing.modelListPrice.value!==null && $v.modelPricing.modelListPrice.value.$error"
                          class="invalid-text"
                        >{{validationsMessages.DECIMALUPTO2PLACE}}</p>
                        <p
                          v-if="submitted && !$v.modelPricing.modelListPrice.value.required"
                          class="invalid-text"
                        >{{validationsMessages.REQUIRED}}</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        Web Sales Price
                        <i
                          class="fa fa-info-circle"
                          aria-hidden="true"
                          title="Model Web Price in $"
                        ></i>
                      </label>
                      <div class="checkBoxinFrom">
                        <div class="checkbox-combine">
                          <div class="custom-control custom-checkbox">
                            <input
                              :disabled="editMode"
                              type="checkbox"
                              :class="(modelPricing.modelWebPrice.value!=='' || modelPricing.modelWebPrice.value!==null)?'custom-control-input': 'custom-control-input disabled'"
                              id="customCheck11"
                              @change="onCheckChange(modelPricing.modelWebPrice,modelPricing.modelWebPrice.value, $event)"
                              :checked="modelPricing.modelWebPrice.isSelected"
                            />
                            <label
                              :class="modelPricing.modelWebPrice.value!=='' ?'custom-control-label': 'custom-control-label disabled' "
                              for="customCheck11"
                            ></label>
                          </div>
                        </div>
                        <div class="input-combine">
                          <input
                            :disabled="editMode"
                            type="number"
                            @blur="modelWebPriceInputChange()"
                            @keypress="isNumber($event)"
                            @input="$v.modelPricing.modelWebPrice.value.$touch()"
                            class="form-control"
                            v-model="modelPricing.modelWebPrice.value"
                            step="0.01"
                            min="0.00"
                          />
                        </div>
                        <p
                          class="invalid-text"
                          v-if="$v.modelPricing.modelWebPrice.value.$error"
                        >{{validationsMessages.DECIMALUPTO2PLACE}}</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>
                        Dealer Sales Price
                        <i
                          class="fa fa-info-circle"
                          aria-hidden="true"
                          title="Model Dealer Price in $"
                        ></i>
                      </label>
                      <div class="checkBoxinFrom">
                        <div class="checkbox-combine">
                          <div class="custom-control custom-checkbox">
                            <input
                              :disabled="editMode"
                              type="checkbox"
                              :class="(modelPricing.modelDealerPrice.value!=='' || modelPricing.modelDealerPrice.value!==null) ?'custom-control-input': 'custom-control-input disabled' "
                              id="customCheck12"
                              @change="onCheckChange(modelPricing.modelDealerPrice,modelPricing.modelDealerPrice.value, $event)"
                              :checked="modelPricing.modelDealerPrice.isSelected"
                            />
                            <label
                              :class="modelPricing.modelDealerPrice.value!=='' ?'custom-control-label': 'custom-control-label disabled' "
                              for="customCheck12"
                            >&nbsp;</label>
                          </div>
                        </div>
                        <div class="input-combine">
                          <input
                            :disabled="editMode"
                            type="number"
                            class="form-control"
                            @blur="modelDealerPriceInputChange()"
                            @keypress="isNumber($event)"
                            v-model="modelPricing.modelDealerPrice.value"
                            @input="$v.modelPricing.modelDealerPrice.$touch()"
                            step="0.01"
                            min="0.00"
                          />
                        </div>
                      </div>
                      <p
                        class="invalid-text"
                        v-if="$v.modelPricing.modelDealerPrice.value.$error"
                      >{{validationsMessages.DECIMALUPTO2PLACE}}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { required } from 'vuelidate/lib/validators';
import modelService from '../services/model-service';
import { ModelUrls } from '../../../shared/constants/urls';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { showToast } from '../../../shared/services/toast-service';

import VALIDATION_MESSAGES from '../../../shared/constants/messages';
// eslint-disable-next-line arrow-parens
const checkFloat = value => {
  if (typeof value === 'undefined' || value === null || value === '' || value === 0) {
    return true;
  }
  return /^\d+(\.\d{1,2})?$/.test(value);
};
export default {
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      modelPricing: {
        modelId: null,
        standardMonthlyPrice: 0,
        modelCostPrice: 0,
        modelListPrice: {
          value: 0,
          isSelected: false
        },
        modelWebPrice: {
          value: 0,
          isSelected: false
        },
        modelDealerPrice: {
          value: 0,
          isSelected: false
        },
        user: 0
      },
      modelId: null,
      opertaionMode: 'none',
      editMode: true,
      persistData: {},
      submitted: false,
      disableModelCost: false,
      disableModelListCheck: false
    };
  },
  validations: {
    modelPricing: {
      modelId: {},
      standardMonthlyPrice: {
        required,
        checkFloat
      },
      modelCostPrice: {
        checkFloat
      },
      modelListPrice: {
        value: { required, checkFloat },
        isSelected: {}
      },
      modelWebPrice: {
        value: { checkFloat },
        isSelected: {}
      },
      modelDealerPrice: {
        value: { checkFloat },
        isSelected: {}
      },
      userId: {}
    }
  },
  methods: {
    onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.submitted = false;
        this.callAPIToGetModelPricing();
      }
      return false;
    },
    onEditClicked() {
      this.editMode = false;
    },
    onSaveClicked() {
      this.submitted = true;
      if (this.$v.$invalid) {
        return;
      }
      this.$v.$touch();
      // eslint-disable-next-line max-len
      if (!this.$v.$anyDirty) {
        // eslint-disable-next-line no-console
        // this.$v.$touch();
      } else {
        if (this.modelPricing.modelDealerPrice.value === '' || this.modelPricing.modelDealerPrice.value === null) {
          this.modelPricing.modelDealerPrice.value = null;
        } else {
          this.modelPricing.modelDealerPrice.value = parseFloat(this.modelPricing.modelDealerPrice.value);
        }
        if (this.modelPricing.modelWebPrice.value === '' || this.modelPricing.modelWebPrice.value === null) {
          this.modelPricing.modelWebPrice.value = null;
        } else {
          this.modelPricing.modelWebPrice.value = parseFloat(this.modelPricing.modelWebPrice.value);
        }
        if (this.modelPricing.modelCostPrice === '' || this.modelPricing.modelCostPrice === null) {
          this.modelPricing.modelCostPrice = null;
        } else {
          this.modelPricing.modelCostPrice = parseFloat(this.modelPricing.modelCostPrice);
        }

        this.modelPricing.standardMonthlyPrice = parseFloat(this.modelPricing.standardMonthlyPrice);
        this.modelPricing.modelListPrice.value = parseFloat(this.modelPricing.modelListPrice.value);
        this.callAPIToSavePricing();
      }
    },
    parse2DecimalDigit(value) {
      return Number(parseFloat(value).toFixed(2)); // value.toFixed(2); // Number.parseFloat(value).toFixed(2);
    },
    callAPIToSavePricing() {
      // eslint-disable-next-line arrow-parens
      modelService.postModelsDataAction(ModelUrls.saveModelPricing, this.modelPricing).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.callAPIToGetModelPricing();
          showToast('success');
        }
      });
    },
    // eslint-disable-next-line no-unused-vars
    onCheckChange(selectedCheckBox, value, event) {
      if (value === null || value === '') {
        // eslint-disable-next-line no-param-reassign
        selectedCheckBox.isSelected = false;
        // eslint-disable-next-line no-param-reassign
        value = null;
      }
      if (!event.target.checked && value === null) {
        // eslint-disable-next-line no-param-reassign
        event.target.checked = !event.target.checked;
      } else {
        // eslint-disable-next-line no-param-reassign
        selectedCheckBox.isSelected = !selectedCheckBox.isSelected;
      }
    },
    onInputLeft(event) {
      // eslint-disable-next-line no-param-reassign
      const regexp = /^\d+(\.\d{1,2})?$/;
      if (!regexp.test(event.target.value)) {
        // eslint-disable-next-line no-param-reassign
        event.target.value = null;
      }
    },
    modelPricingInputChanged() {
      if (this.modelPricing.modelListPrice.value === '' || this.modelPricing.modelListPrice.value === null) {
        // eslint-disable-next-line no-param-reassign
        this.modelPricing.modelListPrice.isSelected = false;
      }
      if (this.$v.modelPricing.modelListPrice.$anyError) {
        this.modelPricing.modelListPrice.isSelected = false;
      }
    },
    modelDealerPriceInputChange() {
      if (this.modelPricing.modelDealerPrice.value === '' || this.modelPricing.modelDealerPrice.value === null) {
        this.modelPricing.modelDealerPrice.isSelected = false;
      }
    },
    modelWebPriceInputChange() {
      if (this.modelPricing.modelWebPrice.value === '' || this.modelPricing.modelWebPrice.value === null) {
        this.modelPricing.modelWebPrice.isSelected = false;
      }
    },
    callAPIToGetModelPricing() {
      this.disableModelCost = false;
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.getModelPricing}?modelId=${this.modelId}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed' && res.data.data) {
          this.modelPricing = res.data.data;
          if (this.modelPricing.modelCostPrice) {
            this.disableModelCost = true;
          }
          this.correctFloatingValues();
        } else {
          this.modelPricing = {
            modelId: this.modelId,
            standardMonthlyPrice: null,
            modelCostPrice: null,
            modelListPrice: {
              value: null,
              isSelected: false
            },
            modelWebPrice: {
              value: null,
              isSelected: false
            },
            modelDealerPrice: {
              value: null,
              isSelected: false
            },
            user: 0
          };
        }
        this.editMode = true;
      });
    },
    correctFloatingValues() {
      if (this.modelPricing.modelDealerPrice.value === '' || this.modelPricing.modelDealerPrice.value === null) {
        this.modelPricing.modelDealerPrice.value = null;
      } else {
        this.modelPricing.modelDealerPrice.value = parseFloat(this.modelPricing.modelDealerPrice.value).toFixed(2);
      }
      if (this.modelPricing.modelWebPrice.value === '' || this.modelPricing.modelWebPrice.value === null) {
        this.modelPricing.modelWebPrice.value = null;
      } else {
        this.modelPricing.modelWebPrice.value = parseFloat(this.modelPricing.modelWebPrice.value).toFixed(2);
      }
      if (this.modelPricing.modelCostPrice === '' || this.modelPricing.modelCostPrice === null) {
        this.modelPricing.modelCostPrice = null;
      } else {
        this.modelPricing.modelCostPrice = parseFloat(this.modelPricing.modelCostPrice).toFixed(2);
      }
      this.modelPricing.standardMonthlyPrice = parseFloat(this.modelPricing.standardMonthlyPrice).toFixed(2);
      this.modelPricing.modelListPrice.value = parseFloat(this.modelPricing.modelListPrice.value).toFixed(2);
    },
    /**
     * Stop User to insert -.+ amd etc signs
     */
    // eslint-disable-next-line consistent-return
    isNumber(evt) {
      // eslint-disable-next-line no-param-reassign
      evt = evt || window.event;
      // eslint-disable-next-line no-unused-vars
      const charCode = evt.which ? evt.which : evt.keyCode;
      if ((evt.which !== 8 && evt.which !== 46 && evt.which !== 0 && evt.which < 48) || evt.which > 57) {
        evt.preventDefault();
      } else {
        return true;
      }
    }
  },
  created() {
    this.modelId = this.$store.getters.getModelId;
    this.callAPIToGetModelPricing();
  }
};
</script>
<style scoped>
.disabled {
  pointer-events: none;
  opacity: 0.9;
  background-color: #e9ecef;
}
.invalid-input {
  border: 1px solid #db0303;
  background-color: #fdede4;
}
.invalid-text {
  color: #db0303;
  font-size: 14px;
}
.checkbox-combine,
.input-combine {
  display: inline-block;
}
.checkbox-combine {
  width: 9%;
}
.input-combine {
  width: 89%;
}
.general-text {
  font-size: 14px;
  color: #777777;
}
</style>