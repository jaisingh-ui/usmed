<template>
  <!-- right pannel section -->
  <div id="content">
    <div class="container-fluid">
      <ModuleHeader :headerData="result"></ModuleHeader>
      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <div id="accordion" v-if="componentToRender.length > 0">
              <template v-for="(subModule, index) in componentToRender">
                <component
                  :is="subModule"
                  :key="index"
                  :ref="'model'+index"
                  :itemIndex="index"
                  @togglePanel="panelToggle"
                  @panelClicked="onClicked"
                ></component>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import ModuleHeader from '../../components/ModuleHeader';
import ComparableModel from './model-associate/ComparableModel';
import AssociatedModel from './model-associate/AssociatedModel';
import UsableParts from './model-associate/UsableParts';
import StandardParts from './model-associate/StandardParts';
import Accessories from './model-associate/Accessories';
import modelService from './services/model-service';
import { ModelUrls } from '../../shared/constants/urls';
import VALIDATION_MESSAGES from '../../shared/constants/messages';

export default {
  components: {
    ModuleHeader,
    ComparableModel,
    AssociatedModel,
    UsableParts,
    Accessories,
    StandardParts
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      componentToRender: [],
      showPanels: true,
      refId: null,
      modelcategory: '',
      headerData: {
        head: 'Associated Models / Parts',
        id: 0,
        name: '',
        status: ''
      }
    };
  },
  methods: {
    panelToggle(editMode, itemIndex) {
      this.refId = `model${itemIndex}`;
      if (editMode) {
        this.showPanels = true;
      } else {
        this.showPanels = false;
      }
    },
    onClicked(event) {
      if (!this.showPanels) {
        // eslint-disable-next-line no-alert
        const answer = window.confirm(this.validationsMessages.WARNINGPARTIALFILLEDPANEL);
        if (!answer) {
          event.preventDefault();
          event.stopPropagation();
          // eslint-disable-next-line no-param-reassign
          event.returnValue = '';
        } else {
          this.$refs[this.refId][0].onChildCancelClicked();
          this.showPanels = true;
        }
      }
    }
  },
  computed: {
    result() {
      return this.headerData;
    }
  },
  created() {
    // eslint-disable-next-line arrow-parens
    modelService.getModelRequest(`${ModelUrls.modelGeneralData}?modelId=${this.$store.getters.getModelId}`).then(res => {
      if (res.data.apiResponseStatus !== 'Failed') {
        const result = res.data.data;
        this.modelcategory = result.modelCategoryName;
        this.headerData.id = result.modelId;
        this.headerData.name = result.modelName;
        this.headerData.status = result.isActive ? 'Active' : 'Inactive';
        switch (this.modelcategory.toLowerCase()) {
          case 'parts':
            this.componentToRender.push(AssociatedModel, ComparableModel); // AssociatedModel,
            break;
          case 'disposable':
            this.componentToRender.push(AssociatedModel, ComparableModel); // AssociatedModel,
            break;
          case 'service':
            this.componentToRender.push(AssociatedModel); // AssociatedModel,
            break;
          case 'accessories':
            this.componentToRender.push(AssociatedModel, ComparableModel, StandardParts, UsableParts); // AssociatedModel,
            break;
          case 'equipment':
            this.componentToRender.push(ComparableModel, StandardParts, UsableParts, Accessories);
            break;
          default:
            break;
        }
      } else {
        this.modelcategory = '';
      }
    });
  }
};
</script>