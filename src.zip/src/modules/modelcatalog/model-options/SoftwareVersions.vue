<template>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseThree"
          aria-expanded="false"
          aria-controls="collapseThree"
          @click="clickPanel"
        >Software Versions</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseThree"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseThree"
      class="collapse"
      aria-labelledby="headingThree"
      data-parent="#accordion"
    >
      <div class="card-body">
        <div class="row" style="border-bottom: 1px solid #efefef;">
          <div class="col-md-12 text-right mb-1 mt-1">
            <button
              v-if="editMode"
              type="button"
              class="edit-btn"
              @click.prevent="onEditClicked"
            >Edit</button>
            <span v-if="!editMode">
              <button
                type="button"
                :class="enableSaveBtn()?  'savebtn mr-1' : 'savebtn mr-1 custom-disabled'"
                class="save-btn mr-1"
                @click.prevent="onSaveClicked"
              >Save</button>

              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </span>
          </div>
        </div>
        <small
          class="error-message"
          v-if="isPrimarySelected"
        >{{validationsMessages.SOFTVERSIONNOPRIMARY}}</small>

        <!-- <small class="error-message" v-if="noDatatoSave">No Data To Save</small> -->
        <div class="row" v-for="(swtVersion, index) in softwareVersions.versions" :key="index">
          <div class="col-md-9">
            <div class="form-group">
              <label v-if="index===0">
                Version
                <i class="fa fa-info-circle" aria-hidden="true" title="Software Versions"></i>
              </label>
              <input
                :disabled="editMode? true: !swtVersion.isActive"
                type="text"
                maxlength="100"
                :class="toggleVersions(swtVersion)"
                v-model.trim="swtVersion.softwareVersion"
                @input="onVersionKeyPress()"
              />
              <small
                v-if="duplicateIndex.includes(swtVersion.softwareVersion.toLowerCase().trim())"
                class="error-message"
              >{{validationsMessages.DUPLICATE_VALUES}}</small>
              <small
                v-if="checkEmptyVersion(swtVersion, index)"
                class="error-message"
              >{{validationsMessages.REQUIRED}}</small>
              <small
                v-if="duplicateIndex.includes(index)"
                class="error-message"
              >{{validationsMessages.DUPLICATE_VALUES}}</small>
              <small
                v-if="regexValidation.includes(swtVersion.softwareVersion.toLowerCase().trim())"
                class="error-message"
              >{{validationsMessages.INVALIDMODELSWTVERSION}}</small>
            </div>
          </div>

          <div class="col-md-2 text-center">
            <div class="form-group">
              <label v-if="index===0">
                Default
                <i
                  class="fa fa-info-circle"
                  aria-hidden="true"
                  title="Is Default/Primary Software Version"
                ></i>
              </label>
              <div class="checkBoxinFrom">
                <div
                  :class=" swtVersion.isActive  ? 'custom-control custom-checkbox': 'custom-control custom-checkbox custom-disabled-check'"
                >
                  <input
                    :disabled="editMode"
                    type="checkbox"
                    :class="swtVersion.softwareVersion!=='' ? 'custom-control-input': 'custom-control-input custom-disabled-check'"
                    :id="'customCheck' + index"
                    :checked="swtVersion.isPrimary"
                    name="swtCheck"
                    @click="checkBoxClicked(index)"
                  />
                  <label class="custom-control-label" :for="'customCheck' + index">&nbsp;</label>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-1 text-left">
            <div :class="{'form-group first-div': index===0, 'form-group': index!==0}">
              <div v-if="index === softwareVersions.versions.length-1">
                <a :disabled="editMode" href="#" @click.prevent="editMode? '#':addElements(index)">
                  <i :class="addElementClass(swtVersion)" aria-hidden="true"></i>
                </a>
              </div>
              <div v-else>
                <a
                  :disabled="editMode"
                  href="#"
                  @click.prevent="editMode? '#':deleteElements(index)"
                >
                  <i
                    aria-hidden="true"
                    :class="{'AddDelBtn':!editMode, 'fas fa-trash AddDelBtn':true, 'far fa-trash-alt AddDelBtn custom-delete-btn': !swtVersion.isActive}"
                  ></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import modelService from '../services/model-service';
import { ModelUrls } from '../../../shared/constants/urls';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import { showToast } from '../../../shared/services/toast-service';

export default {
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      isPrimarySelected: false,
      opertaionMode: 'none',
      softwareVersions: {
        modelId: null,
        versions: [
          {
            softwareVersion: '',
            isPrimary: false,
            modelSoftwareId: 0,
            isActive: true
          }
        ]
      },
      oldModelSwtVersion: {},
      modelId: null,
      editMode: true, // this should be false in case of Add mode
      isError: false,
      duplicateIndex: [],
      emptyIndex: [],
      validSwtVersion: null,
      regexValidation: [],
      noDatatoSave: false
    };
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    checkEmptyVersion(swtVersion, index) {
      if (swtVersion.softwareVersion.toLowerCase().trim() === '' && index !== this.softwareVersions.versions.length - 1) {
        this.isError = true;
        return true;
      }
      return false;
    },
    checkBoxClicked(index) {
      this.isPrimarySelected = false;
      if (this.softwareVersions.versions[index].softwareVersion === '' && index === this.softwareVersions.versions.length - 1) {
        event.preventDefault();
      } else {
        // eslint-disable-next-line no-plusplus
        for (let i = 0; i < this.softwareVersions.versions.length; i++) {
          //
          this.isPrimarySelected = false;
          if (i === index) {
            this.softwareVersions.versions[i].isPrimary = !this.softwareVersions.versions[i].isPrimary;
            this.isPrimarySelected = false;
          } else if (this.softwareVersions.versions[i].isActive) {
            this.softwareVersions.versions[i].isPrimary = false;
          }
        }
      }
    },
    addElements(index) {
      // Add elements only in case if first element is added
      if (this.softwareVersions.versions[index].softwareVersion !== '' && !this.isError && this.validSwtVersion === null) {
        this.softwareVersions.versions.push({
          softwareVersion: '',
          isPrimary: false,
          modelSoftwareId: 0,
          isActive: true
        });
      }
    },
    async deleteElements(index) {
      if (this.softwareVersions.versions[index] !== undefined) {
        if (this.softwareVersions.versions[index].modelSoftwareId !== 0) {
          this.softwareVersions.versions[index].isActive = !this.softwareVersions.versions[index].isActive;
          this.softwareVersions.versions[index].isPrimary = false;
        } else {
          this.softwareVersions.versions.splice(index, 1);
          if (this.softwareVersions.versions.length === 0) {
            this.softwareVersions.versions.push({
              softwareVersion: '',
              isPrimary: false,
              modelSoftwareId: 0,
              isActive: true
            });
          }
        }
      }
    },
    // Save button will only be available to click once there is no error in form
    // and first input element is non empty
    enableSaveBtn() {
      if (this.isError) {
        return false;
      } else if (this.softwareVersions.versions.length === 1 && this.softwareVersions.versions[0].softwareVersion === '') {
        return false;
      }
      return true;
    },
    async checkAnyPrimary() {
      // if only one version is in scope
      if (
        this.softwareVersions.versions.length === 1 &&
        this.softwareVersions.versions[0].softwareVersions !== '' &&
        !this.softwareVersions.versions[0].isActive
      ) {
        return true;
      }
      // // if all versions are marked deleted
      // const allDeleted = await this.softwareVersions.versions.filter(item => item.isActive === false);
      // if (allDeleted.length === this.softwareVersions.versions.length - 1) {
      //   return true;
      // }
      // if any of the version have the primary
      const result = await this.softwareVersions.versions.find(item => item.isPrimary === true);
      if (result) {
        return true;
      }
      return false;
    },
    onSaveClicked() {
      this.isPrimarySelected = false;
      // If the user tries to save the record without proving any information in Version
      if (this.softwareVersions.versions.length === 1 && this.softwareVersions.versions[0].softwareVersion !== '' && !this.isError) {
        this.checkDeletedData();
      } else if (
        this.softwareVersions.versions.length !== 1 &&
        this.softwareVersions.versions[this.softwareVersions.versions.length - 1].softwareVersion === '' &&
        !this.isError
      ) {
        // this.softwareVersions.versions.splice(this.softwareVersions.versions.length - 1, 1);
        this.checkDeletedData();
      } else if (!this.isError) {
        this.checkDeletedData();
      }
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    onEditClicked() {
      this.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.editMode = true;
        this.isPrimarySelected = false;
        this.isError = false;
        this.callAPIToGetSwtVersions();
        this.validSwtVersion = null;
        this.$emit('togglePanel', this.editMode, this.itemIndex);
      }
      return false;
    },
    onChildCancelClicked() {
      this.editMode = true;
      this.isPrimarySelected = false;
      this.isError = false;
      this.callAPIToGetSwtVersions();
      this.validSwtVersion = null;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    onVersionKeyPress() {
      this.isError = false;
      this.noDatatoSave = false;
      this.duplicateIndex = [];
      this.regexValidation = [];
      const valueArr = this.softwareVersions.versions.map(item => item.softwareVersion.toLowerCase().trim());
      const isDuplicate = valueArr.filter((item, idx) => valueArr.indexOf(item) !== idx && item !== '');
      this.duplicateIndex.push(...isDuplicate);
      if (this.duplicateIndex.length > 0) {
        this.isError = true;
      }
      const valueRegex = valueArr.filter((item, idx) => this.validateVersionFields(item, idx));
      this.regexValidation.push(...valueRegex);
      if (this.regexValidation.length > 0) {
        this.isError = true;
      }
    },
    handleBlurEvent(loc) {
      this.validateVersionFields(this.softwareVersions.versions[loc].softwareVersion, loc);
    },
    validateVersionFields(value, index) {
      this.validSwtVersion = null;
      if (value) {
        // eslint-disable-next-line no-useless-escape
        if (!/^[a-zA-Z0-9\.\s]{0,100}$/.test(value)) {
          this.validSwtVersion = index;
          return true;
        }
      }
      return false;
    },
    callAPIToGetSwtVersions() {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.getModelSoftwareVersions}?modelId=${this.modelId}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.softwareVersions = res.data.data;
          this.oldModelSwtVersion = JSON.parse(JSON.stringify(this.softwareVersions));
          if (this.softwareVersions && this.softwareVersions.versions) {
            this.softwareVersions.versions.push({
              softwareVersion: '',
              isPrimary: false,
              modelSoftwareId: 0,
              isActive: true
            });
          }
          this.editMode = true;
        }
      });
    },
    checkDeletedData() {
      const delData = this.softwareVersions.versions.filter(item => item.isActive === false);
      this.deletedRecord = delData.length;
      if (this.deletedRecord !== 0) {
        // eslint-disable-next-line no-alert
        const answer = window.confirm(`${this.deletedRecord} ${this.validationsMessages.INPUTDELETERECORD}`);
        if (answer) {
          this.checkEditedModelversions();
        }
      } else {
        this.checkEditedModelversions();
      }
    },
    async checkEditedModelversions() {
      if (await this.checkAnyPrimary()) {
        this.noDatatoSave = false;
        if (this.softwareVersions.versions.length !== 1 && this.softwareVersions.versions[this.softwareVersions.versions.length - 1].softwareVersion === '') {
          this.softwareVersions.versions.splice(this.softwareVersions.versions.length - 1, 1);
        }
        const editedArray = [];
        // add newly added data
        const newlyAddedData = await this.softwareVersions.versions.filter(item => item.modelSoftwareId === 0);
        if (newlyAddedData) {
          editedArray.push(...newlyAddedData);
        }
        // add deleted data
        const deletedData = await this.softwareVersions.versions.filter(item => item.isActive === false);
        if (deletedData) {
          editedArray.push(...deletedData);
        }
        // add text edited data
        const editedData = await this.softwareVersions.versions.filter((item, index) => this.checkEdits(item, index));
        if (editedData) {
          editedArray.push(...editedData);
        }
        // check isPrimary edited
        const editedPrimaryData = await this.softwareVersions.versions.filter((item, index) => this.checkPrimaryEdits(item, index));
        if (editedPrimaryData) {
          editedArray.push(...editedPrimaryData);
        }
        if (editedArray.length > 0 && editedArray[0].softwareVersion.trim() !== '') {
          this.softwareVersions.versions = editedArray;
          this.noDatatoSave = false;
          this.callAPIToSaveSwtVersions();
        } else {
          // this.isError = true;
          // this.softwareVersions.versions = [];
          this.noDatatoSave = true;
        }
      } else {
        this.isPrimarySelected = true;
      }
    },
    checkPrimaryEdits(item, index) {
      if (item.isActive && this.softwareVersions.versions[index].softwareVersion !== '' && item.modelSoftwareId !== 0) {
        if (this.oldModelSwtVersion.versions[index].isPrimary !== item.isPrimary) {
          return true;
        }
      }
      return false;
    },
    checkEdits(item, index) {
      if (item.isActive && item.softwareVersion !== '' && this.oldModelSwtVersion.versions.length > index) {
        if (this.oldModelSwtVersion.versions[index].softwareVersion !== item.softwareVersion) {
          return true;
        }
      }
      return false;
    },
    async callAPIToSaveSwtVersions() {
      if (this.validSwtVersion === null) {
        // this.softwareVersions.modelId = parseInt(this.softwareVersions.modelId, 10);
        // eslint-disable-next-line arrow-parens
        modelService.postModelRequest(ModelUrls.savetModelSoftwareVersions, this.softwareVersions).then(res => {
          if (res.data.apiResponseStatus !== 'Failed') {
            this.callAPIToGetSwtVersions();
            this.editMode = true;
            this.$emit('togglePanel', this.editMode, this.itemIndex);
            showToast('success');
          }
        });
      }
    },
    handleEditSaveMode() {
      if (this.$store.getters.getOperationMode === 'edit') {
        this.editMode = true;
      } else {
        this.editMode = false;
      }
      // if (this.softwareVersions && this.softwareVersions.versions) {
      //   this.softwareVersions.versions.push({
      //     softwareVersion: '',
      //     isPrimary: false,
      //     modelSoftwareId: 0,
      //     isActive: true
      //   });
      // }
    },
    // when modelSoftwareId !==0 disable permanently
    // when toggle is clicked set/reset the disablity
    toggleVersions(swtVersion) {
      let versionClass = 'form-control form-control-view';
      if (swtVersion.modelSoftwareId === 0 && this.editMode) {
        versionClass = 'form-control form-control-disable';
      } else if (swtVersion.isActive && !this.editMode) {
        versionClass = 'form-control form-control-view';
      } else if (swtVersion.modelSoftwareId === 0 && this.editMode) {
        versionClass = 'form-control form-control-view';
      }
      return versionClass;
    },
    addElementClass(swtVersion) {
      let delClass = 'icon-model-options AddDelBtn';
      if (swtVersion.softwareVersion.trim() === '' || this.isError) {
        delClass = 'icon-model-options AddDelBtn disable-btn';
      }
      return delClass;
      // editMode?:'icon-model-options AddDelBtn disable-btn':option.isActive? 'icon-model-options AddDelBtn':''
    }
  },
  async created() {
    this.modelId = await this.$store.getters.getModelId;
    await this.callAPIToGetSwtVersions();
  }
};
</script>
<style scoped>
.first-div {
  margin-top: 30px;
}
.custom-disabled-check {
  pointer-events: none;
  background-color: #e9ecef;
}
.disabled {
  pointer-events: none;
  opacity: 1;
  cursor: not-allowed;
  background-color: #e9ecef;
}
</style>