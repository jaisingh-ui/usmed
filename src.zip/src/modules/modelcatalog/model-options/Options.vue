<template>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button
          class="btn btn-link"
          data-toggle="collapse"
          data-target="#collapseTwo"
          aria-expanded="true"
          aria-controls="collapseTwo"
          @click="clickPanel"
        >Options</button>
      </h5>
      <div class="rightInfotext">
        <i
          class="fa fa-angle-down"
          data-toggle="collapse"
          data-target="#collapseTwo"
          @click="clickPanel"
        ></i>
      </div>
    </div>
    <div
      id="collapseTwo"
      class="collapse show"
      aria-labelledby="headingTwo"
      data-parent="#accordion"
    >
      <div class="card-body">
        <div class="row border-bottom">
          <div class="col-md-12 text-right mb-1 mt-1">
            <button
              v-if="editMode"
              type="button"
              class="edit-btn"
              @click.prevent="onEditClicked"
            >Edit</button>
            <span v-if="!editMode">
              <button
                type="button"
                :class="enableSaveBtn()?  'save-btn mr-1' : 'save-btn mr-1 custom-disabled'"
                @click.prevent="onSaveClicked"
              >Save</button>
              <button type="button" class="cancel-btn" @click.prevent="onCancelClicked">Cancel</button>
            </span>
          </div>
        </div>
        <div>
          <!-- <small class="error-message" v-if="noDatatoSave">No Data To Save</small> -->
          <div class="row" v-for="(option, index) in modelOptions.options" v-bind:key="index">
            <div :id="index" class="col-md-4">
              <div class="form-group">
                <label v-if="index === 0">
                  Option
                  <i class="fa fa-info-circle" aria-hidden="true" title="Options"></i>
                </label>
                <input
                  :disabled="editMode? true: !option.isActive"
                  type="text"
                  maxlength="200"
                  :class="toggleOptions(option)"
                  v-model.trim="option.modelOptionsName"
                  @input="onOptionKeyPress()"
                />
                <small
                  v-if="duplicateIndex.includes(option.modelOptionsName.toLowerCase().trim())"
                  class="error-message"
                >{{validationsMessages.DUPLICATE_VALUES}}</small>
                <small
                  v-if="checkEmptyVersion(option,index)"
                  class="error-message"
                >{{validationsMessages.REQUIRED}}</small>
                <small
                  v-if="regexValidation.includes(option.modelOptionsName.toLowerCase().trim())"
                  class="error-message"
                >{{validationsMessages.INVALIDMODELOPTION}}</small>
              </div>
            </div>
            <div class="col-md-7 text-left">
              <div class="form-group">
                <label v-if="index === 0">
                  Description
                  <i
                    class="fa fa-info-circle"
                    aria-hidden="true"
                    title="Option Description"
                  ></i>
                </label>
                <input
                  :disabled="editMode? true: !option.isActive"
                  type="text"
                  maxlength="500"
                  :class="toggleOptions(option)"
                  @input="onOptionKeyPress()"
                  v-model.trim="option.description"
                />
                <small
                  v-if="regexValidation.includes(option.description.toLowerCase().trim())"
                  class="error-message"
                >{{validationsMessages.INVALIDMODELOPTION}}</small>
              </div>
            </div>

            <div class="col-md-1 text-left">
              <div :class="{'form-group first-div': index===0, 'form-group': index!==0}">
                <div v-if="index === modelOptions.options.length-1">
                  <a
                    :disabled="editMode"
                    href="#"
                    @click.prevent="editMode? '#':addElements(index)"
                  >
                    <i :class="addElementClass(option)" aria-hidden="true"></i>
                  </a>
                </div>
                <div v-else>
                  <a
                    :disabled="editMode"
                    href="#"
                    @click.prevent="editMode? '#':deleteElements(index)"
                  >
                    <i
                      aria-hidden="true"
                      :class="{'AddDelBtn':!editMode, 'fas fa-trash AddDelBtn':true, 'fas fa-trash AddDelBtn custom-delete-btn': !option.isActive}"
                    ></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import modelService from '../services/model-service';
import { ModelUrls } from '../../../shared/constants/urls';
import { showWindowConfrim } from '../../../shared/services/window-confrim';
import VALIDATION_MESSAGES from '../../../shared/constants/messages';
import { showToast } from '../../../shared/services/toast-service';

export default {
  props: {
    itemIndex: {
      type: Number
    }
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      modelOptions: {
        modelId: null,
        options: [
          {
            modelOptionsName: '',
            description: '',
            isActive: true,
            modelOptionsId: 0
          }
        ]
      },
      oldModelOptions: {},
      modelId: null,
      opertaionMode: 'none',
      disableRow: [],
      persistData: [],
      editMode: true,
      isError: false,
      duplicateIndex: [],
      validOption: null,
      validDescription: null,
      regexValidation: [],
      noDatatoSave: false,
      deletedRecord: 0
    };
  },
  methods: {
    clickPanel(event) {
      this.$emit('panelClicked', event);
    },
    checkEmptyVersion(option, index) {
      if (option.modelOptionsName.toLowerCase().trim() === '' && index !== this.modelOptions.options.length - 1) {
        this.isError = true;
        return true;
      }
      return false;
    },
    addElementClass(option) {
      let delClass = 'icon-model-options AddDelBtn';
      if (option.modelOptionsName.trim() === '' || this.isError) {
        delClass = 'icon-model-options AddDelBtn disable-btn';
      }
      return delClass;
      // editMode?:'icon-model-options AddDelBtn disable-btn':option.isActive? 'icon-model-options AddDelBtn':''
    },
    // Will allow to add elements if the current input element is non-empty
    addElements(index) {
      // Add elements only in case if first element option property is not empty
      if (this.modelOptions.options[index].modelOptionsName !== '' && !this.isError && this.validOption === null && this.validDescription === null) {
        this.modelOptions.options.push({
          modelOptionsName: '',
          description: '',
          isActive: true,
          modelOptionsId: 0
        });
      }
    },
    onOptionKeyPress() {
      this.noDatatoSave = false;
      this.isError = false;
      this.duplicateIndex = [];
      this.regexValidation = [];
      const options = this.modelOptions.options.map(item => item.modelOptionsName.toLowerCase().trim());
      const optionDescription = this.modelOptions.options.map(item => item.description.toLowerCase().trim());
      // @blur="handleDescrBlurEvent(option.description, index)"
      const isDuplicate = options.filter((item, idx) => options.indexOf(item) !== idx && item !== '');
      this.duplicateIndex.push(...isDuplicate);
      if (this.duplicateIndex.length > 0) {
        this.isError = true;
      }
      this.regexValidation.push(...options.filter((item, idx) => this.validateOptionFields(item, idx)));
      this.regexValidation.push(...optionDescription.filter((item, idx) => this.validateOptionFields(item, idx)));
      if (this.regexValidation.length > 0) {
        this.isError = true;
      }
    },
    // this will check the duplicate entries
    handleOptionBlurEvent(loc, event) {
      this.isError = false;
      const result = this.modelOptions.options.find(
        (item, index) => item.modelOptionsName.toLowerCase().trim() === event.target.value.toLowerCase().trim() && loc !== index && event.target.value !== ''
      );
      if (result) {
        this.isError = true;
        this.duplicateIndex.push(loc);
      } else {
        const index = this.duplicateIndex.indexOf(loc);
        if (index > -1) {
          this.duplicateIndex.splice(index, 1);
        }
      }
      this.validateOptionFields(this.modelOptions.options[loc].modelOptionsName, loc);
    },
    handleDescrBlurEvent(optDescription, index) {
      this.validDescription = null;
      if (optDescription) {
        // eslint-disable-next-line no-useless-escape
        if (!/^[a-zA-Z0-9\-_,.#\s]{0,500}$/.test(optDescription)) {
          this.validDescription = index;
        }
      }
    },
    validateOptionFields(value, index) {
      this.validOption = null;
      if (value) {
        // !/^[a-zA-Z0-9\-_,.#\s]{0,200}$/.test(value)
        // eslint-disable-next-line no-useless-escape
        if (!/^[a-zA-Z0-9\-_,.#\s]{0,500}$/.test(value)) {
          this.validOption = index;
          return true;
        }
      }
      return false;
    },
    // Once Edit is clicked we need to enable the whole form and marked the isEdit mode false
    onEditClicked() {
      this.editMode = false;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    // It disables the elements on clicking delete button
    deleteElements(index) {
      if (this.modelOptions.options[index] !== undefined) {
        if (this.modelOptions.options[index].modelOptionsId !== 0) {
          this.modelOptions.options[index].isActive = !this.modelOptions.options[index].isActive;
        } else {
          this.modelOptions.options.splice(index, 1);
          if (this.modelOptions.options.length === 0) {
            this.modelOptions.options.push({
              modelOptionsName: '',
              description: '',
              isActive: true,
              modelOptionsId: 0
            });
          }
        }
      }
    },
    // Save button will only be available to click once there is no error in form
    // and first input element is non empty
    enableSaveBtn() {
      if (this.isError) {
        return false;
      } else if (this.modelOptions.options.length === 1 && this.modelOptions.options[0].modelOptionsName === '') {
        return false;
      }
      return true;
    },
    // Save functionality will go here
    onSaveClicked() {
      if (this.modelOptions.options.length !== 1 && this.modelOptions.options[this.modelOptions.options.length - 1].modelOptionsName === '' && !this.isError) {
        this.modelOptions.options.splice(this.modelOptions.options.length - 1, 1);
      }
      this.modelOptions.modelId = parseInt(this.modelOptions.modelId, 10);
      // call API to save data to DB
      if (this.validOption === null && !this.isError) {
        const delData = this.modelOptions.options.filter(item => item.isActive === false);
        this.deletedRecord = delData.length;
        if (this.deletedRecord !== 0) {
          // eslint-disable-next-line no-alert
          const answer = window.confirm(`${this.deletedRecord} ${this.validationsMessages.INPUTDELETERECORD}`);
          if (answer) {
            this.callAPItoSaveModelOption();
          } else {
            this.modelOptions.options.push({
              modelOptionsName: '',
              description: '',
              isActive: true,
              modelOptionsId: 0
            });
          }
        } else {
          this.callAPItoSaveModelOption();
        }
      }
    },
    checkEditedModelOption() {
      this.noDatatoSave = false;
      // this.oldModelOptions = JSON.parse(JSON.stringify(this.modelOptions));
      const editedArray = [];
      // add newly added data
      const newlyAddedData = this.modelOptions.options.filter(item => item.modelOptionsId === 0);
      if (newlyAddedData) {
        editedArray.push(...newlyAddedData);
      }
      // add deleted data
      const delData = this.modelOptions.options.filter(item => item.isActive === false);
      if (delData) {
        editedArray.push(...delData);
      }
      // this.deletedRecord = delData.length;
      // add edited data
      const editedData = this.modelOptions.options.filter((item, index) => this.checkEdits(item, index));
      if (editedData) {
        editedArray.push(...editedData);
      }
      if (editedArray.length > 0 && editedArray[0].modelOptionsName.trim() !== '') {
        this.modelOptions.options = editedArray;
        this.noDatatoSave = false;
        this.callAPItoSaveModelOption();
      } else {
        this.noDatatoSave = true;
      }
    },
    checkEdits(item, index) {
      if (item.isActive && this.oldModelOptions.options.length > index) {
        if (
          this.oldModelOptions.options[index].modelOptionsName !== item.modelOptionsName ||
          this.oldModelOptions.options[index].description !== item.description
        ) {
          return true;
        }
      }
      return false;
    },
    callAPItoSaveModelOption() {
      // eslint-disable-next-line arrow-parens
      modelService.postModelsDataAction(ModelUrls.saveModelOptions, this.modelOptions).then(res => {
        // this.modelOptions = res.data;
        if (res.data.apiResponseStatus !== 'Failed') {
          this.editMode = true;
          // again re-render the UI from the response fom the API
          this.callApiToGetModelOptions();
          this.$emit('togglePanel', this.editMode, this.itemIndex);
          showToast('success');
        }
      });
    },
    callApiToGetModelOptions() {
      // eslint-disable-next-line arrow-parens
      modelService.getModelRequest(`${ModelUrls.getModelOptions}?modelId=${this.modelId}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.modelOptions = res.data.data;
          this.editMode = true;
          this.oldModelOptions = JSON.parse(JSON.stringify(this.modelOptions));
          if (this.modelOptions && this.modelOptions.options) {
            //  && this.modelOptions.options.length === 0
            this.modelOptions.options.push({
              modelOptionsName: '',
              description: '',
              isActive: true,
              modelOptionsId: 0
            });
          }
        }
      });
    },
    // cancel will revert whole edited data to previous state
    async onCancelClicked() {
      const cancel = showWindowConfrim();
      if (cancel) {
        await this.callApiToGetModelOptions();
        this.validOption = null;
        this.validDescription = null;
        this.isError = false;
        this.duplicateIndex = [];
        this.editMode = true;
        this.$emit('togglePanel', this.editMode, this.itemIndex);
      }
      return false;
    },
    async onChildCancelClicked() {
      await this.callApiToGetModelOptions();
      this.validOption = null;
      this.validDescription = null;
      this.isError = false;
      this.duplicateIndex = [];
      this.editMode = true;
      this.$emit('togglePanel', this.editMode, this.itemIndex);
    },
    toggleOptions(option) {
      let optionClass = 'form-control form-control-view';
      if (option.modelOptionsId === 0 && this.editMode) {
        optionClass = 'form-control form-control-disable';
      } else if (option.isActive && !this.editMode) {
        optionClass = 'form-control form-control-view';
      } else if (option.modelOptionsId === 0 && this.editMode) {
        optionClass = 'form-control form-control form-control-view';
      }
      return optionClass;
    }
  },
  // Call API to fetch option data
  // if OperationMode is 'edit' it will disable the form
  async created() {
    this.modelId = await this.$store.getters.getModelId;
    await this.callApiToGetModelOptions();
    this.editMode = true;
  }
};
</script>

<style scoped >
.first-div {
  margin-top: 30px;
}
.error-message {
  color: #db0303 !important;
  font-size: 14px;
}
</style>