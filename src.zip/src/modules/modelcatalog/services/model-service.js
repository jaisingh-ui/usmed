/* eslint-disable indent */
import axiosMethods from '../../../shared/services/base-service';


const modelService = {
    // GET operations  postRequest
    getModelRequest(url, body) {
        return axiosMethods.getRequest(url, body).then(res => res);
    },
    postModelRequest(url, body) {
        return axiosMethods.postRequest(url, body).then(res => res);
    },
    putModelRequest(url, body) {
        return axiosMethods.putRequest(url, body).then(res => res);
    },
    deleteModelRequest(url, body) {
        return axiosMethods.deleteRequest(url, body).then(res => res);
    },
    getModelListResult(url, body) {
        return axiosMethods.getRequest(url, body).then(res => res);
    },
    getModelOptions(url, body) {
        return axiosMethods.getRequest(url, body).then(res => res);
    },
    saveModelOptions(url, body) {
        return axiosMethods.getRequest(url, body).then(res => res);
    },
    getModelSoftwareVersions(url, body) {
        return axiosMethods.getRequest(url, body).then(res => res);
    },
    saveModelSoftwareVersions(url, body) {
        return axiosMethods.getRequest(url, body).then(res => res);
    },
    getModelPricing(url, body) {
        return axiosMethods.getRequest(url, body).then(res => res);
    },
    postModelsDataAction(url, body) {
        return axiosMethods.postRequestAction(url, body).then(res => res);
    }
};


export default modelService;
