/* eslint-disable indent */
export const modelType = [
    {
        entityID: 1,
        entityName: 'Infusion',
        displayOrder: 1,
        isActive: true
    },
    {
        entityID: 2,
        entityName: 'Respiratory',
        displayOrder: 2,
        isActive: true
    },
    {
        entityID: 3,
        entityName: 'Monitoring',
        displayOrder: 3,
        isActive: true
    },
    {
        entityID: 4,
        entityName: 'Central Supply',
        displayOrder: 4,
        isActive: true
    },
    {
        entityID: 5,
        entityName: 'Office Equipment',
        displayOrder: 5,
        isActive: true
    },
    {
        entityID: 6,
        entityName: 'Accessories',
        displayOrder: 6,
        isActive: true
    },
    {
        entityID: 8,
        entityName: 'Biomedical Parts',
        displayOrder: 8,
        isActive: true
    }
];

export const modelSubType = [
    {
        entityID: 1,
        entityName: 'DVT',
        displayOrder: 1,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Infusion Pump/Dual Channel',
        displayOrder: 2,
        isActive: true,
        ModelTypeParentId: 1

    },
    {
        entityID: 1,
        entityName: 'Infusion Pump/Triple Channel',
        displayOrder: 3,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Infusion Pump/Quad Channel',
        displayOrder: 4,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Infusion Pump Ambulatory',
        displayOrder: 5,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Infusion Pump Ambulatory/PCA',
        displayOrder: 6,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Infusion Pump Syringe',
        displayOrder: 7,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Infusion Pump Syringe/PCA',
        displayOrder: 8,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Infusion Pump/PCA',
        displayOrder: 9,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Enteral Pump',
        displayOrder: 10,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Infusion Pump/Single Channel',
        displayOrder: 11,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Disposables',
        displayOrder: 12,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'PCA Module',
        displayOrder: 13,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Pump Module',
        displayOrder: 14,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Syringe Module',
        displayOrder: 15,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Alaris PC Unit',
        displayOrder: 16,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Lockbox',
        displayOrder: 17,
        isActive: true,
        ModelTypeParentId: 1
    },
    {
        entityID: 1,
        entityName: 'Infusion Pump Ambulatory/Multi-Therapy',
        displayOrder: 18,
        isActive: true,
        ModelTypeParentId: 1
    }
];

export const ModelClass = [
    {
        entityID: 1,
        entityName: 'Life support',
        displayOrder: 1,
        isActive: true
    },
    {
        entityID: 2,
        entityName: 'Non-life support',
        displayOrder: 2,
        isActive: true,
        ModelTypeParentId: 1

    },
    {
        entityID: 3,
        entityName: 'Non-Medical',
        displayOrder: 3,
        isActive: true,
        ModelTypeParentId: 1
    }
];

export const ModelCategory = [
    {
        entityID: 1,
        entityName: '--None --',
        displayOrder: 1,
        isActive: true
    },
    {
        entityID: 2,
        entityName: 'Accessories',
        displayOrder: 2,
        isActive: true
    },
    {
        entityID: 3,
        entityName: 'Assets',
        displayOrder: 3,
        isActive: true
    },
    {
        entityID: 4,
        entityName: 'Disposable',
        displayOrder: 4,
        isActive: true
    }
];

export const Manufacturer = [
    {
        entityID: 1,
        entityName: 'LG',
        displayOrder: 1,
        isActive: true
    },
    {
        entityID: 2,
        entityName: 'SamSung',
        displayOrder: 2,
        isActive: true
    }
];

export const UnitOfMeasure = [
    {
        entityID: 1,
        entityName: 'Box(s)',
        displayOrder: 1,
        isActive: true
    },
    {
        entityID: 2,
        entityName: 'Crate(s)',
        displayOrder: 2,
        isActive: true
    },
    {
        entityID: 3,
        entityName: 'Each',
        displayOrder: 3,
        isActive: true
    },
    {
        entityID: 4,
        entityName: 'Pallet(s)',
        displayOrder: 4,
        isActive: true
    }
];

export const ModelGroup = [
    {
        entityID: 1,
        entityName: 'Bilicheck',
        displayOrder: 1,
        isActive: true
    },
    {
        entityID: 2,
        entityName: 'Bilisoft',
        displayOrder: 2,
        isActive: true
    },
    {
        entityID: 3,
        entityName: 'BiliBlanket',
        displayOrder: 3,
        isActive: true
    }
];

export const StandardWarranty = [
    {
        entityID: 1,
        entityName: '6 months',
        displayOrder: 1,
        isActive: true
    },
    {
        entityID: 2,
        entityName: '1 year',
        displayOrder: 2,
        isActive: true
    },
    {
        entityID: 3,
        entityName: '2 years',
        displayOrder: 3,
        isActive: true
    },
    {
        entityID: 1,
        entityName: '3 years',
        displayOrder: 1,
        isActive: true
    },
    {
        entityID: 2,
        entityName: 'Parts Only',
        displayOrder: 2,
        isActive: true
    },
    {
        entityID: 1,
        entityName: 'Parts and Labor',
        displayOrder: 1,
        isActive: true
    }
];

