<template>
  <!-- right pannel section -->
  <div id="content">
    <div class="container-fluid">
      <div class="container-fluid">
        <Search
          :placeholder="placeholder"
          :headTitle="headTitle"
          :mySearchInput="mySearchInput"
          :showAllInput="showAllInput"
          :addButtonText="addButtonText"
          @searchInputValueChanged="mySearchInput = $event"
          @onSearchClicked="onTopSearch($event)"
          @onAddClicked="onAddNewModelClicked()"
        ></Search>
      </div>
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6">
            <h1 class="pageName">Model List</h1>
          </div>
          <div class="col-md-6">
            <div class="form-group pull-right" style="padding:0; margin:0; margin-left:10px;">
              <div class="checkBoxinFrom">
                <div class="custom-control custom-checkbox">
                  <input
                    type="checkbox"
                    class="custom-control-input"
                    id="customCheck11"
                    v-model="showAllInput"
                    @click="showAll($event)"
                  />
                  &nbsp;
                  <label
                    class="custom-control-label"
                    for="customCheck11"
                  >Show All</label>
                </div>
              </div>
            </div>

            <div class="FormworkingBtn pull-right">
              <a href="javascript:void(0)" @click="importPricing()">
                <i class="icon-current-rentals" aria-hidden="true"></i> Import Pricing
              </a>
            </div>
          </div>
        </div>
        <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
          <span class="k-loading-text">Loading...</span>
          <div class="k-loading-image">
            <div class="k-loading-color"></div>
          </div>
        </div>
        <DataTable
          :myColumns="myColumns"
          :multiSelectData="multiSelectData"
          :myToolbar="myToolbar"
          :myData="myData"
          @viewDetailCliked="viewDetail"
        ></DataTable>
      </div>
    </div>
  </div>
</template>
<script>
import Search from '../../components/Search';
import DataTable from '../../components/DataTable';
import modelService from './services/model-service';
import { ModelUrls } from '../../shared/constants/urls';

export default {
  data() {
    return {
      headTitle: 'Search Model',
      placeholder: 'Type Model Name/ Model Category/ Reference Number/ Meta Tags',
      myToolbar: ['excel', 'pdf'],
      dataItemsSource: [],
      addButtonText: 'Add New Model',
      myData: [],
      showLoader: false,
      // here checkbox is behaving oppositely
      showAllInput: false,
      mySearchInput: '',
      // myColumns getting used as column for grid
      myColumns: [
        { field: 'modelId', hidden: true },
        { field: 'modelCommonName', title: 'Model Common Name' },
        { field: 'modelName', title: 'Model Name' },
        { field: 'modelCategoryName', title: 'Category' },
        { field: 'modelTypeName', title: 'Type' },
        { field: 'manufacturer', title: 'Manufacturer' },
        { field: 'isActiveDisplay', title: 'Status' },
        { field: 'inventory', title: 'Inventory' }
        // { field: 'ProductName', title: 'Product Name', template: '<a href="/detail/">#:ProductName#</a>' },
        // { field: 'UnitPrice', title: 'Unit Price', filter: 'numeric' }
        // { title: 'Action', command: { text: 'View Details', click: this.showDetails } }
      ],
      // multiSelectData is used in multiselect Array
      multiSelectData: [
        { field: 'ProductID', title: 'ProductID' },
        { field: 'ProductName', title: 'Product Name', cell: 'myTemplate' },
        { field: 'UnitPrice', title: 'Unit Price', filter: 'numeric' }
      ]
    };
  },
  methods: {
    importPricing() {
      this.$router.push('/model-catalog/import-model-pricing');
      console.log('/import-model-pricing');
    },
    /**
     * on click at the add new model button onAddNewModelClicked get called
     * and navigate user to add new model
     */
    onAddNewModelClicked() {
      this.$store.dispatch('setOperationMode', 'save');
      const header = {
        head: 'Model Details',
        id: '',
        name: '',
        status: ''
      };
      localStorage.removeItem('header');
      localStorage.setItem('header', JSON.stringify(header));
      this.$router.push('/model-catalog/model-details');
    },
    /**
     * on click at the particular  model row viewDetail get called
     * and navigate user to view new model detail
     */
    viewDetail(id) {
      this.$store.dispatch('setModelId', id);
      // this.$store.dispatch('setModelName', event.name[0]);
      // this.$store.dispatch('setModelStatus', event.status[0]);
      this.$store.dispatch('setOperationMode', 'edit');
      this.$router.push(`/model-catalog/model-details/${id}`);
    },
    /**
     * on searching model from top search input onTopSearch method get call
     * and return the relevent data in to the grid
     */
    // eslint-disable-next-line consistent-return
    onTopSearch(event) {
      this.showLoader = true;
      const searchValue = event.trim();
      if (searchValue) {
        // this.showAllInput = true;
        // eslint-disable-next-line arrow-parens
        modelService.getModelRequest(`${ModelUrls.modelListSearch}?searchedItem=${searchValue}`).then(res => {
          const result = res.data.data;
          if (result) {
            this.myData = result;
            this.showLoader = false;
          }
        });
      } else if ((searchValue && this.showAllInput) || (!searchValue && this.showAllInput)) {
        // eslint-disable-next-line arrow-parens
        modelService.getModelRequest(`${ModelUrls.modelListShowAll}?searchedItem=${this.mySearchInput}`).then(res => {
          const result = res.data.data;
          if (result) {
            this.myData = result;
            this.showLoader = false;
          }
        });
      } else {
        if (this.showAllInput) {
          return false;
        }
        this.myData = this.dataItemsSource;
        this.showLoader = false;
      }
    },
    /**
     * on showAll checked get all model data
     * on showAll unchecked show no data for model
     */
    showAll(e) {
      this.showLoader = true;
      if (e.target.checked && this.mySearchInput) {
        // this.mySearchInput = '';
        // eslint-disable-next-line arrow-parens
        modelService.getModelRequest(`${ModelUrls.modelListShowAll}?searchedItem=${this.mySearchInput}`).then(res => {
          const result = res.data.data;
          if (result) {
            this.myData = result;
            this.showLoader = false;
          }
        });
      } else if (e.target.checked && !this.mySearchInput) {
        // eslint-disable-next-line arrow-parens
        modelService.getModelRequest(`${ModelUrls.modelListShowAll}`).then(res => {
          const result = res.data.data;
          if (result) {
            this.myData = result;
            this.showLoader = false;
          }
        });
      } else if (!e.target.checked && this.mySearchInput) {
        // eslint-disable-next-line arrow-parens
        modelService.getModelRequest(`${ModelUrls.modelListSearch}?searchedItem=${this.mySearchInput}`).then(res => {
          const result = res.data.data;
          if (result) {
            this.myData = result;
            this.showLoader = false;
          }
        });
      } else {
        this.myData = this.dataItemsSource;
        this.showLoader = false;
      }
    }
  },
  components: {
    Search,
    DataTable
  }
};
</script>
