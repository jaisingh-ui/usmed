<template>
  <!-- right pannel section -->
  <div id="content">
    <div class="container-fluid">
      <ModuleHeader :headerData="result"></ModuleHeader>
      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <div id="accordion" v-if="componentToRender.subMenuModules.length > 0">
              <template v-for="(subModule, index) in componentToRender.subMenuModules">
                <component
                  v-if="subModule.subMenuModuleVisible"
                  v-show="showNextPanels(index)"
                  :is="subModule.subMenuModuleName"
                  :subModuleInfo="subModule"
                  :key="subModule.subMenuModuleId"
                  :ref="'model'+index"
                  :itemIndex="index"
                  @togglePanel="panelToggle"
                  @panelClicked="onClicked"
                  @onModelAdded="modelAdded"
                  @setModelDetailHeaders="setModelDetailHeader"
                ></component>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ModuleHeader from '../../components/ModuleHeader';
import GeneralDetail from './model-details/GeneralDetail';
import Accounting from './model-details/Accounting';
import AdditionalInformation from './model-details/AdditionalInformation';
import ModelImage from './model-details/ModelImage';
import MobileSettings from './model-details/MobileSettings';
import VALIDATION_MESSAGES from '../../shared/constants/messages';

export default {
  components: {
    GeneralDetail,
    Accounting,
    AdditionalInformation,
    ModelImage,
    MobileSettings,
    ModuleHeader
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      componentToRender: {},
      showPanels: false,
      showNewPanels: true,
      refId: null,
      headerData: {
        head: 'Model Details',
        id: 0,
        name: '',
        status: ''
      }
    };
  },
  computed: {
    result() {
      return this.headerData;
    }
  },
  methods: {
    modelAdded() {
      if (!isNaN(this.$store.getters.getModelId)) {
        this.showPanels = true;
      } else {
        this.showPanels = false;
      }
    },
    showNextPanels(index) {
      if (index === 0) {
        return true;
      } else if (this.showPanels) {
        return true;
      }
      return false;
    },
    setModelDetailHeader(modelHeader) {
      this.headerData.id = modelHeader.id;
      this.headerData.name = modelHeader.name;
      this.headerData.status = modelHeader.status;
    },
    panelToggle(editMode, itemIndex) {
      this.refId = `model${itemIndex}`;
      if (editMode) {
        this.showNewPanels = true;
      } else {
        this.showNewPanels = false;
      }
    },
    onClicked(event) {
      if (!this.showNewPanels) {
        // eslint-disable-next-line no-alert
        const answer = window.confirm(this.validationsMessages.WARNINGPARTIALFILLEDPANEL);
        if (!answer) {
          event.preventDefault();
          event.stopPropagation();
          // eslint-disable-next-line no-param-reassign
          event.returnValue = '';
        } else {
          this.$refs[this.refId][0].onChildCancelClicked();
          this.showNewPanels = true;
        }
      }
    }
  },
  created() {
    this.componentToRender = this.$store.getters.getSubMenuModulesFromLeftMenuConfigs(2, 2);
    if (!isNaN(this.$store.getters.getModelId)) {
      this.showPanels = true;
    }
  }
};
</script>
<style>
.error {
  border: 1px solid red;
}
.error-message {
  color: red;
  font-size: 14px;
}
.disabledbutton {
  pointer-events: none;
  opacity: 0.4;
}
</style>
