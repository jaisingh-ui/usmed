import Contacts from '../contacts/Contacts';

export default [
  {
    path: '/contacts',
    name: 'Contact',
    component: Contacts,
    meta: {
      requiresAuth: true
    }
  }
];
