<template>
  <div id="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <h1 class="pageName">
            <i class="far fa-star mr-1 text-muted"></i> Search Contacts
          </h1>
        </div>
      </div>

      <div class="row mb-3">
        <div class="col-lg-10 col-md-10">
          <div class="input-group">
            <input
              type="text"
              class="form-control"
              placeholder="Type Contact Name/Partner Name/Partner Number"
              v-model.trim="searchInput"
            />
            <div
              class="input-group-append"
              v-if="searchInput"
              @click="searchInput=''; showText= false"
            >
              <span class="input-group-text" id="basic-addon2">
                <i class="fa fa-times" aria-hidden="true"></i>
              </span>
            </div>
          </div>
          <div
            class="error-message pl-2 mt-1"
            v-if="errorMessage && showText"
          >Please enter a value to search.</div>
          <!-- <div class="form-group">
            <input
              type="text"
              class="form-control"
              placeholder="Type Contact Name/Partner Name/Partner Number"
              v-model="searchedItem"
            />
          </div>-->
        </div>
        <div class="col-lg-2 col-md-2">
          <button
            type="button"
            class="btn btn-blue btn-block"
            @click="showText = true;onSearchMethod(1)"
          >Search</button>
          <!-- <button type="button" class="btn btn-blue btn-block">Search</button> -->
        </div>
      </div>

      <div class="row">
        <div class="col-md-12">
          <div class="form-group pull-right overflow-hidden">
            <div class="checkBoxinFrom">
              <div class="custom-control custom-checkbox">
                <input
                  type="checkbox"
                  class="custom-control-input"
                  id="customCheck11"
                  checked="checked"
                  v-model="showAllInput"
                  @change="getContactList()"
                />
                &nbsp;
                <label
                  class="custom-control-label"
                  for="customCheck11"
                >Show All</label>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
        <span class="k-loading-text">Loading...</span>
        <div class="k-loading-image">
          <div class="k-loading-color"></div>
        </div>
      </div>-->
      <ConfiguredColumnGrid
        @onRowClick="viewDetail"
        :gridColumns="myColumns"
        :gridObjects="myData"
        :sorting="sort"
      ></ConfiguredColumnGrid>
    </div>
  </div>
</template>
<script>
import ConfiguredColumnGrid from '../../components/ConfiguredColumnGrid';
import contactService from './services/contact-service';
import { ContactsUrls } from '../../shared/constants/urls';

export default {
  components: {
    ConfiguredColumnGrid
  },
  data() {
    return {
      // showLoader: false,
      showAllInput: false,
      searchInput: '',
      showText: false,
      myData: [],
      myColumns: [
        { field: 'partnerContactId', hidden: true },
        { field: 'partnerId', title: 'Partner #' },
        { field: 'firstName', title: 'Contact First Name' },
        { field: 'lastName', title: 'Contact Last Name' },
        { field: 'partnerName', title: 'Partner Name' },
        { field: 'designation', title: 'Designation' },
        { field: 'email', title: 'Email Address' },
        { field: 'phone', title: 'Cell Phone' },
        { field: 'partnerDepartmentName', title: 'Department' },
        {
          field: 'isPortalUserDisplay',
          title: 'mySMARTS Access',
          filter: 'boolean',
          cell: this.cellIsPortalUserFunction
        },
        {
          field: 'isActiveDisplay',
          title: 'Status',
          filter: 'boolean',
          cell: this.cellIsActiveDisplayFunction
        }
      ],
      sort: [{ field: 'designation', dir: 'asc' }]
    };
  },
  computed: {
    errorMessage() {
      const inputLength = this.searchInput.length;
      if (inputLength === 1) {
        this.showText = false;
      }
      // console.log(this.searchInput, this.showText, this.showAllInput, inputLength);
      if (this.showAllInput) {
        return false;
      }
      if (!this.searchInput && this.showText) {
        return true;
      }

      return false;
    }
  },
  created() {},
  methods: {
    viewDetail(event) {
      const id = event.dataItem.partnerContactId;
      this.$router.push(`/partners/search-view-partner-contact-list/${id}`);
      // this.$store.dispatch('setPartnerContactId', id);
      // this.isGridMode = false;
    },
    /**
     * getPartnerContactDetail method will fetch data based on showAll Flag
     * @param parterId
     * @param showFlag
     */
    getContactList(sItem = '') {
      if (this.showAllInput || sItem) {
        // eslint-disable-next-line arrow-parens
        contactService.getContactsResult(`${ContactsUrls.GET_CONTACT_LIST}?showall=${this.showAllInput}&searchedItem=${sItem}`).then(res => {
          if (res) {
            if (res.data.data) {
              this.myData = res.data.data;
            }
            // console.log(this.myData, 'llll');
            // this.showLoader = false;
          }
        });
      } else {
        this.showText = false;
        this.myData = [];
      }
    },
    onSearchMethod(submitClicked) {
      if (submitClicked) {
        this.showText = true;
      }
      if (!this.searchInput) {
        this.searchError = true;
      } else {
        this.searchError = false;
        this.getContactList(this.searchInput);
      }
    }
  }
};
</script>