/* eslint-disable indent */
import axiosMethods from '../../../shared/services/base-service';


const contactService = {
    getContactsResult(url, body) {
        return axiosMethods.getRequest(url, body).then(res => res);
    },
    postPartnersData(url, body) {
        return axiosMethods.postRequest(url, body).then(res => res);
    },
    postPartnersDataAction(url, body) {
        return axiosMethods.postRequestAction(url, body).then(res => res);
    }
};


export default contactService;
