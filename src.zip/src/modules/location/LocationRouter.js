import Location from '../location/Location';

export default [
  {
    path: '/location',
    name: 'Location',
    component: Location
  }
];
