<template>
  <div id="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8">
          <h1 class="pageName">Locations</h1>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12">
          <div class="formTabSection">
            <div id="accordion" v-if="componentToRender.subMenuModules.length > 0">
              <template v-for="(subModule, index) in componentToRender.subMenuModules">
                <component
                  v-if="subModule.subMenuModuleVisible"
                  v-show="showNextPanels(index)"
                  :is="subModule.subMenuModuleName"
                  :subModuleInfo="subModule"
                  :key="subModule.subMenuModuleId"
                  :ref="'loc'+index"
                  :itemIndex="index"
                  @togglePanel="panelToggle"
                  @panelClicked="onClicked"
                ></component>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Region from './location-components/Region';
import Branch from './location-components/Branch';
import Territory from './location-components/Territory';
import VALIDATION_MESSAGES from '../../shared/constants/messages';

export default {
  components: {
    Region,
    Branch,
    Territory
  },
  data() {
    return {
      validationsMessages: VALIDATION_MESSAGES,
      componentToRender: {},
      showPanels: true,
      showNewPanels: true,
      refId: null
    };
  },
  computed: {
    result() {
      return this.headerData;
    }
  },
  methods: {
    showNextPanels(index) {
      if (index === 0) {
        return true;
      } else if (this.showPanels) {
        return true;
      }
      return false;
    },
    panelToggle(editMode, itemIndex) {
      this.refId = `loc${itemIndex}`;
      if (editMode) {
        this.showNewPanels = true;
      } else {
        this.showNewPanels = false;
      }
    },
    onClicked(event) {
      if (!this.showNewPanels) {
        // eslint-disable-next-line no-alert
        const answer = window.confirm(this.validationsMessages.WARNINGPARTIALFILLEDPANEL);
        if (!answer) {
          event.preventDefault();
          event.stopPropagation();
          // eslint-disable-next-line no-param-reassign
          event.returnValue = '';
        } else {
          this.$refs[this.refId][0].onChildCancelClicked();
          this.showNewPanels = true;
        }
      }
    }
  },
  created() {
    this.componentToRender = {
      subMenuId: 1,
      subMenuName: 'Location',
      subMenuUrl: '/location',
      subMenuIcon: 'icon-profile',
      subMenuVisible: true,
      subMenuModules: [
        {
          subMenuModuleId: 11,
          subMenuModuleName: 'Region',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        },
        {
          subMenuModuleId: 12,
          subMenuModuleName: 'Branch',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        },
        {
          subMenuModuleId: 13,
          subMenuModuleName: 'Territory',
          subMenuActionAllowed: 'Add/AddDelete/Delete/ViewOnly',
          subMenuModuleVisible: true
        }
      ]
    };
  }
};
</script>
