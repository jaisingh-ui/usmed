<template>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseTwo"
          aria-expanded="false"
          aria-controls="collapseTwo"
        >Branches</button>
      </h5>
      <div class="rightInfotext">
        <i class="fa fa-angle-down" data-toggle="collapse" data-target="#collapseTwo"></i>
      </div>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body">
        <BranchForm v-if="formShow" @showHideForm="showHideForm"></BranchForm>
        <div class="locationSection">
          <h3>
            <span></span>
            <button class="save-btn width-auto" @click="formShow=!formShow">Add New Branch</button>
          </h3>
          <div v-if="!formShow">
            <ConfiguredColumnGrid
              :gridObjects="branchList"
              :gridColumns="BranchColumns"
              :sorting="sort"
              @onRowClick="onRowClick"
            ></ConfiguredColumnGrid>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import BranchForm from './elements/BranchForm';
import axiosMethods from '../../../shared/services/base-service';
import { LocationUrls } from '../../../shared/constants/urls';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import ConfiguredColumnGrid from '../../../components/ConfiguredColumnGrid';

export default {
  name: 'Branch',
  props: {},
  components: {
    BranchForm,
    ConfiguredColumnGrid
  },
  data() {
    return {
      formShow: false,
      VALIDATION_MESSAGE,
      selectedID: 0,
      BranchColumns: [
        { field: 'branchID', editable: false, title: 'branchID', hidden: true, filterable: false },
        { field: 'branchName', editable: false, title: 'Branch Name' },
        { field: 'regionName', editable: false, title: 'Region' },
        { field: 'email', editable: false, title: 'Responsible Email' },
        { field: 'address1', editable: false, title: 'Address 1' },
        { field: 'address2', editable: false, title: 'Address 2' },
        { field: 'city', editable: false, title: 'City' },
        { field: 'stateName', editable: false, title: 'State', filter: 'numeric' },
        { field: 'zip', title: 'Zip' },
        { field: 'fax', title: 'Fax' },
        { field: 'phone', title: 'Phone' }
      ],
      branchList: [],
      sort: [{ field: 'branchName', dir: 'asc' }]
    };
  },
  validations: {},
  created() {
    this.getBranchList();
  },
  methods: {
    onRowClick(ev) {
      this.selectedID = ev.dataItem.branchID;
      this.formShow = !this.formShow;
      console.log('-----branchID---', this.selectedID);
      // this.$router.push(`/profile/${id}`);
    },

    showHideForm(status) {
      this.formShow = status !== 'undefined' ? status : !this.formShow;
    },
    getBranchList() {
      // eslint-disable-next-line arrow-parens
      axiosMethods.getRequest(`${LocationUrls.GET_BRANCH}`).then(res => {
        this.branchList = res.data.data.branches;
        console.log('locaiton branches', res.data.data, this.branchList);
      });
    },
    editElements(ev) {
      // console.log(ev, 'vvvvvvvvvvvvvvvvvvvvvvvvvv');
      const id = ev.dataItem.partnerID;
      const MID = ev.dataItem.modelId;
      console.log(id, MID, 'daaaaa');
    }
  }
};
</script>