<template>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button
          class="btn btn-link collapsed"
          data-toggle="collapse"
          data-target="#collapseThree"
          aria-expanded="false"
          aria-controls="collapseThree"
        >Sales Territory</button>
      </h5>
      <div class="rightInfotext">
        <i class="fa fa-angle-down" data-toggle="collapse" data-target="#collapseThree"></i>
      </div>
    </div>
    <div
      id="collapseThree"
      class="collapse"
      aria-labelledby="headingThree"
      data-parent="#accordion"
    >
      <div class="card-body">
        <!-- add territory div -->
        <SalesTerritoryForm v-if="formShow" @showHideForm="showHideForm"></SalesTerritoryForm>
        <div class="row" v-if="!formShow">
          <div class="col-lg-7 col-md-12">
            <div class="locationSection">
              <div class="row">
                <div class="col-md-12 mt-4">
                  <div class="table-responsive">
                    <table class="table softwareTable fix-head-table">
                      <thead>
                        <tr>
                          <th class="text-nowrap">Sales Territory</th>
                          <th class="text-nowrap">Sales Rep</th>
                          <th class="text-nowrap">Sales Manager</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr
                          :class="{'active':item.territoryId == selectedTerritory}"
                          @click="getSalesTerritoryDetails(item.territoryId)"
                          v-for="(item, index) in territoryList"
                        >
                          <td>{{item.territoryName}}</td>
                          <td>{{item.salesRep}}</td>
                          <td>{{item.regionName}}Not coming from Api</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-5 col-md-12">
            <div class="locationSection">
              <div class="row">
                <div class="col-md-12 mt-4 mb-2 text-right">
                  <button class="save-btn width-auto" @click="formShow=!formShow">
                    Add New Sales
                    Territory
                  </button>
                  <button v-if="editMode" class="save-btn" @click="handleSave">Save</button>
                  <button v-if="editMode" class="cancel-btn" @click="handleCancel">Cancel</button>
                  <button v-if="!editMode" class="edit-btn" @click="editMode=!editMode">Edit</button>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="custom-label">
                      Sales
                      Territory
                    </label>
                    <input type="text" class="form-control" id placeholder="Austin" disabled />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="custom-label">
                      Sales
                      Rep
                    </label>
                    <input type="text" class="form-control" id placeholder="Amber Parker" disabled />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="custom-label">
                      Sales
                      Manager
                    </label>
                    <input type="text" class="form-control" id placeholder="Amber Parker" disabled />
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-11">
                  <div class="form-group">
                    <label>Add New Zip</label>
                    <input type="text" class="form-control" id placeholder value />
                  </div>
                </div>
                <div class="col-md-1">
                  <div class="form-group mt-4 pt-2">
                    <a href="#">
                      <i class="icon-model-options AddDelBtn" aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
              </div>
              <AssociatedZipCodes :territoryId="selectedTerritory"></AssociatedZipCodes>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import SalesTerritoryForm from './elements/SalesTerritoryForm';
import axiosMethods from '../../../shared/services/base-service';
import { LocationUrls } from '../../../shared/constants/urls';
import VALIDATION_MESSAGE from '../../../shared/constants/messages';
import { showWindowConfrim } from '../../../shared/services/window-confrim';

export default {
  name: 'Territory',
  props: {},
  components: {
    SalesTerritoryForm
  },
  data() {
    return {
      formShow: false,
      VALIDATION_MESSAGE,
      territoryList: [],
      selectedTerritory: 0,
      editMode: false
    };
  },
  validations: {},
  created() {
    this.getTerritoryList();
  },
  methods: {
    handleEdit() {},
    handleCancel() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.editMode = false;
      }
      return false;
    },
    getSalesTerritoryDetails(territoryId) {
      this.selectedTerritory = territoryId;
      console.log('tid here', territoryId);
      // eslint-disable-next-line arrow-parens
      axiosMethods.getRequest(`${LocationUrls.GET_ZIPCODE}`).then(res => {
        this.territoryList = res.data.data.territories;
        console.log('locaiton branches', res.data.data, this.territoryList);
      });
    },
    showHideForm(status) {
      this.formShow = status !== 'undefined' ? status : !this.formShow;
    },
    getTerritoryList() {
      // eslint-disable-next-line arrow-parens
      axiosMethods.getRequest(`${LocationUrls.GET_TERRITORY}`).then(res => {
        this.territoryList = res.data.data.territories;
        console.log('locaiton branches', res.data.data, this.territoryList);
      });
    },
    editElements(ev) {
      // console.log(ev, 'vvvvvvvvvvvvvvvvvvvvvvvvvv');
      const id = ev.dataItem.partnerID;
      const MID = ev.dataItem.modelId;
      console.log(id, MID, 'daaaaa');
    }
  }
};
</script>