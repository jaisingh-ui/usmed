<template>
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button
          class="btn btn-link"
          data-toggle="collapse"
          data-target="#collapseOne"
          aria-expanded="true"
          aria-controls="collapseOne"
        >Regions</button>
      </h5>
      <div class="rightInfotext">
        <i class="fa fa-angle-down" data-toggle="collapse" data-target="#collapseOne"></i>
      </div>
    </div>
    <div
      id="collapseOne"
      class="collapse show"
      aria-labelledby="headingOne"
      data-parent="#accordion"
    >
      <div class="card-body">
        <div class="hideAreabox" data-page="1">
          <div class="row">
            <div class="col-md-12">
              <div class="boxAreaborder">
                <div class="row">
                  <div class="col-md-12 topButtonRegion">
                    <h4>Add New Region</h4>
                    <div>
                      <span class="save-btn mr-2">
                        <a href="javascript:void(0)">Save</a>
                      </span>
                      <span class="cancel-btn">
                        <a href="javascript:void(0)">Cancel</a>
                      </span>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-12">
                    <div class="form-group">
                      <label>Region Name</label>
                      <input type="text" class="form-control" id placeholder value />
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-12">
                    <div class="form-group">
                      <label>Operations Manager</label>
                      <div class="input-group">
                        <select id="inputState" class="form-control">
                          <option selected>
                            Select
                            Operations Manager
                          </option>
                          <option>...</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-7 col-md-12">
            <div class="locationSection">
              <div class="row mt-4">
                <div class="col-md-12">
                  <div class="table-responsive">
                    <table class="table softwareTable fix-head-table">
                      <thead>
                        <tr>
                          <th width="45%">Region</th>
                          <th class="text-nowrap">Operation Manager</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td width="46%" class="text-nowrap">Albuquerque</td>
                          <td class="text-nowrap">
                            Richard
                            Kinard
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Atlanta</td>
                          <td class="text-nowrap">
                            Chris
                            Hartman
                          </td>
                        </tr>
                        <tr class="active">
                          <td width="46%" class="text-nowrap">Austin</td>
                          <td class="text-nowrap">
                            Amber
                            Parker
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">BDC</td>
                          <td class="text-nowrap">
                            Rain
                            Thompson
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Albuquerque</td>
                          <td class="text-nowrap">
                            Richard
                            Kinard
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Atlanta</td>
                          <td class="text-nowrap">
                            Chris
                            Hartman
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Austin</td>
                          <td class="text-nowrap">
                            Amber
                            Parker
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">BDC</td>
                          <td class="text-nowrap">
                            Rain
                            Thompson
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Albuquerque</td>
                          <td class="text-nowrap">
                            Richard
                            Kinard
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Atlanta</td>
                          <td class="text-nowrap">
                            Chris
                            Hartman
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Austin</td>
                          <td class="text-nowrap">
                            Amber
                            Parker
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">BDC</td>
                          <td class="text-nowrap">
                            Rain
                            Thompson
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Albuquerque</td>
                          <td class="text-nowrap">
                            Richard
                            Kinard
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Atlanta</td>
                          <td class="text-nowrap">
                            Chris
                            Hartman
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Austin</td>
                          <td class="text-nowrap">
                            Amber
                            Parker
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">BDC</td>
                          <td class="text-nowrap">
                            Rain
                            Thompson
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Albuquerque</td>
                          <td class="text-nowrap">
                            Richard
                            Kinard
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Atlanta</td>
                          <td class="text-nowrap">
                            Chris
                            Hartman
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Austin</td>
                          <td class="text-nowrap">
                            Amber
                            Parker
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">BDC</td>
                          <td class="text-nowrap">
                            Rain
                            Thompson
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Albuquerque</td>
                          <td class="text-nowrap">
                            Richard
                            Kinard
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Atlanta</td>
                          <td class="text-nowrap">
                            Chris
                            Hartman
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">Austin</td>
                          <td class="text-nowrap">
                            Amber
                            Parker
                          </td>
                        </tr>
                        <tr>
                          <td width="46%" class="text-nowrap">BDC</td>
                          <td class="text-nowrap">
                            Rain
                            Thompson
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-5 col-md-12">
            <div class="locationSection">
              <div class="row">
                <div class="col-md-12 text-right mt-3 mb-2">
                  <span class="workingBtn addShowbox save-btn width-auto">
                    <a href="javascript:void(0)" data-click="1">Add New Region</a>
                  </span>
                  <span class="workingBtn edit-btn">
                    <a href="javascript:void(0)">Edit</a>
                  </span>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="custom-label">
                      Region
                      Name
                    </label>
                    <input type="text" class="form-control" id placeholder="Austin" disabled />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="custom-label">
                      Operation
                      Manager
                    </label>
                    <input type="text" class="form-control" id placeholder="Amber Parker" disabled />
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 mt-1">
                  <div class="form-group">
                    <label class="custom-label">
                      Associated
                      Branches
                    </label>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="table-responsive">
                    <table class="table softwareTable fix-head-table-small">
                      <tbody>
                        <tr>
                          <td>Birmingham</td>
                        </tr>
                        <tr>
                          <td>Birmingham</td>
                        </tr>
                        <tr>
                          <td>Austin</td>
                        </tr>
                        <tr>
                          <td>Lancaster</td>
                        </tr>
                        <tr>
                          <td>Birmingham</td>
                        </tr>
                        <tr>
                          <td>Birmingham</td>
                        </tr>
                        <tr>
                          <td>Dallas</td>
                        </tr>
                        <tr>
                          <td>Birmingham</td>
                        </tr>
                        <tr>
                          <td>Austin</td>
                        </tr>
                        <tr>
                          <td>Dallas</td>
                        </tr>
                        <tr>
                          <td>Birmingham</td>
                        </tr>
                        <tr>
                          <td>Austin</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Region',
  props: {},
  data() {
    return {};
  },
  validations: {},
  created() {},
  methods: {}
};
</script>
