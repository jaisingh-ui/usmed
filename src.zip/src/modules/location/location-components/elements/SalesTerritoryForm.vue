<template>
  <div data-page="3">
    <div class="row">
      <div class="col-md-12">
        <div class="boxAreaborder">
          <div class="row">
            <div class="col-md-12 topButtonRegion">
              <h4>Sales Territory</h4>
              <div>
                <span class="save-btn mr-2">
                  <a href="javascript:void(0)">Save</a>
                </span>
                <span class="cancel-btn">
                  <a @click="handleCancel" href="javascript:void(0)">Cancel</a>
                </span>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="form-group">
                <label>Sales Territory Name</label>
                <input type="text" class="form-control" id placeholder value />
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="form-group">
                <label>Sales Rep</label>
                <div class="input-group">
                  <select id="inputState" class="form-control">
                    <option selected>1217</option>
                    <option>...</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="form-group">
                <label>Sales Manager</label>
                <div class="input-group">
                  <select id="inputState" class="form-control">
                    <option selected>select</option>
                    <option>...</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { showWindowConfrim } from '../../../../shared/services/window-confrim';

export default {
  name: 'SalesTerritory',
  props: {},
  data() {
    return {
      formShow: false
    };
  },
  validations: {},
  created() {},
  methods: {
    handleCancel() {
      const cancel = showWindowConfrim();
      if (cancel) {
        this.$emit('showHideForm', false);
      }
      return false;
    }
  }
};
</script>