import Vue from 'vue';

// eslint-disable-next-line import/prefer-default-export
export const EventBus = new Vue();
