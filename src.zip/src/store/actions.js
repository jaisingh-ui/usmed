/* eslint-disable no-unused-vars */
/* eslint-disable indent */

import axios from 'axios';
import store from './store';
import commonService from '../shared/services/common-service';
import { MasterUrls } from '../shared/constants/urls';

const allActions = {
    // eslint-disable-next-line no-unused-vars
    resetEditAddStateToDefault: ({ commit }) => {
        commit('resetEditAddStateToDefault');
    },
    setMenuConfiguration: ({ commit }, modelConfig) => {
        commit('setMenuConfiguration', modelConfig);
    },
    setModelId: ({ commit }, modelId) => new Promise((resolve, reject) => {
        commit('setModelId', modelId);
    }),
    setModelName: ({ commit }, modelName) => new Promise((resolve, reject) => {
        commit('setModelName', modelName);
    }),
    setModelStatus: ({ commit }, modelStatus) => new Promise((resolve, reject) => {
        commit('setModelStatus', modelStatus);
    }),
    setOperationMode: ({ commit }, mode) => {
        commit('setOperationMode', mode);
    },
    setModelCategoryId: ({ commit }, modelCategoryId) => new Promise((resolve, reject) => {
        commit('setModelCategoryId', modelCategoryId);
    }),
    setPartnerId: ({ commit }, partnerid) => new Promise((resolve, reject) => {
        commit('setPartnerId', partnerid);
    }),
    setPartnerContactId: ({ commit }, partnercontactid) => new Promise((resolve, reject) => {
        commit('setPartnerContactId', partnercontactid);
    }),
    setContactId: ({ commit }, contactid) => new Promise((resolve, reject) => {
        commit('setContactId', contactid);
    }),
    setLoaderStatus: ({ commit }, loaderStatus) => new Promise((resolve, reject) => {
        commit('setLoaderStatus', loaderStatus);
    }),
    setUserObject: ({ commit }, userdata) => new Promise((resolve, reject) => {
        commit('setUserObject', userdata);
    }),

    /**
     * Partner call Log Actions
     */
    resetEditCallLogStateToDefault: ({ commit }) => {
        commit('resetEditCallLogStateToDefault');
    },
    setAddToCartObject: ({ commit }, addtocartdata) => new Promise((resolve, reject) => {
        commit('setAddToCartObject', addtocartdata);
    }),
    setDeliveryCart: ({ commit }, deliverycartdata) => new Promise((resolve, reject) => {
        commit('setDeliveryCart', deliverycartdata);
    }),
    setPickupCart: ({ commit }, pickupcartdata) => new Promise((resolve, reject) => {
        commit('setPickupCart', pickupcartdata);
    }),
    setIsDemoLoaner: ({ commit }, demoLoanerValue) => new Promise((resolve, reject) => {
        commit('setIsDemoLoaner', demoLoanerValue);
    }),
    setIsFullCallerInfoReq: ({ commit }, isFullCallerInfoReqValue) => new Promise((resolve, reject) => {
        commit('setIsDemoLoaner', isFullCallerInfoReqValue);
    }),
    setAddToCartStep: ({ commit }, addToCartStepValue) => new Promise((resolve, reject) => {
        commit('setAddToCartStep', addToCartStepValue);
    }),
    setSelectedCallsToAssign: ({ commit }, selectedCallsValue) => commit('setSelectedCallsToAssign', selectedCallsValue),
    setUserBranch: ({ commit }, userbranch) => new Promise((resolve, reject) => {
        commit('setUserBranch', userbranch);
    })

};

export default allActions;
