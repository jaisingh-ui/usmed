/* eslint-disable indent */
const allGetters = {
    getLeftMenuConfiguration: (state => state.menuConfig),
    getSubMenuFromLeftMenuConfig: (state => menuId => state.menuConfig.menus.find(
        item => item.menuSubMenus.find(
            subItems => subItems.subMenuId === menuId
        )
    )),
    getSubMenuModulesFromLeftMenuConfigs: (state, getters) => (menuId, subMenuId) => {
        const returnItem = getters.getSubMenuFromLeftMenuConfig(menuId);
        if (returnItem) { return returnItem.menuSubMenus.find(item => item.subMenuId === subMenuId); }
        return null;
    },
    // eslint-disable-next-line no-unused-vars
    getCategoriesToEnableLeftMenuConfigs: (state, getters) => (categoryId) => {
        if (!isNaN(categoryId)) {
            const menuCategories = getters.getLeftMenuConfiguration.categories.find(item => item.modelCategoryId === categoryId);
            if (menuCategories.subMenuId.length > 0) { return menuCategories.subMenuId; }
            return [];
        }
        return [];
    },
    getOperationMode: state => state.operationMode,
    getModelId: state => parseInt(state.modelId, 10),
    getModelName: state => state.modelName,
    getModelStatus: state => state.modelStatus,
    getModelCategoryId: state => parseInt(state.modelCategoryId, 10),
    getPartnerId: state => state.partnerId,
    getPartnerContactId: state => state.partnerContactId,
    getContactId: state => state.contactId,
    getLoaderStatus: state => state.loaderStatus,
    getUserObject: state => state.userObject,

    /**
     * Partner Call Log getters
     */
    getAddtoCartObject: state => state.addtocartobject,
    getDeliveryCart: state => state.addtocartobject.deliveryCart,
    getPickupCart: state => state.addtocartobject.pickupCart,
    getDemoLoader: state => state.addtocartobject.isDemoLoaner,
    getAddTocartStep: state => state.addtocartobject.addToCartStep,
    getSelectedCallsToAssign: state => state.selectedCallsToAssign,
    getCallerInfoRequired: state => state.addtocartobject.isFullCallerInfoReq,
    getUserbranch: state => state.addtocartobject.userBranch

};

export default allGetters;
