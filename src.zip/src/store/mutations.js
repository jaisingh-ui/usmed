/* eslint-disable indent */


const allMutations = {

    auth_request() {
        this.state.status = 'loading';
    },
    auth_success({ token }) {
        this.state.status = 'success';
        this.state.token = token;
    },
    auth_error() {
        this.state.status = 'error';
    },
    resetEditAddStateToDefault() {
        this.state.operationMode = 'none';
        this.state.modelId = null;
        this.state.modelOptions = {};
        this.state.modelSoftwareVersions = {};
        this.state.modelName = '';
        this.state.modelStatus = '';
        this.state.modelCategoryId = null;
        this.state.partnerId = '';
        this.state.partnerContactId = '';
        this.state.contactId = '';
    },
    setMenuConfiguration(state, menuConfig) {
        this.state.menuConfig = menuConfig;
    },
    setModelId(state, modelId) {
        this.state.modelId = modelId;
    },
    setModelName(state, modelName) {
        this.state.modelName = modelName;
    },
    setModelStatus(state) {
        this.state.modelStatus = state;
    },
    setOperationMode(state, mode) {
        this.state.operationMode = mode;
    },
    setShowHideLoaderMode(state, mode) {
        this.state.showHideLoader = mode;
    },
    setModelCategoryId(state, modelCategoryId) {
        this.state.modelCategoryId = modelCategoryId;
    },
    setPartnerId(state, partnerid) {
        this.state.partnerId = partnerid;
    },
    setPartnerContactId(state, partnercontactid) {
        this.state.partnerContactId = Number(partnercontactid);
    },
    setContactId(state, contactid) {
        this.state.contactId = Number(contactid);
    },
    setLoaderStatus(state, loaderStatus) {
        this.state.loaderStatus = loaderStatus;
    },


    /**
     * Partner Call Log State Management
     */
    resetEditCallLogStateToDefault() {
        if (this.state.addtocartobject.deliveryCart) {
            this.state.addtocartobject.deliveryCart.length = 0;
        }

        if (this.state.addtocartobject.pickupCart) {
            this.state.addtocartobject.pickupCart.length = 0;
        }
        // this.state.addtocartobject.isDemoLoaner = false;
        // this.state.addtocartobject.addToCartStep = false;
        // this.state.addtocartobject.isFullCallerInfoReq = false;
    },
    setAddToCartObject(state, addtocartobject) {
        this.state.addtocartobject = addtocartobject;
    },
    setDeliveryCart(state, deliveryObject) {
        this.state.addtocartobject.deliveryCart.push(deliveryObject);
    },
    setPickupCart(state, pickupCart) {
        this.state.addtocartobject.pickupCart.push(pickupCart);
    },
    setIsDemoLoaner(state, demoLoanerValue) {
        this.state.addtocartobject.isDemoLoaner = demoLoanerValue;
    },
    setAddToCartStep(state, stepValue) {
        this.state.addtocartobject.addToCartStep = stepValue;
    },
    setIsFullCallerInfoReq(state, callInfoValue) {
        this.state.addtocartobject.isFullCallerInfoReq = callInfoValue;
    },
    setUserBranch(state, userbranchValue) {
        this.state.addtocartobject.userBranch = userbranchValue;
    },
    setSelectedCallsToAssign(state, salectedCallsValue) {
        this.state.selectedCallsToAssign = salectedCallsValue;
    }

};
export default allMutations;
