import Vue from 'vue';
import Vuex from 'vuex';
import createPersistedState from 'vuex-persistedstate';
import SecureLS from 'secure-ls';

import allGetters from './getters';
import allActions from './actions';
import allMutations from './mutations';
import allStates from './state';

Vue.use(Vuex);
const secureStore = new SecureLS({ isCompression: false });
const store = new Vuex.Store({
  state: {
    ...allStates
  },
  mutations: {
    ...allMutations
  },
  actions: {
    ...allActions
  },
  modules: {},
  getters: {
    ...allGetters
  },
  plugins: [createPersistedState({
    storage: {
      getItem: key => secureStore.get(key),
      setItem: (key, value) => secureStore.set(key, value),
      removeItem: key => secureStore.remove(key)
    }
  })]
});
export default store;
