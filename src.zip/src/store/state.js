

const allStates = {
  menuConfig: {},
  status: '',
  user: {},
  allowToNavigate: true,
  // operationMode will be none, edit & add
  operationMode: '',
  // this will be model id which will be used to store in edit & add mode
  modelId: null,
  modelName: '',
  modelStatus: '',
  modelCategoryId: null,
  partnerId: '',
  contactId: '',
  partnerContactId: '',
  loaderStatus: false,
  selectedCallsToAssign: [],
  addtocartobject: {
    deliveryCart: [],
    pickUpCart: [],
    isDemoLoaner: false,
    addToCartStep: false,
    isFullCallerInfoReq: false,
    userBranch: 1
  }
};

export default allStates;
