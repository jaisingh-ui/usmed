import Vue from 'vue';
import VueRouter from 'vue-router';
import ModelCatalogRouter from '../modules/modelcatalog/ModelCatalogRouter';
import CallLogRouter from '../modules/calllogs/CallLogRouter';
import DashboardRouter from '../modules/dashboard/DashboardRouter';
import ContactsRouter from '../modules/contacts/ContactsRouter';
import PartnersRouter from '../modules/partner/PartnersRouter';
import Dashboard from '../modules/dashboard/Dashboard';
import LocationRouter from '../modules/location/LocationRouter';

Vue.use(VueRouter);
const router = new VueRouter({
  routes: [
    ...CallLogRouter,

    ...ModelCatalogRouter,

    ...DashboardRouter,

    ...ContactsRouter,

    ...PartnersRouter,
    ...LocationRouter,
    {
      path: '/',
      name: 'Dashboard',
      component: Dashboard
    }
  ],
  mode: 'history'
});

export default router;
