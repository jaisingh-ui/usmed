<template>
  <div class="custom-autocomplete">
    <kendo-datasource ref="datasource" :data="searchedItem"></kendo-datasource>
    <kendo-autocomplete
      ref="autoComp"
      :data-source-ref="'datasource'"
      :filter="'contains'"
      :placeholder="initialPlaceHolder"
      :data-text-field="paramToBind"
      :value="textenter"
      @change="onChange"
      @filtering="onFiltering"
      @open="onOpen"
      @select="onSelect"
      @close="onClose"
    ></kendo-autocomplete>
  </div>
</template>
<script>
import Vue from 'vue';
import '@progress/kendo-ui/js/kendo.autocomplete';
import { DropdownsInstaller } from '@progress/kendo-dropdowns-vue-wrapper';

Vue.use(DropdownsInstaller);
export default {
  props: {
    initialPlaceHolder: {
      type: String
    },
    searchedItem: {
      type: Array
    },
    paramToBind: {
      type: String
    },
    bindToInput: {
      type: String
    },
    itemIndex: {
      type: Number
    },
    distroyThis: {
      type: Number
    },
    value: {
      type: String
    }
  },
  data() {
    return {
      dataSourceArray: this.searchedItem,
      textenter: '',
      changeText: '',
      limit: 3,
      filteredData: {},
      filteredDataArray: []
    };
  },
  methods: {
    // eslint-disable-next-line no-unused-vars
    onClose(e) {
      this.changeText = '';
    },
    clearData() {
      this.textenter = '';
      this.dataSourceArray = null;
    },
    getDataToBind() {
      return this.searchedItem;
    },
    // eslint-disable-next-line no-unused-vars
    onClear(e) {},
    onChange(e) {
      this.changeText = e;
      if (this.textenter.length === 0) {
        this.$emit('emptySelectedFields', this.textenter, this.itemIndex);
      }
    },
    onFiltering(e) {
      if (e.filter.value.length > 2) {
        this.$emit('autoFilterData', e.filter.value);
      } else if (e.filter.value.length === 0) {
        this.textenter = e.filter.value;
        this.$emit('emptySelectedFields', this.textenter, this.itemIndex);
      }
    },
    // eslint-disable-next-line no-unused-vars
    onOpen(e) {
      // console.log('Event :: open', e);
    },
    onSelect(e) {
      // eslint-disable-next-line dot-notation
      this.textenter = e.dataItem[this.bindToInput];
      this.$emit('setSeletecDataToInputs', e.dataItem, this.itemIndex);
      // this.$refs.autoComp.destroy();
      this.$emit('refresh');
    }
  },
  mounted() {
    this.$root.$on('clearText', this.clearData);
  }
};
</script>
<style scoped>
</style>