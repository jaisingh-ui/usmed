<template>
  <div class="custom-kendo-grid">
    <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
      <span class="k-loading-text">Loading...</span>
      <div class="k-loading-image">
        <div class="k-loading-color"></div>
      </div>
    </div>
    <kendo-grid
      @change="onViewDetail"
      @pdfexport="onPdfExport"
      :selectable="true"
      ref="kendoData"
      style="height: 725px;"
      no-records-template="<p class='no-record-text'>There is no data available.</p>"
      :data-source="myData"
      :pageable="pageable"
      :filterable-mode="'row'"
      :sortable-mode="'single'"
      :reorderable="true"
      :columns="columns"
      :toolbar="toolbar"
      :pdf-avoid-links="true"
      :pdf-paper-size="'A4'"
      :pdf-all-pages="true"
      :pdf-margin="{ top: '2cm', left: '1cm', right: '1cm', bottom: '1cm' }"
      :pdf-landscape="true"
      :pdf-repeat-headers="true"
      :pdf-scale="0.8"
      :excel-all-pages="true"
      :excel-file-file="'file.xlsx'"
    ></kendo-grid>
  </div>
</template>

<script>
import Vue from 'vue';
import { DataSourceInstaller } from '@progress/kendo-datasource-vue-wrapper';
// import { DropdownsInstaller } from '@progress/kendo-dropdowns-vue-wrapper';
import { Grid, GridInstaller } from '@progress/kendo-grid-vue-wrapper';
import JSZip from 'jszip';
import $ from 'jquery';

window.JSZip = JSZip;
Vue.use(DataSourceInstaller);
Vue.use(GridInstaller);
// Vue.use(DropdownsInstaller);
Vue.component('Grid', Grid);
// Vue.component('GridColumn', GridColumn);
// Vue.component('GridDataSource', GridDataSource);

export default {
  props: {
    myColumns: {
      type: Array
    },
    multiSelectData: {
      type: Array
    },
    myToolbar: {
      type: Array
    },
    myData: {
      type: Array
    }
  },
  data() {
    return {
      showLoader: false,
      dataItems: [],
      pageable: {
        pageSizes: [15, 30, 45, 60],
        buttonCount: 5,
        pageSize: 15
      },
      multiSelectDataArray: this.multiSelectData,
      selectedColumns: this.myColumns,
      toolbar: this.myToolbar
      // dataResult: this.myData
    };
  },
  methods: {
    onViewDetail(ev) {
      // eslint-disable-next-line arrow-parens
      const id = $.map(ev.sender.select(), item => $('td:eq(0)', item).text());
      // const name = $.map(ev.sender.select(), item => $('td:eq(2)', item).text());
      // const status = $.map(ev.sender.select(), item => $('td:eq(6)', item).text());
      // const body = { id, name, status };
      this.$emit('viewDetailCliked', id);
    },
    onPdfExport(e) {
      this.showLoader = true;
      e.promise.then(() => {
        this.showLoader = false;
      });
    }
  },
  computed: {
    columns() {
      return this.selectedColumns;
    }
  }
};
</script>

<style>
.k-pdf-export .k-filter-row {
  display: none !important;
}

.k-loading-pdf-mask {
  display: none !important;
}

.custom-kendo-grid .k-header {
  text-align: right;
}

.custom-kendo-grid .k-grid-content-expander {
  width: auto !important;
}

.custom-kendo-grid .k-grid-toolbar {
  background-color: #ffffff;
}

.custom-kendo-grid th.k-header .k-link {
  text-align: left;
  font-size: 15px;
  font-weight: 500;
}

.k-pager-numbers .k-link {
  color: #787878;
}

.k-pager-numbers .k-link:hover,
.k-pager-nav:hover {
  color: #0053a0;
}

.k-list .k-item.k-state-selected,
.k-pager-numbers .k-state-selected,
.k-list .k-item.k-state-selected:hover {
  background-color: #0053a0;
}
.no-record-text {
  position: absolute;
  top: 0;
  padding: 10px 0px;
  width: 100%;
  margin-bottom: 0;
  left: 50%;
  -webkit-transform: translateX(-50%);
  transform: translateX(-50%);
  background-color: #fafafa;
}
.no-record-text:hover {
  background-color: #eeeeee;
}
</style>