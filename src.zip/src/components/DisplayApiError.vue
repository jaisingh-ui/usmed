<template>
  <div
    class="alert alert-warning alert-dismissible fade show text-center"
    role="alert"
    v-if="apiErrors.length > 0"
  >
    <div v-for="message in apiErrors">{{message.userMessage}}</div>
  </div>
</template>
<script>
export default {};
</script>>