<template>
  <div class="row" v-for="(option, index) in modelOptions">
    <div class="col-md-4">
      <div class="form-group">
        <label v-if="indexValue === 0">
          {{columnOneLabelValue}}
          <i
            class="icon-help-round-button"
            data-container="body"
            data-toggle="popover"
            data-placement="right"
            data-content="Options"
          ></i>
        </label>
        <input
          type="text"
          class="form-control"
          :placeholder="'Option ' + indexValue"
          v-model="option.option"
        />
      </div>
    </div>
    <div class="col-md-7 text-left">
      <div class="form-group">
        <label v-if="indexValue === 0">
          {{columnTwoLabel}}
          <i
            class="icon-help-round-button"
            data-container="body"
            data-toggle="popover"
            data-placement="right"
            data-content="Description"
            data-original-title
            title
          ></i>
        </label>
        <input
          type="text"
          class="form-control"
          :placeholder="'Option Description ' + indexValue"
          v-model="option.description"
        />
      </div>
    </div>

    <div class="col-md-1 text-left">
      <div :class="{'form-group first-div': indexValue===0, 'form-group': indexValue!==0}">
        <a href="#" v-if="indexValue === dataObject.length-1" @click.prevent="addElements">
          <i class="icon-model-options AddDelBtn" aria-hidden="true"></i>
        </a>
        <a href="#" v-else @click.prevent="deleteElements(indexValue)">
          <i class="icon-delete AddDelBtn" aria-hidden="true"></i>
        </a>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['columnOneData', 'columnOneLabel', 'columnTwoData', 'columnTwoLabel', 'index', 'defaultObject', 'actualObject'],
  data() {
    return {
      columanOneValue: this.columnOneData,
      columnTwoValue: this.columnTwoData,
      indexValue: this.index,
      defaultData: this.defaultObject,
      columnOneLabelValue: this.columnOneLabel,
      columnTwoLabelValue: this.columnTwoLabel,
      dataObject: this.actualObject
    };
  },
  methods: {
    addElements() {
      this.dataObject.push(this.defaultData);
      // this.modelOptions.push(this.modelOptionHTML);
      // this.$emit('clicked');
    },
    deleteElements(event, index) {
      this.dataObject.splice(index, 1);
    }
  }
};
</script>

<style scoped >
.first-div {
  margin-top: 30px;
}
</style>