<template>
  <div class="row">
    <div class="col-md-8">
      <h1 class="pageName">
        {{headerData.head}}
        <span v-show="headerData.id">
          :
          <span>{{headerData.name}}</span>
          <span style="color:#000; font-size:15px;">(# {{headerData.id}})</span>
          <span class="statusText">Status : {{headerData.status}}</span>
        </span>
      </h1>
    </div>
    <div class="col-md-4 text-right">
      <a href="#">
        <i class="fa fa-star" aria-hidden="true" style="color: #d8d8d8"></i>
      </a>
      <span class="FormworkingBtn">
        <a
          href="javascript:void(0)"
          data-toggle="collapse"
          data-target="#collapseTwo"
          aria-expanded="false"
          class="collapsed"
        >Collapse All</a>
      </span>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    headerData: {
      type: Object
    }
  },
  data() {
    return {
      currentModelId: null,
      modelName: null,
      modelStatus: '',
      pageName: this.moduleName
    };
  },
  created() {
    // this.currentModelId = this.$store.getters.getModelId;
    // this.modelName = this.$store.getters.getModelName;
    // this.modelStatus = this.$store.getters.getModelStatus;
  },
  computed: {
    result() {
      return this.headerData;
    }
  }
};
</script>