<template>
  <div>
    <div class="openArrow" @click="handleRtClick">
      <span></span>
    </div>
    <div class="rightSubmenu" ref="rtSubMenu">
      <div class="closeRight" @click="handleCloseBtn">
        <i class="fa fa-times-circle" aria-hidden="true"></i>
      </div>
      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
          <a
            class="nav-link active"
            id="quick-tab"
            data-toggle="tab"
            href="#quick"
            role="tab"
            aria-controls="quick"
            aria-selected="false"
          >Favorites</a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            id="Help-tab"
            data-toggle="tab"
            href="#help"
            role="tab"
            aria-controls="help"
            aria-selected="true"
          >Help</a>
        </li>
      </ul>
      <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade" id="help" role="tabpanel" aria-labelledby="help-tab">
          <h3>Partner Profile</h3>
          <!--Accordion wrapper-->
          <div
            class="accordion md-accordion"
            id="accordionEx"
            role="tablist"
            aria-multiselectable="true"
          >
            <!-- Accordion card -->
            <div class="card active">
              <!-- Card header -->
              <div class="card-header" role="tab" id="headingOne1">
                <a
                  data-toggle="collapse"
                  data-parent="#accordionEx"
                  href="#collapseOne1"
                  aria-expanded="true"
                  aria-controls="collapseOne1"
                >
                  <h5 class="mb-0">
                    Partner primary IDN
                    <i class="fa fa-angle-down"></i>
                  </h5>
                </a>
              </div>

              <!-- Card body -->
              <div
                id="collapseOne1"
                class="collapse show"
                role="tabpanel"
                aria-labelledby="headingOne1"
                data-parent="#accordionEx"
              >
                <div
                  class="card-body"
                >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</div>
              </div>
            </div>
            <!-- Accordion card -->
            <!-- Accordion card -->
            <div class="card">
              <!-- Card header -->
              <div class="card-header" role="tab" id="headingTwo2">
                <a
                  class="collapsed"
                  data-toggle="collapse"
                  data-parent="#accordionEx"
                  href="#collapseTwo2"
                  aria-expanded="false"
                  aria-controls="collapseTwo2"
                >
                  <h5 class="mb-0">
                    Partner primary IDN 2
                    <i class="fa fa-angle-down"></i>
                  </h5>
                </a>
              </div>

              <!-- Card body -->
              <div
                id="collapseTwo2"
                class="collapse"
                role="tabpanel"
                aria-labelledby="headingTwo2"
                data-parent="#accordionEx"
              >
                <div
                  class="card-body"
                >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</div>
              </div>
            </div>
            <!-- Accordion card -->
            <!-- Accordion card -->
            <div class="card">
              <!-- Card header -->
              <div class="card-header" role="tab" id="headingThree3">
                <a
                  class="collapsed"
                  data-toggle="collapse"
                  data-parent="#accordionEx"
                  href="#collapseThree3"
                  aria-expanded="false"
                  aria-controls="collapseThree3"
                >
                  <h5 class="mb-0">
                    Partner primary IDN 3
                    <i class="fa fa-angle-down"></i>
                  </h5>
                </a>
              </div>

              <!-- Card body -->
              <div
                id="collapseThree3"
                class="collapse"
                role="tabpanel"
                aria-labelledby="headingThree3"
                data-parent="#accordionEx"
              >
                <div
                  class="card-body"
                >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</div>
              </div>
            </div>
            <!-- Accordion card -->
          </div>
          <!-- Accordion wrapper -->
        </div>
        <div
          class="tab-pane fade show active"
          id="quick"
          role="tabpanel"
          aria-labelledby="quick-tab"
        >
          <h3 class="BorderBottom">Pages Added to Favorites (2)</h3>
          <div class="FevMenu" v-for="item in favMenu" :key="item.meta">
            <router-link :to="item.path">
              <i class="fa fa-star" aria-hidden="true" style="color: #f48d28"></i>
              {{item.meta}}
            </router-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      favMenu: []
    };
  },
  methods: {
    handleRtClick() {
      this.$refs.rtSubMenu.classList.add('rightmenuOpen'); // contains('leftSubmenuChange');
    },
    handleCloseBtn() {
      this.$refs.rtSubMenu.classList.remove('rightmenuOpen'); // contains('leftSubmenuChange');
    }
  },
  mounted() {
    // eslint-disable-next-line no-unused-vars
    this.$root.$on('starclick', (meta, path, addOrRemoveToggel) => {
      // console.log(`${meta}   ${path}`);
      const newOpp = { meta, path };
      const found = this.favMenu.some(el => el.meta === meta);
      if (!found) {
        this.favMenu.push(newOpp);
      } else {
        this.favMenu.pop(newOpp);
      }
    });
  }
};
</script>