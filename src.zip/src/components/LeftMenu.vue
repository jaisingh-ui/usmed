<template>
  <div>
    <div id="sidebar">
      <ul class="nav">
        <router-link
          v-for="menu in leftMenuConfig.menus"
          v-if="menu.menuVisible"
          :key="menu.menuId"
          :to="menu.menuUrl"
          tag="li"
          :class="{active: count===menu.menuId}"
        >
          <a @click="handleMenuClicks(menu)">
            <i :class="menu.menuIcon" aria-hidden="true"></i>
            {{menu.menuName}}
          </a>
          <div
            class="sidebarSubMenu showHideElement"
            v-show="toggle.leftSubMenuOpen"
            v-if="menu.menuSubMenus.length>0 && count===menu.menuId"
          >
            <div class="leftSubPannel">
              <ul>
                <router-link
                  v-for="(subMenu, index) of menu.menuSubMenus"
                  v-if="showHideModleSubMenu(subMenu.subMenuId) && subMenu.subMenuVisible"
                  :to="subMenu.subMenuUrl.replace(':id', $route.params.id)"
                  :key="`menuSubMenus${subMenu.subMenuId}`"
                  tag="li"
                  exact-active-class="active"
                >
                  <a
                    v-bind:class="{'disabled':enableSubMenus(index, menu.menuId) }"
                    @click="handleSubMenuClicks(index)"
                  >
                    <i :class="subMenu.subMenuIcon" aria-hidden="true"></i>
                    {{subMenu.subMenuName}}
                  </a>
                </router-link>
              </ul>
            </div>
          </div>
        </router-link>
      </ul>
      <div
        :class="{'pinIcon showHideElement': toggle.leftSubMenuOpen, 'pinIcon pinIconchange': !toggle.leftSubMenuOpen }"
        v-show="toggle.pinIconVisible"
        @click="onPinClicked"
      >
        <i class="icon-pin" v-show="toggle.pinIconVisible"></i>
      </div>
    </div>
  </div>
</template>
<script>
import commonService from '../shared/services/common-service';
import { MasterUrls } from '../shared/constants/urls';

export default {
  data() {
    return {
      count: 1,
      toggle: {
        leftSubMenuOpen: false,
        contentAreaOccupy: false,
        pinIconVisible: false
      },
      leftMenuConfig: [],
      modelId: null,
      oprMode: '',
      enabledModelSubMenus: []
    };
  },
  methods: {
    handleMenuClicks(event) {
      this.toggle.leftSubMenuOpen = false;
      this.toggle.contentAreaOccupy = false;
      this.toggle.pinIconVisible = false;
      this.count = event.menuId;
      if (event.menuSubMenus.length > 0) {
        this.toggle.leftSubMenuOpen = true;
        this.toggle.contentAreaOccupy = true;
        this.toggle.pinIconVisible = true;
      }
      this.$emit('clicked', this.toggle.contentAreaOccupy);
      this.$store.dispatch('resetEditAddStateToDefault');
    },
    onPinClicked() {
      this.toggle.leftSubMenuOpen = !this.toggle.leftSubMenuOpen;
      this.toggle.contentAreaOccupy = !this.toggle.contentAreaOccupy;
      this.$emit('clicked', this.toggle.contentAreaOccupy);
    },
    enableSubMenus(index, menuId) {
      this.modelId = this.$store.getters.getModelId;
      this.oprMode = this.$store.getters.getOperationMode;
      // Search Model/Partner List, very first sub-menu will be enable by default
      if (index === 0) {
        return false;
      } else if (menuId > 2 && !isNaN(this.$route.params.id)) {
        return false;
      } else if (this.modelId && index !== 0 && this.oprMode === 'edit') {
        // if model Id exist in system and operation Mode is edit. i.e user had clicked on the
        // grid row event
        return false;
      } else if (this.oprMode === 'add' && index === 1) {
        return false;
      } else if (this.modelId && this.oprMode === 'add' && index !== 1) {
        return false;
      }
      return true;
    },
    showHideModleSubMenu(subMenuId) {
      const arr = this.$store.getters.getCategoriesToEnableLeftMenuConfigs(this.$store.getters.getModelCategoryId);
      if (this.modelId !== null && !isNaN(this.modelId) && typeof this.modelId === 'number' && arr.length > 0) {
        if (arr.indexOf(subMenuId) === -1) {
          return false;
        }
        return true;
      }
      return true;
    },
    handleSubMenuClicks(index) {
      if (index === 0) {
        this.$store.dispatch('resetEditAddStateToDefault');
      }
    }
  },
  watch: {},
  created() {
    // eslint-disable-next-line arrow-parens,no-unused-vars
    commonService.getConfigurableMenus(`${MasterUrls.configurableMenu}?roleId=${1}`).then(res => {
      if (res.data.apiResponseStatus !== 'Failed') {
        // console.log(res.data.data, '0000000');
        this.leftMenuConfig = res.data.data;
        this.$store.dispatch('setMenuConfiguration', this.leftMenuConfig);
        this.leftMenuConfig = this.$store.getters.getLeftMenuConfiguration;
      }
    });
  }
};
</script>