<template>
  <div class="col-md-12 mt-3">
    <div class="k-loading-mask" style="width:100%;height:100%" v-if="showLoader">
      <span class="k-loading-text">Loading...</span>
      <div class="k-loading-image">
        <div class="k-loading-color"></div>
      </div>
    </div>
    <h3 class="gridName">Uploaded Documents List</h3>
    <div class="upload-table">
      <table class="table softwareTable">
        <thead class="thead-custom">
          <tr>
            <th>Document Title</th>
            <th>Category</th>
            <th>Upload Date Time</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="DocumnetList.length === 0">
            <td>No Document found</td>
          </tr>
          <tr v-else v-for="(document, index) in DocumnetList">
            <td>
              <a :href="document.documentUrl" target="_blank">{{document.documentTitle}}</a>
            </td>
            <td>{{document.documentationCategoryName}}</td>
            <td>{{document.createdOn | formatDate}}</td>
            <td>
              <a
                href="javascript:void()"
                :class="editMode ? 'disabled-anchor' : ''"
                @click="!editMode ? removeDocument(document.id) : ''"
              >
                <i class="fas fa-trash AddDelBtn"></i>
              </a>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script>
import baseService from '../shared/services/base-service';
import { DocumentUrls } from '../shared/constants/urls';

export default {
  name: 'DocumentsTable',
  data() {
    return {
      editMode: true,
      DocumnetList: [],
      showLoader: false,
      menuId: 0
    };
  },
  created() {
    if (this.$route.params.id) {
      this.Id = this.$route.params.id;
      this.menuId = 3;
    } else if (this.$store.getters.getModelId) {
      this.Id = this.$store.getters.getModelId;
    } else {
      this.Id = 0;
      this.menuId = 2;
    }
    console.log(this.Id);
    this.getDocumentList(this.menuId, this.Id);
  },
  methods: {
    getDocumentList(menuId, RefID) {
      this.showLoader = true;
      // eslint-disable-next-line arrow-parens
      baseService.getRequest(`${DocumentUrls.GET_DOCUMENT}?menuId=${menuId}&RefID=${RefID}`).then(res => {
        if (res.data.apiResponseStatus !== 'Failed') {
          this.DocumnetList = res.data.data;
        }
        this.showLoader = false;
      });
    },
    removeDocument(id) {
      if (confirm('Do you really want to delete this document?')) {
        this.showLoader = true;
        // eslint-disable-next-line arrow-parens
        baseService.deleteRequest(`${DocumentUrls.DELETE_DOCUMENT}?id=${id}`).then(res => {
          console.log(res);
          this.getDocumentList(this.menuId, this.Id);
          this.showLoader = false;
        });
      }
    }
  }
};
</script>

<style scoped>
.upload-table {
  height: 336px;
  overflow-y: auto;
}
</style>