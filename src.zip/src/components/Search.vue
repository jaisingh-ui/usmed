<template>
  <div>
    <div class="searchArea">
      <h1 class="pageName">{{headTitle}}</h1>
      <div class="row mb-3">
        <div class="col-md-8">
          <div class="input-group">
            <input
              type="text"
              :class="{'form-control':true, 'rm-search-rt-bdr':searchInput }"
              v-model.trim="searchInput"
              @keyup.enter="onSearchMethod()"
              :placeholder="placeholder"
            />
            <div class="input-group-append" v-if="searchInput" @click="searchInput=''">
              <span class="input-group-text" id="basic-addon2">
                <i class="fa fa-times" aria-hidden="true"></i>
              </span>
            </div>
          </div>
          <div
            class="error-message pl-2 mt-1"
            v-if="errorMessage && showText"
          >Please enter a value to search.</div>
        </div>
        <div class="col-md-2 firstBtn">
          <button
            type="button"
            class="btn btn-blue btn-block"
            @click="showText = true;onSearchMethod(1)"
          >Search</button>
        </div>
        <div class="col-md-2 secondBtn">
          <button
            type="button"
            class="btn btn-lightRed btn-block"
            @click="onAdd()"
          >{{addButtonText}}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    headTitle: {
      type: String
    },
    placeholder: {
      type: String
    },
    mySearchInput: {
      type: String
    },
    addButtonText: {
      type: String
    },
    showAllInput: {
      type: Boolean
    }
  },
  data() {
    return {
      searchInput: this.mySearchInput,
      // showAllInputVal: this.showAllInput,
      showText: false
    };
  },
  watch: {
    mySearchInput() {
      this.searchInput = this.mySearchInput;
    },
    searchInput() {
      this.$emit('searchInputValueChanged', this.searchInput);
    },
    showAllInput() {
      return this.showAllInput;
    }
  },
  computed: {
    errorMessage() {
      const inputLength = this.searchInput.length;
      if (inputLength === 1) {
        this.showText = false;
      }
      // console.log(this.searchInput, this.showText, this.showAllInput, inputLength);
      if (this.showAllInput) {
        return false;
      }
      if (!this.searchInput && this.showText) {
        return true;
      }

      return false;
    }
  },
  methods: {
    onSearchMethod(submitClicked) {
      if (submitClicked) {
        this.showText = true;
      }
      // if (!this.searchInput && !this.showAllInput) {
      //   alert(`${!this.searchInput} && ${!this.showAllInput}`);
      //   this.showText = true;
      // } else {
      //   this.showText = false;
      // }
      if (this.searchInput.length > 0) {
        this.$emit('onSearchClicked', this.searchInput);
      }
    },
    onAdd() {
      this.$emit('onAddClicked');
      this.$store.dispatch('setOperationMode', 'add');
    }
  }
};
</script>
<style scoped>
.searchArea .input-group-text {
  border-left: 0;
}
/*---conditionally---------(jab button ayega)*/
.rm-search-rt-bdr {
  border-right: 0;
}
</style>>