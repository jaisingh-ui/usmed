<template>
  <div class="row">
    <div class="header-section">
      <div class="smarts-logo">
        <span>
          <a href="#">
            <img src="../assets/images/logo.png" alt="smarts Logo" title="smarts Logo" />
          </a>
        </span>
      </div>
      <div class="smarts-user-section">
        <ul class="smarts-user">
          <li class="Topsearch">
            <form>
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                    <i class="fa fa-search" aria-hidden="true"></i>
                  </span>
                </div>
                <input type="text" class="form-control" placeholder="Search" />
              </div>
            </form>
          </li>
          <li class="nav-item dropdown notification">
            <a
              class="nav-link dropdown-toggle userLink"
              href="#"
              data-toggle="dropdown"
              aria-haspopup="true"
              aria-expanded="false"
            >
              <i>
                <i class="icon-notification" title="Notification"></i>
                <span>4</span>
              </i>
            </a>
            <ul class="dropdown-menu sub_menu animated flipInX">
              <li class="title">Messages</li>
              <li>
                <a href="JavaScript:void(0);">Your clinic location is changed</a>
              </li>
              <li>
                <a href="JavaScript:void(0);">GP/Consultant meeting on Friday</a>
              </li>
              <li>
                <a
                  href="JavaScript:void(0);"
                >Your theatre on MON 11/07/16 at The Orally Hospital starts at 14:50</a>
              </li>
              <li class="seenotification">
                <a href="JavaScript:void(0);">See All Notifications</a>
              </li>
            </ul>
          </li>
          <li class="nav-item dropdown userImg">
            <a
              class="nav-link dropdown-toggle"
              href="#"
              data-toggle="dropdown"
              aria-haspopup="true"
              aria-expanded="false"
            >
              <span>
                <i class="icon-user-profile-icon" title="User"></i>
              </span>
            </a>
            <div class="dropdown-menu bigmenu animated flipInX" style="min-width:284px;">
              <ul class="row">
                <li>
                  <router-link
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Book_Appointment"
                    to="/location"
                  >
                    <i class="fas fa-map-marked-alt"></i>
                    <span>Locations</span>
                  </router-link>
                </li>
                <li>
                  <a
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Book_Appointment"
                    href="javascript:void(0)"
                  >
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                  </a>
                </li>

                <li>
                  <a
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Book_Appointment"
                    href="javascript:void(0)"
                  >
                    <i class="far fa-check-square"></i>
                    <span>Roles</span>
                  </a>
                </li>
                <li>
                  <a
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Book_Appointment"
                    href="javascript:void(0)"
                  >
                    <i class="far fa-address-card"></i>
                    <span>Company Profile</span>
                  </a>
                </li>

                <!-- <li>
                  <a
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Book_Appointment"
                    href="javascript:void(0)"
                  >
                    <i class="fa fa-exclamation-triangle"></i>
                    <span>Book Appointment</span>
                  </a>
                </li>
                <li>
                  <a
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Contact_Hospital_Staff"
                    href="javascript:void(0)"
                  >
                    <i class="fa fa-exclamation-triangle"></i>
                    <span>Send Messages</span>
                  </a>
                </li>
                <li>
                  <a
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Holiday_request"
                    href="javascript:void(0)"
                  >
                    <i class="fa fa-exclamation-triangle"></i>
                    <span>Leave Request</span>
                  </a>
                </li>
                <li>
                  <a
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Find_Colleague"
                    href="javascript:void(0)"
                  >
                    <i class="fa fa-exclamation-triangle"></i>
                    <span>Find Colleague</span>
                  </a>
                </li>
                <li>
                  <a
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Offsite_Access"
                    href="javascript:void(0)"
                  >
                    <i class="fa fa-exclamation-triangle"></i>
                    <span>Offsite Access</span>
                  </a>
                </li>
                <li>
                  <a
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Request_Clinic"
                    href="javascript:void(0)"
                  >
                    <i class="fa fa-exclamation-triangle"></i>
                    <span>Request New Clinic</span>
                  </a>
                </li>
                <li>
                  <a
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Request_Theatre"
                    href="javascript:void(0)"
                  >
                    <i class="fa fa-exclamation-triangle"></i>
                    <span>Request New Theatre</span>
                  </a>
                </li>
                <li>
                  <a
                    class="subMenuHref"
                    hidesecondleftmenu="true"
                    id="Custom_Screen"
                    href="javascript:void(0)"
                  >
                    <i class="fa fa-exclamation-triangle"></i>
                    <span>Custom Screen</span>
                  </a>
                </li>-->
              </ul>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle userLink"
              href="#"
              data-toggle="dropdown"
              aria-haspopup="true"
              aria-expanded="false"
            >
              <span>Robert Brown</span>
            </a>
            <div class="dropdown-menu name animated flipInX">
              <a class="dropdown-item" href="#">
                <i class="fa fa-cog"></i> Settings
              </a>
              <a class="dropdown-item" href="#">
                <i class="fa fa-sign-out"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
