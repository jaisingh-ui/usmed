<template>
  <Grid
    ref="grid"
    :style="{height: '654px'}"
    :data-items="gridDataToRender"
    :edit-field="'inEdit'"
    :filterable="true"
    :filter="filter"
    :pageable="pageable"
    :skip="skip"
    :take="take"
    :total="total"
    :scrollable="'scrollable'"
    :page-size="pageSize"
    @filterchange="filterChange"
    :sortable="true"
    :sort="sort"
    @sortchange="sortChangeHandler"
    @edit="edit"
    @checkedElement="onSelectionChange"
    :columns="columns"
    :reorderable="true"
    @columnreorder="columnReorder"
    @pagechange="pageChangeHandler"
    @rowclick="onRowClick"
  >
    <grid-norecords>There is no data available</grid-norecords>
  </Grid>
</template>
<script>
/*eslint-disable*/
import Vue from 'vue';
import { Grid, GridToolbar, GridNoRecords } from '@progress/kendo-vue-grid';
import { filterBy, orderBy } from '@progress/kendo-data-query';

Vue.component('Grid', Grid);
Vue.component('grid-toolbar', GridToolbar);
Vue.component('grid-norecords', GridNoRecords);

export default {
  props: {
    gridObjects: {
      type: Array
    },
    sorting: {
      type: Array,
      default: []
    },
    gridColumns: {
      type: Array
    },
    skips: {
      type: Number
    },
    takes: {
      type: Number
    }
  },
  data() {
    return {
      pageable: {
        pageSizes: [15, 30, 45, 60],
        buttonCount: 5,
        pageSize: 15,
        info: true,
        type: 'numeric',
        // pageSizes: true,
        previousNext: true
      },
      filter: {
        logic: 'and',
        filters: []
      },
      sort: this.sorting,
      updatedData: [],
      editID: null,
      //  group: [{ field: 'UnitsInStock' }],
      expandedItems: [],
      columns: this.gridColumns,
      gridData: this.gridObjects,
      skip: 0,
      take: 15,
      pageSize: 15
    };
  },
  computed: {
    gridDataToRender: {
      get() {
        if (this.filter !== null && this.filter.filters.length > 0) {
          this.gridData = orderBy(filterBy(this.gridData, this.filter), this.sort);
        } else {
          this.gridData = orderBy(this.gridObjects, this.sort);
        }
        if (this.gridData) {
          return this.gridData.slice(this.skip, this.take + this.skip);
        }
        return null;
      }
    },
    total() {
      return this.gridData ? this.gridData.length : 0;
    }
  },
  mounted() {
    // this.updatedData = JSON.parse(JSON.stringify(this.gridData));
  },
  methods: {
    columnReorder(options) {
      this.columns = options.columns;
    },
    sortChangeHandler(e) {
      this.sort = e.sort;
    },
    pageChangeHandler(event) {
      this.skip = event.page.skip;
      this.take = event.page.take;
      // this.$emit('pageChange', { dataItem: e.dataItem });
    },
    edit(e) {
      this.$emit('editRow', { dataItem: e.dataItem });
      // Vue.set(e.dataItem, 'inEdit', true);
    },
    onRowClick(e) {
      this.$emit('onRowClick', { dataItem: e.dataItem });
    },
    onSelectionChange(e) {
      this.$emit('checkedItem', { dataItem: e.dataItem });
      // Vue.set(e.dataItem, 'inEdit', true);
    },
    filterChange(ev) {
      this.filter = ev.filter;
    }
  }
};
</script>
<style>
.k-master-row {
  cursor: default;
}
/* .k-filtercell-operator {
  display: none;
} */
</style>